(function() {
  if (window.__desktopWidthController) return;
  window.__desktopWidthController = true;

  var TARGET = 'width=1200, initial-scale=0.34, user-scalable=yes';

  var origCreateElement = document.createElement;
  var origSetAttribute = Element.prototype.setAttribute;

  function isViewportMeta(n) {
    return n && n.nodeType === 1 &&
      String(n.tagName).toLowerCase() === 'meta' &&
      String(n.getAttribute('name') || '').toLowerCase() === 'viewport';
  }

  function rewrite(meta) {
    if (!meta) return;
    if (meta.getAttribute('content') !== TARGET) {
      origSetAttribute.call(meta, 'content', TARGET);
    }
  }

  document.createElement = function(tag) {
    var el = origCreateElement.apply(document, arguments);
    if (String(tag).toLowerCase() === 'meta') {
      var origMeta = el.setAttribute;
      el.setAttribute = function(name, value) {
        var lname = String(name).toLowerCase();
        if (lname === 'name' && String(value).toLowerCase() === 'viewport') {
          return origMeta.call(el, 'name', value);
        }
        if (lname === 'content' &&
            String(el.getAttribute('name') || '').toLowerCase() === 'viewport') {
          return origMeta.call(el, 'content', TARGET);
        }
        return origMeta.call(el, name, value);
      };
    }
    return el;
  };

  function fixAll() {
    var metas = document.querySelectorAll('meta[name="viewport"]');
    for (var i = 0; i < metas.length; i++) {
      rewrite(metas[i]);
    }
    if (metas.length === 0) {
      var head = document.head || document.getElementsByTagName('head')[0] || document.documentElement;
      if (head) {
        var m = origCreateElement.call(document, 'meta');
        origSetAttribute.call(m, 'name', 'viewport');
        origSetAttribute.call(m, 'content', TARGET);
        head.insertBefore(m, head.firstChild);
      }
    }
  }

  if (document.documentElement) {
    new MutationObserver(function(mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var nodes = mutations[i].addedNodes;
        for (var j = 0; j < nodes.length; j++) {
          if (isViewportMeta(nodes[j])) rewrite(nodes[j]);
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  fixAll();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', fixAll, { once: true });
  }
  window.addEventListener('load', fixAll, { once: true });
})();