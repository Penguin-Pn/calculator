(function () {
  if (window.__calculatorAdBlockV3) return 'ready';
  window.__calculatorAdBlockV3 = true;

  var bridge = null;
  try {
    if (window.Bridge && typeof window.Bridge.isBlocked === 'function') bridge = window.Bridge;
    else if (window.AndroidAdBlock && typeof window.AndroidAdBlock.isBlocked === 'function') bridge = window.AndroidAdBlock;
  } catch (e) {}

  var stats = { hidden: 0, blocked: 0 };
  window.__adblock = {
    report: function () { return JSON.stringify(stats); },
    setAI: function () {},
    getStats: function () { return stats; }
  };

  var adSelectors = [
    'ins.adsbygoogle',
    '[id^="google_ads_iframe"]',
    '[id^="div-gpt-ad"]',
    '[id^="aswift_"]',
    'iframe[src*="doubleclick.net"]',
    'iframe[src*="googlesyndication.com"]',
    'iframe[src*="googleadservices.com"]',
    'iframe[src*="amazon-adsystem.com"]',
    'iframe[src*="taboola.com"]',
    'iframe[src*="outbrain.com"]'
  ].join(',');

  function injectStyle() {
    if (document.getElementById('__adblock_style')) return;
    var style = document.createElement('style');
    style.id = '__adblock_style';
    style.textContent = adSelectors + '{display:none!important;visibility:hidden!important;height:0!important;width:0!important;overflow:hidden!important;}';
    (document.head || document.documentElement).appendChild(style);
  }

  function hideAds(root) {
    if (!root || !root.querySelectorAll) return;
    try {
      var found = root.querySelectorAll(adSelectors);
      for (var i = 0; i < found.length; i++) {
        if (found[i] && found[i].style) {
          found[i].style.setProperty('display', 'none', 'important');
          stats.hidden++;
        }
      }
    } catch (e) {}
  }

  function getHost(url) {
    try { return new URL(url, location.href).hostname.toLowerCase(); } catch (e) { return ''; }
  }

  function isBlocked(url) {
    var host = getHost(url);
    if (!host || !bridge) return false;
    try { return !!bridge.isBlocked(host); } catch (e) { return false; }
  }

  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function (input) {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      if (url && isBlocked(url)) {
        stats.blocked++;
        return Promise.reject(new TypeError('Failed to fetch'));
      }
      return origFetch.apply(this, arguments);
    };
  }

  var origXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function () {
    var xhr = new origXHR();
    var origOpen = xhr.open;
    var origSend = xhr.send;
    var blocked = false;

    xhr.open = function (method, url) {
      if (isBlocked(String(url))) { blocked = true; return; }
      return origOpen.apply(this, arguments);
    };

    xhr.send = function () {
      if (blocked) {
        stats.blocked++;
        setTimeout(function () {
          try {
            Object.defineProperty(xhr, 'readyState', { value: 4, configurable: true });
            Object.defineProperty(xhr, 'status', { value: 0, configurable: true });
            var evt = new ProgressEvent('error');
            xhr.dispatchEvent(evt);
            if (typeof xhr.onerror === 'function') xhr.onerror(evt);
            if (typeof xhr.onloadend === 'function') xhr.onloadend(evt);
          } catch (e) {}
        }, 0);
        return;
      }
      return origSend.apply(this, arguments);
    };
    return xhr;
  };
  window.XMLHttpRequest.prototype = origXHR.prototype;

  function start() {
    injectStyle();
    hideAds(document);
    if (window.MutationObserver && document.documentElement) {
      new MutationObserver(function (records) {
        for (var i = 0; i < records.length; i++) {
          var nodes = records[i].addedNodes;
          for (var j = 0; j < nodes.length; j++) {
            if (nodes[j] && nodes[j].nodeType === 1) hideAds(nodes[j]);
          }
        }
      }).observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  return 'ready';
})();