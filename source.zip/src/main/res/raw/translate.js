(function () {
  'use strict';
  if (window.__translate) return;

  var SKIP_TAGS = {
    SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, IFRAME: 1, OBJECT: 1, EMBED: 1,
    CODE: 1, PRE: 1, KBD: 1, SAMP: 1, VAR: 1, TEXTAREA: 1,
    INPUT: 1, SELECT: 1, OPTION: 1, BUTTON: 1,
    SVG: 1, MATH: 1, CANVAS: 1, VIDEO: 1, AUDIO: 1
  };

  var API = 'https://translate.googleapis.com/translate_a/single?client=gtx';

  var state = {
    translated: false,
    lang: '',
    originals: new WeakMap(),
    cache: Object.create(null),
    queue: [],
    active: 0,
    maxConcurrent: 5,
    observer: null,
    translatedCount: 0,
    failedCount: 0,
    doneCallback: null,
    cbCounter: 0,
    cbCallbacks: Object.create(null),
    hasBridge: false
  };

  try {
    state.hasBridge = (typeof Bridge !== 'undefined' && Bridge &&
      typeof Bridge.translateText === 'function');
  } catch (e) { state.hasBridge = false; }

  window.__onTranslateResult = function (id, result) {
    var cb = state.cbCallbacks[id];
    if (cb) cb(result);
  };

  function cacheKey(lang, text) { return lang + '\u0001' + text; }

  function httpGetJson(url) {
    return new Promise(function (resolve, reject) {
      if (typeof fetch !== 'function') { reject(new Error('no fetch')); return; }
      var opts = { credentials: 'omit' };
      var ctrl = null, timer = null;
      try {
        if (typeof AbortController !== 'undefined') {
          ctrl = new AbortController();
          opts.signal = ctrl.signal;
          timer = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 12000);
        }
      } catch (e) {}
      fetch(url, opts).then(function (r) {
        if (timer) clearTimeout(timer);
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      }).then(resolve).catch(function (e) {
        if (timer) clearTimeout(timer);
        reject(e);
      });
    });
  }

  function bridgeTranslate(text, targetLang) {
    return new Promise(function (resolve, reject) {
      var id = 'bt_' + (++state.cbCounter) + '_' + Date.now();
      var timer = setTimeout(function () {
        delete state.cbCallbacks[id];
        reject(new Error('timeout'));
      }, 12000);
      state.cbCallbacks[id] = function (result) {
        clearTimeout(timer);
        delete state.cbCallbacks[id];
        if (result === null || result === undefined || result === '') reject(new Error('empty'));
        else resolve(result);
      };
      try {
        Bridge.translateText(text, targetLang, id);
      } catch (e) {
        clearTimeout(timer);
        delete state.cbCallbacks[id];
        reject(e);
      }
    });
  }

  function translateText(text, targetLang) {
    var key = cacheKey(targetLang, text);
    if (state.cache[key] !== undefined) return Promise.resolve(state.cache[key]);

    var promise;
    if (state.hasBridge) {
      promise = bridgeTranslate(text, targetLang);
    } else {
      var url = API + '&sl=auto&tl=' + encodeURIComponent(targetLang) +
        '&dt=t&q=' + encodeURIComponent(text);
      promise = httpGetJson(url).then(function (data) {
        var out = '';
        var chunks = data && data[0];
        if (chunks) {
          for (var i = 0; i < chunks.length; i++) {
            if (chunks[i] && chunks[i][0]) out += chunks[i][0];
          }
        }
        return out || text;
      });
    }

    return promise.then(function (t) {
      if (!t) t = text;
      state.cache[key] = t;
      return t;
    });
  }

  function collectTextNodes(root) {
    var nodes = [];
    if (!root) return nodes;
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        var p = node.parentNode;
        while (p && p.nodeType === 1) {
          var tag = p.tagName ? p.tagName.toUpperCase() : '';
          if (SKIP_TAGS[tag]) return NodeFilter.FILTER_REJECT;
          if (p.hasAttribute && p.hasAttribute('contenteditable') &&
              p.getAttribute('contenteditable') !== 'false') return NodeFilter.FILTER_REJECT;
          if (p.classList && p.classList.contains('notranslate')) return NodeFilter.FILTER_REJECT;
          p = p.parentNode;
        }
        if (!/[A-Za-z\u0600-\u06FF\u0400-\u04FF\u4E00-\u9FFF\uAC00-\uD7AF]/.test(node.nodeValue)) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    }, false);
    var n;
    while ((n = walker.nextNode())) nodes.push(n);
    return nodes;
  }

  function applyTranslation(job, translated) {
    if (!job.node || !state.originals.has(job.node)) return;
    if (!document.contains(job.node)) return;
    job.node.nodeValue = job.leading + translated + job.trailing;
  }

  function notifyDone() {
    if (state.queue.length > 0 || state.active > 0) return;
    var cb = state.doneCallback;
    if (!cb) return;
    state.doneCallback = null;
    cb(state.translatedCount > 0);
  }

  function pump() {
    while (state.active < state.maxConcurrent && state.queue.length > 0) {
      var job = state.queue.shift();
      (function (j) {
        var cached = state.cache[cacheKey(state.lang, j.text)];
        if (cached !== undefined) {
          applyTranslation(j, cached);
          state.translatedCount++;
          notifyDone();
          return;
        }
        state.active++;
        translateText(j.text, state.lang).then(function (t) {
          applyTranslation(j, t);
          state.translatedCount++;
        }).catch(function () {
          state.failedCount++;
        }).then(function () {
          state.active--;
          pump();
          notifyDone();
        });
      })(job);
    }
  }

  function enqueueNode(node) {
    if (!node || !node.nodeValue) return;
    if (state.originals.has(node)) return;
    var raw = node.nodeValue;
    var leading = (raw.match(/^\s*/) || [''])[0];
    var trailing = (raw.match(/\s*$/) || [''])[0];
    var core = raw.trim();
    if (!core) return;
    state.originals.set(node, raw);

    var key = cacheKey(state.lang, core);
    if (state.cache[key] !== undefined) {
      node.nodeValue = leading + state.cache[key] + trailing;
      state.translatedCount++;
      return;
    }
    state.queue.push({ node: node, text: core, leading: leading, trailing: trailing });
  }

  function startObserver() {
    if (state.observer) return;
    if (typeof MutationObserver === 'undefined') return;
    state.observer = new MutationObserver(function (muts) {
      if (!state.translated) return;
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (m.type !== 'childList') continue;
        for (var j = 0; j < m.addedNodes.length; j++) {
          var add = m.addedNodes[j];
          if (add.nodeType === 1) {
            var nodes = collectTextNodes(add);
            for (var k = 0; k < nodes.length; k++) enqueueNode(nodes[k]);
            pump();
          } else if (add.nodeType === 3) {
            enqueueNode(add);
            pump();
          }
        }
      }
    });
    state.observer.observe(document.body || document.documentElement, {
      childList: true, subtree: true
    });
  }

  function stopObserver() {
    if (state.observer) { state.observer.disconnect(); state.observer = null; }
  }

  function restoreAll() {
    if (state.doneCallback) {
      var old = state.doneCallback;
      state.doneCallback = null;
      try { old(false); } catch (e) {}
    }
    state.queue = [];
    state.active = 0;
    var root = document.body || document.documentElement;
    if (root) {
      var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
      var restorable = [];
      var n;
      while ((n = walker.nextNode())) {
        if (state.originals.has(n)) restorable.push(n);
      }
      for (var i = 0; i < restorable.length; i++) {
        var node = restorable[i];
        var orig = state.originals.get(node);
        if (orig !== undefined) node.nodeValue = orig;
      }
    }
    state.originals = new WeakMap();
    state.translated = false;
    state.lang = '';
    state.translatedCount = 0;
    state.failedCount = 0;
  }

  window.__translate = {
    translate: function (lang, cb) {
      if (!lang || typeof lang !== 'string') { if (cb) cb(false); return; }
      if (state.translated && state.lang === lang) { if (cb) cb(true); return; }
      if (state.translated) restoreAll();

      state.lang = lang;
      state.translated = true;
      state.translatedCount = 0;
      state.failedCount = 0;
      try { document.documentElement.lang = lang; } catch (e) {}

      var root = document.body || document.documentElement;
      var nodes = collectTextNodes(root);
      if (nodes.length === 0) {
        state.translated = false;
        state.lang = '';
        if (cb) cb(false);
        return;
      }

      var timeoutId = setTimeout(function () {
        var c = state.doneCallback;
        if (c) { state.doneCallback = null; c(state.translatedCount > 0); }
      }, 15000);

      state.doneCallback = function (ok) {
        clearTimeout(timeoutId);
        if (cb) cb(ok);
      };

      for (var i = 0; i < nodes.length; i++) enqueueNode(nodes[i]);
      pump();
      notifyDone();
      startObserver();
    },
    restore: function () {
      stopObserver();
      restoreAll();
      try { document.documentElement.removeAttribute('lang'); } catch (e) {}
    },
    state: function () {
      return {
        translated: state.translated,
        lang: state.lang,
        pending: state.queue.length + state.active,
        ok: state.translatedCount,
        fail: state.failedCount,
        bridge: state.hasBridge
      };
    }
  };
})();