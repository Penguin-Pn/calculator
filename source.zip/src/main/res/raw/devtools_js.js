(function () {
  if (window.__devtools && window.__devtools.__ready) return 'ready';

  var defaults = {
    console:'Console', sources:'Sources', network:'Network', elements:'Elements',
    application:'Application', performance:'Performance',
    clear:'🗑', close:'✕', run:'Run', placeholder:'Enter expression...',
    noLogs:'No logs', noNet:'No requests', noSrc:'No sources', empty:'Empty',
    headers:'Headers', preview:'Preview', response:'Response', timing:'Timing',
    general:'General', reqHeaders:'Request Headers', resHeaders:'Response Headers',
    localStorage:'Local Storage', sessionStorage:'Session Storage',
    cookies:'Cookies', indexedDB:'IndexedDB',
    key:'Key', value:'Value', name:'Name',
    external:'This resource is external or blocked by cross-origin restrictions'
  };
  var provided = window.__devtools_labels || {};
  var L = {};
  Object.keys(defaults).forEach(function(k) {
    L[k] = (provided[k] != null && provided[k] !== 'undefined') ? provided[k] : defaults[k];
  });

  function el(t, c, x) {
    var e = document.createElement(t);
    if (c) e.className = c;
    if (x != null) e.textContent = x;
    return e;
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function(c) {
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }
  function fmtVal(v) {
    try {
      if (typeof v === 'string') return v;
      if (typeof v === 'function') return 'f ' + (v.name || 'anonymous') + '()';
      if (typeof v === 'symbol') return v.toString();
      if (v === null) return 'null';
      if (v === undefined) return 'undefined';
      if (v instanceof Error) return v.name + ': ' + v.message;
      return JSON.stringify(v);
    } catch (e) { return String(v); }
  }
  function shortVal(v) {
    var s = fmtVal(v);
    return s.length > 80 ? s.slice(0, 80) + '...' : s;
  }

  function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text);
      } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
    } catch(e) {}
  }

  var MAX_NETWORK = 500;
  var MAX_LOGS = 2000;
  var MAX_COMMAND_HISTORY = 200;
  var MAX_OBJECT_KEYS = 50;
  var MAX_INSPECT_DEPTH = 3;
  var CMD_STRING_LIMIT = 2000;
  var REBUILD_LIMIT = 20;
  var MAX_TABLE_ROWS = 100;
  var MAX_TABLE_COLS = 20;

  var dev = {
    __ready: true,
    logs: [],
    network: [],
    sources: [],
    storage: { local: {}, session: {}, cookies: [], idb: [] },
    visible: false,
    activeTab: 'console',
    panel: null,
    L: L,
    consoleFilter: 'all',
    consoleSearch: '',
    networkFilter: '',
    elementsSelected: null,
    elementsExpanded: {},
    cmdHistory: [],
    cmdIndex: -1,
    groupDepth: 0,
    timers: {},
    counters: {},
    scc: null,
    startWatchdog: null
  };
  window.__devtools = dev;

  var originals = {};
  var groupDepth = 0;
  var timers = {};
  var counters = {};

  var CONSOLE_METHODS = [
    'log','info','debug','warn','error','trace',
    'dir','dirxml','table',
    'group','groupCollapsed','groupEnd',
    'clear','count','countReset','assert',
    'time','timeEnd','timeLog','timeStamp',
    'profile','profileEnd',
    'exception','context',
    'record','recordEnd',
    'markTimeline','timeline','timelineEnd',
    'select','screenshot','debug','undebug'
  ];

  function pushLog(level, args, extra) {
    var entry = {
      level: level,
      time: new Date().toLocaleTimeString('en-GB'),
      args: args || [],
      indent: groupDepth,
      ts: Date.now()
    };
    if (extra) {
      for (var k in extra) if (extra.hasOwnProperty(k)) entry[k] = extra[k];
    }
    dev.logs.push(entry);
    if (dev.logs.length > MAX_LOGS) dev.logs.shift();
    if (dev.visible && dev.activeTab === 'console') renderConsole();
  }

  function truncateText(s) {
    if (typeof s !== 'string') return s;
    return s.length > 200000 ? s.slice(0, 200000) + '\n...[truncated]' : s;
  }

  CONSOLE_METHODS.forEach(function(method) {
    var orig = console[method];
    var hasOriginal = typeof orig === 'function';
    originals[method] = hasOriginal ? orig : function () {};

    console[method] = function() {
      var args = Array.prototype.slice.call(arguments);
      var label;

      try {
        switch (method) {
          case 'group':
          case 'groupCollapsed':
            pushLog('group', args);
            groupDepth++;
            break;
          case 'groupEnd':
            if (groupDepth > 0) groupDepth--;
            break;
          case 'clear':
            dev.logs = [];
            groupDepth = 0;
            timers = {};
            counters = {};
            dev.groupDepth = 0;
            dev.timers = {};
            dev.counters = {};
            if (dev.visible && dev.activeTab === 'console') renderConsole();
            break;
          case 'time':
            label = String(args[0] || 'default');
            timers[label] = performance.now();
            pushLog('time', [label + ': timer started']);
            break;
          case 'timeEnd':
            label = String(args[0] || 'default');
            var tStart = timers[label];
            var tDur = tStart != null ? (performance.now() - tStart) : 0;
            delete timers[label];
            pushLog('time', [label + ': ' + tDur.toFixed(2) + ' ms']);
            break;
          case 'timeLog':
            label = String(args[0] || 'default');
            var tlStart = timers[label];
            var tlDur = tlStart != null ? (performance.now() - tlStart) : 0;
            pushLog('time', [label + ': ' + tlDur.toFixed(2) + ' ms'].concat(args.slice(1)));
            break;
          case 'count':
            label = String(args[0] || 'default');
            counters[label] = (counters[label] || 0) + 1;
            pushLog('count', [label + ': ' + counters[label]]);
            break;
          case 'countReset':
            label = String(args[0] || 'default');
            counters[label] = 0;
            pushLog('count', [label + ': 0']);
            break;
          case 'assert':
            if (!args[0]) pushLog('assert', ['Assertion failed:'].concat(args.slice(1)));
            break;
          case 'table':
            pushLog('table', args, { tableData: args[0], tableCols: args[1] });
            break;
          case 'trace':
            var stack = [];
            try { stack = (new Error()).stack.split('\n').slice(2, 6); } catch (e) {}
            pushLog('trace', args.concat(['\n' + stack.join('\n')]));
            break;
          case 'exception':
            pushLog('exception', args);
            break;
          default:
            pushLog(method, args);
        }
      } catch (e) {
        pushLog('error', ['__devtools internal: ' + e.message]);
      }

      try { if (hasOriginal) orig.apply(console, args); } catch (e) {}
    };
  });

  window.addEventListener('error', function(e) {
    pushLog('error', [e.message + ' @ ' + (e.filename || '').split('/').pop() + ':' + (e.lineno || 0)]);
  });
  window.addEventListener('unhandledrejection', function(e) {
    pushLog('error', ['Unhandled: ' + ((e.reason && e.reason.message) || e.reason)]);
  });

  if (window.fetch) {
    var of = window.fetch;
    window.fetch = function() {
      var args = arguments;
      var url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '?';
      var opts = args[1] || {};
      var method = opts.method || (args[0] && args[0].method) || 'GET';
      var start = performance.now();
      var entry = {
        id: 'n' + Date.now() + Math.random(),
        url: url, method: method.toUpperCase(),
        status: 0, time: 0, ts: Date.now(),
        type: 'fetch', reqHeaders: opts.headers || {},
        reqBody: opts.body || null, resHeaders: {}, resBody: null
      };
      dev.network.push(entry);
      if (dev.network.length > MAX_NETWORK) dev.network.shift();
      if (dev.visible && dev.activeTab === 'network') renderNetwork();
      return of.apply(this, args).then(function(r) {
        entry.status = r.status;
        entry.time = Math.round(performance.now() - start);
        r.headers.forEach(function(v, k) { entry.resHeaders[k] = v; });
        try {
          r.clone().text().then(function(t) { entry.resBody = truncateText(t); });
        } catch (e) {}
        if (dev.visible && dev.activeTab === 'network') renderNetwork();
        return r;
      }).catch(function(x) {
        entry.status = -1;
        entry.time = Math.round(performance.now() - start);
        if (dev.visible && dev.activeTab === 'network') renderNetwork();
        throw x;
      });
    };
  }

  var OrigXHR = window.XMLHttpRequest;
  var NewXHR = function() {
    var xhr = new OrigXHR();
    var entry = { id: 'x' + Date.now() + Math.random(), url: '', method: 'GET',
                  status: 0, time: 0, ts: Date.now(), type: 'xhr',
                  reqHeaders: {}, resHeaders: {}, resBody: null };
    var start = 0;
    var origOpen = xhr.open, origSetHeader = xhr.setRequestHeader;
    xhr.open = function(m, u) {
      entry.method = (m || 'GET').toUpperCase();
      entry.url = String(u);
      return origOpen.apply(this, arguments);
    };
    xhr.setRequestHeader = function(k, v) {
      entry.reqHeaders[k] = v;
      return origSetHeader.apply(this, arguments);
    };
    xhr.addEventListener('loadstart', function() { start = performance.now(); });
    xhr.addEventListener('loadend', function() {
      entry.status = xhr.status;
      entry.time = Math.round(performance.now() - start);
      try {
        if (!xhr.responseType || xhr.responseType === 'text') {
          entry.resBody = truncateText(xhr.responseText);
        } else {
          entry.resBody = '[Response type: ' + xhr.responseType + ']';
        }
      } catch (e) {}
      try {
        var raw = xhr.getAllResponseHeaders() || '';
        raw.trim().split(/\r?\n/).forEach(function(line) {
          var i = line.indexOf(':');
          if (i > 0) entry.resHeaders[line.slice(0, i).trim()] = line.slice(i + 1).trim();
        });
      } catch (e) {}
      dev.network.push(entry);
      if (dev.network.length > MAX_NETWORK) dev.network.shift();
      if (dev.visible && dev.activeTab === 'network') renderNetwork();
    });
    return xhr;
  };
  NewXHR.prototype = OrigXHR.prototype;
  window.XMLHttpRequest = NewXHR;

  function collectStorage() {
    dev.storage.local = {};
    dev.storage.session = {};
    dev.storage.cookies = [];
    dev.storage.idb = [];
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        dev.storage.local[k] = localStorage.getItem(k);
      }
    } catch (e) {}
    try {
      for (var j = 0; j < sessionStorage.length; j++) {
        var k2 = sessionStorage.key(j);
        dev.storage.session[k2] = sessionStorage.getItem(k2);
      }
    } catch (e) {}
    try {
      document.cookie.split(';').forEach(function(c) {
        var p = c.trim().split('=');
        if (p[0]) dev.storage.cookies.push({ name: p[0], value: p.slice(1).join('=') });
      });
    } catch (e) {}
    try {
      if (window.indexedDB && indexedDB.databases) {
        indexedDB.databases().then(function(dbs) {
          dev.storage.idb = dbs || [];
          if (dev.visible && dev.activeTab === 'application') renderApplication();
        }).catch(function() {});
      }
    } catch (e) {}
  }

  function cleanPath(u) {
    if (!u) return '';
    try {
      var s = String(u);
      s = s.split('?')[0].split('#')[0];
      try {
        var url = new URL(s, location.href);
        if (url.origin === location.origin) {
          var p = url.pathname || '';
          if (p.charAt(0) === '/') p = p.substring(1);
          return p || url.hostname;
        }
        return url.hostname + url.pathname;
      } catch (e) { return s; }
    } catch (e) { return ''; }
  }

  function isBinaryFile(ext) {
    var binaryExts = ['png','jpg','jpeg','gif','webp','svg','ico','woff','woff2','ttf','eot','otf','mp3','mp4','webm','ogg','wav','pdf','zip','rar','7z','exe','dll','so','dylib'];
    return binaryExts.indexOf(ext) >= 0;
  }

  function collectSources() {
    var docName = 'index.html';
    try {
      var raw = (location.pathname || '').split('?')[0].split('#')[0];
      var last = raw.split('/').pop();
      if (last && last.indexOf('.') > 0) docName = last;
      else if (location.hostname) docName = location.hostname + '.html';
    } catch (e) {}

    dev.sources = [
      { path: docName, type: 'html', content: document.documentElement.outerHTML }
    ];

    document.querySelectorAll('script[src]').forEach(function(s) {
      var src = s.getAttribute('src') || s.src;
      var path = cleanPath(src);
      if (!path) path = src;
      dev.sources.push({ path: path, type: 'js', url: src, ext: true });
    });

    document.querySelectorAll('link[rel="stylesheet"]').forEach(function(l) {
      var href = l.getAttribute('href') || l.href;
      var path = cleanPath(href);
      if (!path) path = href;
      dev.sources.push({ path: path, type: 'css', url: href, ext: true });
    });

    document.querySelectorAll('script:not([src])').forEach(function(s, i) {
      dev.sources.push({
        path: docName + ' > inline-' + (i + 1) + '.js',
        type: 'js', content: s.textContent
      });
    });

    document.querySelectorAll('style').forEach(function(s, i) {
      dev.sources.push({
        path: docName + ' > inline-' + (i + 1) + '.css',
        type: 'css', content: s.textContent
      });
    });

    Array.from(document.images).forEach(function(img, i) {
      var src = img.getAttribute('src') || img.src || '';
      if (src.indexOf('data:') === 0) return;
      var path = cleanPath(src);
      if (!path) path = 'image-' + (i + 1);
      dev.sources.push({ path: path, type: 'img', url: src });
    });
  }

  function levelClass(lvl) {
    if (lvl === 'error' || lvl === 'exception' || lvl === 'trace' || lvl === 'assert') return 'error';
    if (lvl === 'warn') return 'warn';
    if (lvl === 'debug' || lvl === 'undebug') return 'debug';
    if (lvl === 'info') return 'info';
    if (lvl === 'group' || lvl === 'groupCollapsed') return 'group';
    if (lvl === 'table') return 'table';
    return 'log';
  }

  function levelIcon(lvl) {
    if (lvl === 'error' || lvl === 'exception' || lvl === 'assert') return 'x';
    if (lvl === 'warn') return '!';
    if (lvl === 'info') return 'i';
    if (lvl === 'debug' || lvl === 'undebug') return '#';
    if (lvl === 'trace') return '↳';
    if (lvl === 'group' || lvl === 'groupCollapsed') return '▸';
    if (lvl === 'table') return '▦';
    if (lvl === 'time' || lvl === 'timeEnd' || lvl === 'timeLog' || lvl === 'timeStamp') return '⏱';
    if (lvl === 'count' || lvl === 'countReset') return '#';
    if (lvl === 'profile' || lvl === 'profileEnd') return '⏺';
    return '>';
  }

  function matchesFilter(entry, filter, search) {
    var lvl = entry.level;
    var txt = entry.args ? entry.args.map(fmtVal).join(' ') : '';
    if (search && txt.toLowerCase().indexOf(search.toLowerCase()) === -1) return false;

    if (filter === 'all') return true;
    if (filter === 'log') {
      return ['log','dir','dirxml','table','group','groupCollapsed',
              'time','timeEnd','timeLog','timeStamp','count','countReset',
              'profile','profileEnd','context','record','recordEnd',
              'markTimeline','timeline','timelineEnd','select','screenshot'].indexOf(lvl) >= 0;
    }
    if (filter === 'info') return lvl === 'info';
    if (filter === 'warn') return lvl === 'warn';
    if (filter === 'error') return ['error','exception','trace','assert'].indexOf(lvl) >= 0;
    if (filter === 'debug') return lvl === 'debug' || lvl === 'undebug';
    return true;
  }

  function renderTable(data, columns) {
    if (data == null) return null;
    var wrap = el('div', 'dt-console-table-wrap');
    var table = el('table', 'dt-console-table');
    var rows = [];

    if (Array.isArray(data)) {
      rows = data.map(function(v, i) { return [String(i), v]; });
    } else if (typeof data === 'object') {
      rows = Object.keys(data).map(function(k) { return [k, data[k]]; });
    } else {
      rows = [['value', data]];
    }

    var cols = Array.isArray(columns)
      ? columns
      : (rows.length && rows[0][1] && typeof rows[0][1] === 'object'
          ? ['(index)'].concat(Object.keys(rows[0][1]))
          : ['(index)', 'Value']);

    var thead = el('thead');
    var trh = el('tr');
    cols.forEach(function(c) {
      var th = el('th', null, String(c));
      trh.appendChild(th);
    });
    thead.appendChild(trh);
    table.appendChild(thead);

    var tbody = el('tbody');
    var maxRows = Math.min(rows.length, MAX_TABLE_ROWS);
    for (var i = 0; i < maxRows; i++) {
      var tr = el('tr');
      var key = rows[i][0];
      var val = rows[i][1];
      var cells = [key];
      if (val && typeof val === 'object') {
        cols.slice(1).forEach(function(c) { cells.push(val[c]); });
      } else {
        cells.push(val);
      }
      cells.slice(0, MAX_TABLE_COLS).forEach(function(c) {
        var td = el('td');
        if (c === null || c === undefined) td.textContent = String(c);
        else if (typeof c === 'object') td.textContent = shortVal(c);
        else td.textContent = String(c);
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    wrap.appendChild(table);

    if (rows.length > maxRows) {
      var more = el('div', 'dt-table-more', '... ' + (rows.length - maxRows) + ' more rows');
      wrap.appendChild(more);
    }
    return wrap;
  }

  function renderConsole() {
    if (!dev.panel) return;
    var host = dev.panel.querySelector('#dt-console');
    if (!host) return;
    host.innerHTML = '';
    var logs = dev.logs.filter(function(l) { return matchesFilter(l, dev.consoleFilter, dev.consoleSearch); });
    if (!logs.length) {
      host.innerHTML = '<div class="dt-empty">' + esc(L.noLogs) + '</div>';
      return;
    }
    var frag = document.createDocumentFragment();
    logs.forEach(function(l) {
      var cls = levelClass(l.level);
      var row = el('div', 'dt-log dt-' + cls);
      row.style.paddingLeft = (6 + (l.indent || 0) * 16) + 'px';
      row.style.cursor = 'pointer';
      row.title = 'Double-click to copy';

      var time = el('span', 'dt-time', l.time);
      var icon = el('span', 'dt-icon', levelIcon(l.level));
      row.appendChild(time);
      row.appendChild(icon);
      var msg = el('span', 'dt-msg');

      if (l.level === 'table' && l.tableData !== undefined) {
        var tbl = renderTable(l.tableData, l.tableCols);
        if (tbl) {
          msg.appendChild(tbl);
        } else {
          msg.textContent = '[table: null]';
        }
      } else {
        l.args.forEach(function(arg, i) {
          if (i > 0) msg.appendChild(document.createTextNode(' '));
          msg.appendChild(buildInspector(arg, 0));
        });
      }
      row.appendChild(msg);

      row.ondblclick = function(e) {
        var txt = l.time + ' [' + l.level.toUpperCase() + '] ' + l.args.map(fmtVal).join(' ');
        copyText(txt);
      };

      frag.appendChild(row);
    });
    host.appendChild(frag);
    host.scrollTop = host.scrollHeight;
  }

  function buildInspector(v, depth) {
    depth = depth || 0;
    if (v === null || v === undefined) {
      var s = el('span');
      s.style.color = '#569cd6';
      s.textContent = String(v);
      return s;
    }
    if (typeof v === 'object' && depth < MAX_INSPECT_DEPTH && !v.nodeType) {
      var wrap = el('span');
      var toggle = el('span', 'dt-obj-toggle');
      toggle.textContent = '> ';
      toggle.style.color = '#8b949e';
      toggle.style.cursor = 'pointer';
      var preview = el('span');
      preview.style.color = '#9cdcfe';
      preview.style.cursor = 'pointer';
      var keys;
      try { keys = Object.keys(v); } catch (e) { keys = []; }
      if (Array.isArray(v)) {
        preview.textContent = 'Array(' + v.length + ')';
      } else if (v instanceof Error) {
        preview.textContent = v.name + ': ' + v.message;
      } else {
        preview.textContent = '{' + keys.slice(0, 3).map(function(k){ return k + ': ...'; }).join(', ') +
          (keys.length > 3 ? ', ...' : '') + '}';
      }
      var detail = el('div', 'dt-obj-detail');
      detail.style.display = 'none';
      detail.style.paddingLeft = '16px';
      detail.style.borderLeft = '1px solid #30363d';
      detail.style.marginLeft = '4px';
      keys.slice(0, MAX_OBJECT_KEYS).forEach(function(k) {
        var kv = el('div');
        var kn = el('span', null, k + ': ');
        kn.style.color = '#79c0ff';
        var vn;
        try { vn = buildInspector(v[k], depth + 1); }
        catch (e) { vn = el('span', null, '[error]'); }
        kv.appendChild(kn);
        kv.appendChild(vn);
        detail.appendChild(kv);
      });
      if (keys.length > MAX_OBJECT_KEYS) {
        var more = el('div', null, '... ' + (keys.length - MAX_OBJECT_KEYS) + ' more');
        more.style.color = '#8b949e';
        detail.appendChild(more);
      }
      function toggleFn(e) {
        if (e) e.stopPropagation();
        var open = detail.style.display !== 'none';
        detail.style.display = open ? 'none' : 'block';
        toggle.textContent = open ? '> ' : 'v ';
      }
      toggle.onclick = toggleFn;
      preview.onclick = toggleFn;
      wrap.appendChild(toggle);
      wrap.appendChild(preview);
      wrap.appendChild(detail);
      return wrap;
    }
    var span = el('span');
    span.textContent = typeof v === 'string' ? '"' + v + '"' : shortVal(v);
    span.style.color = {
      string: '#ce9178', number: '#b5cea8', boolean: '#569cd6',
      function: '#dcdcaa', symbol: '#c586c0'
    }[typeof v] || '#9cdcfe';
    return span;
  }

  function renderNetwork() {
    if (!dev.panel) return;
    var host = dev.panel.querySelector('#dt-network');
    if (!host) return;
    host.innerHTML = '';
    var q = (dev.networkFilter || '').toLowerCase();
    var list = dev.network.filter(function(n) {
      return !q || String(n.url || '').toLowerCase().indexOf(q) >= 0;
    });
    if (!list.length) {
      host.innerHTML = '<div class="dt-empty">' + esc(L.noNet) + '</div>';
      return;
    }
    var frag = document.createDocumentFragment();
    list.slice().reverse().forEach(function(n) {
      var cls = n.status === 0 ? 'pending' : (n.status === -1 || n.status >= 400 ? 'err' : 'ok');
      var st = n.status === 0 ? '...' : (n.status === -1 ? 'ERR' : n.status);
      var row = el('div', 'dt-net-row');
      row.style.cursor = 'pointer';
      row.title = 'Double-click to copy URL';
      row.innerHTML =
        '<span class="dt-method">' + esc(n.method) + '</span>' +
        '<span class="dt-status ' + cls + '">' + st + '</span>' +
        '<span class="dt-url" title="' + esc(n.url) + '">' + esc(n.url) + '</span>' +
        '<span class="dt-type">' + esc(n.type) + '</span>' +
        '<span class="dt-dur">' + n.time + 'ms</span>';

      row.onclick = function(e) {
        showNetDetails(n);
      };

      row.ondblclick = function(e) {
        copyText(n.url);
      };

      frag.appendChild(row);
    });
    host.appendChild(frag);
  }

  function showNetDetails(n) {
    var modal = el('div', 'dt-modal');
    var box = el('div', 'dt-modal-box');
    box.innerHTML = '<div class="dt-modal-head">' +
      '<span class="dt-method">' + esc(n.method) + '</span>' +
      '<span class="dt-url-full">' + esc(n.url) + '</span>' +
      '<button class="dt-x">x</button></div>';
    var tabs = el('div', 'dt-modal-tabs');
    var content = el('div', 'dt-modal-body');
    var tabList = ['headers','preview','response','timing'];
    var labels = { headers: L.headers, preview: L.preview, response: L.response, timing: L.timing };
    tabList.forEach(function(t, i) {
      var b = el('button', i === 0 ? 'active' : null, labels[t]);
      b.onclick = function() {
        Array.prototype.forEach.call(tabs.querySelectorAll('button'), function(x) { x.classList.remove('active'); });
        b.classList.add('active');
        renderNetTab(content, n, t);
      };
      tabs.appendChild(b);
    });
    box.appendChild(tabs);
    box.appendChild(content);
    modal.appendChild(box);
    modal.onclick = function(e) { if (e.target === modal) modal.remove(); };
    box.querySelector('.dt-x').onclick = function() { modal.remove(); };
    document.documentElement.appendChild(modal);
    renderNetTab(content, n, 'headers');
  }

  function renderNetTab(host, n, tab) {
    host.innerHTML = '';
    if (tab === 'headers') {
      host.innerHTML = '<div class="dt-sec">' + esc(L.general) + '</div>' +
        kv('URL', n.url) +
        kv('Method', n.method) +
        kv('Status', n.status + (n.status === -1 ? ' (failed)' : '')) +
        kv('Time', n.time + ' ms') +
        '<div class="dt-sec">' + esc(L.reqHeaders) + '</div>' +
        Object.keys(n.reqHeaders || {}).map(function(k) { return kv(k, n.reqHeaders[k]); }).join('') +
        '<div class="dt-sec">' + esc(L.resHeaders) + '</div>' +
        Object.keys(n.resHeaders || {}).map(function(k) { return kv(k, n.resHeaders[k]); }).join('');
    } else if (tab === 'preview') {
      var reqHeadersHtml = Object.keys(n.reqHeaders || {}).map(function(k) { return kv(k, n.reqHeaders[k]); }).join('');
      var reqBodyStr = n.reqBody;
      if (reqBodyStr !== null && typeof reqBodyStr === 'object') {
        try { reqBodyStr = JSON.stringify(reqBodyStr, null, 2); } catch(e) { reqBodyStr = String(reqBodyStr); }
      }
      var reqBodyHtml = reqBodyStr
        ? '<pre class="dt-code">' + esc(String(reqBodyStr).slice(0, 5000)) + '</pre>'
        : '<div class="dt-empty">No request body</div>';
      host.innerHTML = '<div class="dt-sec">' + esc(L.reqHeaders) + '</div>' +
                       (reqHeadersHtml || '<div class="dt-empty">' + esc(L.empty) + '</div>') +
                       '<div class="dt-sec">Request Body</div>' + reqBodyHtml;
    } else if (tab === 'response') {
      host.innerHTML = n.resBody
        ? '<pre class="dt-code">' + esc(n.resBody) + '</pre>'
        : '<div class="dt-empty">No response body</div>';
    } else if (tab === 'timing') {
      host.innerHTML =
        '<div class="dt-timing"><div class="dt-timing-bar" style="width:100%"></div>' +
        '<div class="dt-timing-label">Total: ' + n.time + ' ms</div></div>' +
        kv('Started', new Date(n.ts).toLocaleTimeString('en-GB'));
    }
  }

  function kv(k, v) {
    return '<div class="dt-kv"><span class="dt-k">' + esc(k) + '</span>' +
           '<span class="dt-v">' + esc(String(v)) + '</span></div>';
  }

  function buildSourceTree(sources) {
    var root = { name: 'root', type: 'folder', children: {}, items: [] };
    sources.forEach(function(s, idx) {
      var parts = String(s.path || 'file').split('/');
      var filename = parts.pop();
      var node = root;
      parts.forEach(function(p) {
        if (!p) return;
        if (!node.children[p]) {
          node.children[p] = { name: p, type: 'folder', children: {}, items: [] };
        }
        node = node.children[p];
      });
      node.items.push({ name: filename, source: s, index: idx });
    });
    return root;
  }

  function iconForType(t) {
    if (t === 'html') return '📄';
    if (t === 'js') return '📜';
    if (t === 'css') return '🎨';
    if (t === 'img') return '🖼';
    return '📄';
  }

  function getFolderFiles(node) {
    var files = [];
    if (node.items) {
      node.items.forEach(function(i) { files.push(i.index); });
    }
    if (node.children) {
      Object.keys(node.children).forEach(function(k) {
        files = files.concat(getFolderFiles(node.children[k]));
      });
    }
    return files;
  }

  function renderSourceTreeHtml(node, depth, searchQuery) {
    var html = '';
    var indent = depth * 16;

    var folderNames = Object.keys(node.children).sort();
    folderNames.forEach(function(fname) {
      var child = node.children[fname];
      var folderId = 'f_' + Math.random().toString(36).substr(2, 9);
      var files = getFolderFiles(child);

      if (searchQuery && fname.toLowerCase().indexOf(searchQuery) === -1 && files.length === 0) return;

      html += '<div class="dt-src-folder" data-folder="' + folderId + '" data-folder-name="' + esc(fname) + '" style="padding-left:' + indent + 'px; display:flex; align-items:center;">';
      html += '<span class="dt-folder-toggle">▸</span>';
      html += '<span class="dt-folder-icon">📁</span>';
      html += '<span class="dt-folder-name" style="flex:1;">' + esc(fname) + '</span>';
      html += '<span class="dt-folder-dl" data-files="' + files.join(',') + '" title="Download Folder as ZIP" style="cursor:pointer; padding:0 8px; opacity:0.6;">📦</span>';
      html += '</div>';

      html += '<div class="dt-src-folder-children" id="' + folderId + '" style="display:none; padding-left:0;">';
      html += renderSourceTreeHtml(child, depth + 1, searchQuery);
      html += '</div>';
    });

    node.items.sort(function(a, b) { return a.name.localeCompare(b.name); });
    node.items.forEach(function(item) {
      var s = item.source;

      if (searchQuery) {
        var matchName = item.name.toLowerCase().indexOf(searchQuery) !== -1;
        var matchContent = false;
        if (!matchName) {
            if (s.content && s.content.toLowerCase().indexOf(searchQuery) !== -1) matchContent = true;
            else if (s.fetchedContent && s.fetchedContent.toLowerCase().indexOf(searchQuery) !== -1) matchContent = true;
        }
        if (!matchName && !matchContent) return;
      }

      var badgeClass = 'dt-badge-' + s.type;
      html += '<div class="dt-src-file" data-i="' + item.index + '" style="padding-left:' + indent + 'px; display:flex; align-items:center;">';
      html += '<span class="dt-file-icon">' + iconForType(s.type) + '</span>';
      html += '<span class="dt-badge ' + badgeClass + '">' + s.type.toUpperCase() + '</span>';
      html += '<span class="dt-src-name" style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">' + esc(item.name) + '</span>';
      html += '<span class="dt-src-dl" title="Download" style="cursor:pointer; padding:0 8px; opacity:0.6;">📥</span>';
      html += '</div>';
    });

    return html;
  }

  function downloadFileByIndex(idx) {
    var s = dev.sources[idx];
    if (!s) return;
    var fileName = s.path.split('/').pop() || 'download';

    if (s.content) {
      var blob = new Blob([s.content], {type: 'text/plain'});
      var fr = new FileReader();
      fr.onload = function() {
        if(window.Bridge && Bridge.saveBase64Download) {
          Bridge.saveBase64Download(String(fr.result).split(',')[1], fileName, 'text/plain');
        }
      };
      fr.readAsDataURL(blob);
    } else if (s.url) {
      if (window.Bridge && Bridge.downloadUrl) {
        Bridge.downloadUrl(s.url, fileName);
      } else {
        var a = document.createElement('a');
        a.href = s.url;
        a.download = fileName;
        a.click();
      }
    }
  }

  function sanitizeZipPath(p, idx) {
    var s = String(p == null ? '' : p).replace(/\\/g, '/').trim();
    s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//i, '');
    while (s.charAt(0) === '/') s = s.substring(1);
    s = s.replace(/[\x00-\x1f\x7f]/g, '');
    s = s.replace(/\.\./g, '_');
    while (s.length && s.charAt(s.length - 1) === '/') s = s.slice(0, -1);
    if (!s) s = 'file-' + idx;
    return s;
  }

  function loadJSZip() {
    return new Promise(function(resolve, reject) {
      if (typeof window.JSZip === 'function') return resolve(window.JSZip);
      if (window.__jszip_loading_promise) return window.__jszip_loading_promise;

      var p = new Promise(function(res, rej) {
        var script = document.createElement('script');
        script.src = 'https://appassets.androidplatform.net/jszip_js.js';
        script.async = true;
        var done = false;
        var finish = function(ok, err) {
          if (done) return;
          done = true;
          script.onload = script.onerror = null;
          try { script.remove(); } catch (e) {}
          if (ok && typeof window.JSZip === 'function') res(window.JSZip);
          else rej(err || new Error('JSZip not defined after script load'));
        };
        script.onload = function() { finish(true); };
        script.onerror = function() { finish(false, new Error('Script load failed')); };
        setTimeout(function() { finish(false, new Error('Timeout loading JSZip')); }, 10000);
        (document.head || document.documentElement).appendChild(script);
      });

      window.__jszip_loading_promise = p;
      p.then(function() {}, function() { window.__jszip_loading_promise = null; });
      return p;
    });
  }

  function downloadFolderZip(indices, folderName) {
    if (!indices.length) return;

    function doZip() {
      var zip = new window.JSZip();
      var addedPaths = {};
      var addedCount = 0;
      var failedCount = 0;

      function safeAdd(fullPath, data, opts) {
        var testPath = fullPath, n = 1;
        while (addedPaths[testPath]) {
          n++;
          var dot = fullPath.lastIndexOf('.');
          testPath = dot > 0
            ? fullPath.slice(0, dot) + '_' + n + fullPath.slice(dot)
            : fullPath + '_' + n;
        }
        fullPath = testPath;
        addedPaths[fullPath] = true;
        try {
          if (opts && opts.base64) zip.file(fullPath, data, { base64: true });
          else zip.file(fullPath, data);
          addedCount++;
        } catch (e) {
          failedCount++;
        }
      }

      var promises = indices.map(function(idx) {
        return new Promise(function(resolve) {
          var s = dev.sources[idx];
          if (!s) { failedCount++; return resolve(); }
          var fullPath = sanitizeZipPath(s.path, idx);

          if (s.content != null) {
            safeAdd(fullPath, String(s.content));
            return resolve();
          }
          if (s.fetchedContent != null) {
            safeAdd(fullPath, String(s.fetchedContent));
            return resolve();
          }
          if (!s.url) { failedCount++; return resolve(); }

          var ext = (fullPath.split('.').pop() || '').toLowerCase();
          var isBin = isBinaryFile(ext);
          var cbId = 'zip_' + Math.random().toString(36).substr(2, 9);
          if (!window.__devtools_zip_callbacks) window.__devtools_zip_callbacks = {};
          if (!window.__devtools_callbacks) window.__devtools_callbacks = {};

          var done = false;
          
          var addToZip = function(data) {
            if (done) return;
            done = true;
            delete window.__devtools_zip_callbacks[cbId];
            delete window.__devtools_callbacks[cbId];
            if (data == null) { failedCount++; return resolve(); }
            safeAdd(fullPath, data, isBin ? { base64: true } : null);
            resolve();
          };

          var handler = function(data) {
            if (done) return;
            if (data == null) {
              console.warn('Bridge failed, trying WebView fetch for:', s.url);
              fetch(s.url)
                .then(function(r) {
                  if (!r.ok) throw new Error('HTTP ' + r.status);
                  return isBin ? r.arrayBuffer() : r.text();
                })
                .then(function(resData) {
                  if (isBin) {
                    if (done) return;
                    done = true;
                    delete window.__devtools_zip_callbacks[cbId];
                    delete window.__devtools_callbacks[cbId];
                    safeAdd(fullPath, new Uint8Array(resData));
                    resolve();
                  } else {
                    addToZip(resData);
                  }
                })
                .catch(function(err) {
                  console.warn('Fetch fallback failed too:', err);
                  if (done) return;
                  done = true;
                  delete window.__devtools_zip_callbacks[cbId];
                  delete window.__devtools_callbacks[cbId];
                  failedCount++;
                  resolve();
                });
            } else {
              addToZip(data);
            }
          };

          window.__devtools_zip_callbacks[cbId] = handler;
          window.__devtools_callbacks[cbId] = handler;

          setTimeout(function() {
            if (done) return;
            done = true;
            delete window.__devtools_zip_callbacks[cbId];
            delete window.__devtools_callbacks[cbId];
            failedCount++;
            resolve();
          }, 15000);

          try {
            if (isBin && window.Bridge && Bridge.fetchBase64) Bridge.fetchBase64(s.url, cbId);
            else if (!isBin && window.Bridge && Bridge.fetchText) Bridge.fetchText(s.url, cbId);
            else { done = true; failedCount++; resolve(); }
          } catch (e) { done = true; failedCount++; resolve(); }
        });
      });

      Promise.all(promises).then(function() {
        if (addedCount === 0) { alert('No files added to ZIP (' + failedCount + ' failed)'); return; }
        return zip.generateAsync({
          type: 'base64',
          compression: 'DEFLATE',
          compressionOptions: { level: 9 }
        }).catch(function(err) {
          return zip.generateAsync({ type: 'base64', compression: 'STORE' });
        }).then(function(base64) {
          if (!base64 || base64.length < 30) { alert('Empty ZIP'); return; }
          if (window.Bridge && Bridge.saveBase64Download) {
            Bridge.saveBase64Download(base64, folderName + '.zip', 'application/zip');
          } else {
            alert('Bridge.saveBase64Download unavailable');
          }
        });
      }).catch(function(err) {
        alert('Zip failed: ' + (err && err.message ? err.message : err));
      });
    }

    loadJSZip().then(doZip).catch(function(err) {
      alert('JSZip load failed: ' + err.message);
    });
  }

  window.__devtools_onSourceBase64Loaded = function(cbId, base64) {
    var cb = (window.__devtools_zip_callbacks && window.__devtools_zip_callbacks[cbId])
          || (window.__devtools_callbacks && window.__devtools_callbacks[cbId]);
    if (cb) {
      delete window.__devtools_callbacks[cbId];
      delete window.__devtools_zip_callbacks[cbId];
      cb(base64);
    }
  };

  function attachTreeListeners(host) {
    host.querySelectorAll('.dt-src-folder').forEach(function(folder) {
      var dlBtn = folder.querySelector('.dt-folder-dl');
      if (dlBtn) {
        dlBtn.onclick = function(e) {
          e.preventDefault();
          e.stopPropagation();
          var files = dlBtn.getAttribute('data-files').split(',').filter(function(x){return x !== '';}).map(Number);
          var fname = folder.getAttribute('data-folder-name') || 'folder';
          downloadFolderZip(files, fname);
        };
      }

      folder.onclick = function(e) {
        e.preventDefault();
        e.stopPropagation();
        var folderId = folder.getAttribute('data-folder');
        var children = document.getElementById(folderId);
        if (children) {
          var isHidden = children.style.display === 'none';
          children.style.display = isHidden ? 'block' : 'none';
          var toggle = folder.querySelector('.dt-folder-toggle');
          if (toggle) toggle.textContent = isHidden ? '▾' : '▸';
        }
      };
    });

    host.querySelectorAll('.dt-src-file').forEach(function(file) {
      var dlBtn = file.querySelector('.dt-src-dl');
      if (dlBtn) {
        dlBtn.onclick = function(e) {
          e.preventDefault();
          e.stopPropagation();
          downloadFileByIndex(+file.dataset.i);
        };
      }

      file.onclick = function(e) {
        e.preventDefault();
        e.stopPropagation();
        host.querySelectorAll('.dt-src-file').forEach(function(x) { x.classList.remove('active'); });
        file.classList.add('active');
        var idx = +file.dataset.i;
        var s = dev.sources[idx];
        var v = document.getElementById('dt-src-view');
        if (!v) return;
        if (!s) { v.innerHTML = '<div class="dt-src-empty">Source not found</div>'; return; }

        try {
          var ext = (s.path.split('.').pop() || '').toLowerCase();

          if (s.content) {
            v.innerHTML = '<div class="dt-src-header">' +
              '<span class="dt-src-path">' + esc(s.path) + '</span>' +
              '</div>' +
              '<pre class="dt-src-pre">' + esc(s.content) + '</pre>';
          } else if (s.url) {
            var url = s.url;

            if (isBinaryFile(ext)) {
              var mediaHtml = '';
              if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'bmp'].indexOf(ext) !== -1) {
                mediaHtml = '<div style="padding:20px;text-align:center;background:#010409;"><img src="' + esc(url) + '" style="max-width:100%;max-height:400px;border-radius:8px;" /></div>';
              } else if (['mp4', 'webm', 'ogg'].indexOf(ext) !== -1) {
                mediaHtml = '<div style="padding:20px;text-align:center;background:#010409;"><video controls src="' + esc(url) + '" style="max-width:100%;max-height:400px;border-radius:8px;"></video></div>';
              } else if (['mp3', 'wav', 'aac', 'ogg', 'm4a'].indexOf(ext) !== -1) {
                mediaHtml = '<div style="padding:20px;text-align:center;background:#010409;"><audio controls src="' + esc(url) + '" style="width:100%;"></audio></div>';
              } else {
                mediaHtml = '<div class="dt-src-empty">Binary file (cannot display)</div>';
              }

              v.innerHTML = '<div class="dt-src-header">' +
                '<span class="dt-src-path">' + esc(s.path) + '</span>' +
                '</div>' + mediaHtml;
              return;
            }

            v.innerHTML = '<div class="dt-src-header">' +
              '<span class="dt-src-path">' + esc(s.path) + '</span>' +
              '<span class="dt-src-url-full">' + esc(url) + '</span>' +
              '</div>' +
              '<div class="dt-src-loading">Loading...</div>';

            var cbId = 'cb_' + Math.random().toString(36).substr(2, 9);
            if (!window.__devtools_callbacks) window.__devtools_callbacks = {};
            window.__devtools_callbacks[cbId] = function(text) {
              if (text === null) {
                v.innerHTML = '<div class="dt-src-header">' +
                  '<span class="dt-src-path">' + esc(s.path) + '</span>' +
                  '<span class="dt-src-url-full">' + esc(url) + '</span>' +
                  '</div>' +
                  '<div class="dt-src-empty">Cannot load resource (CORS or Network Error)</div>';
              } else {
                s.fetchedContent = text;
                v.innerHTML = '<div class="dt-src-header">' +
                  '<span class="dt-src-path">' + esc(s.path) + '</span>' +
                  '<span class="dt-src-url-full">' + esc(url) + '</span>' +
                  '</div>' +
                  '<pre class="dt-src-pre">' + esc(text) + '</pre>';
              }
            };

            if (window.Bridge && Bridge.fetchText) {
              Bridge.fetchText(s.url, cbId);
            } else {
              v.innerHTML = '<div class="dt-src-empty">Bridge not available</div>';
            }

          } else {
            v.innerHTML = '<div class="dt-src-empty">' + esc(L.external) + '</div>';
          }
        } catch (err) {
          v.innerHTML = '<div class="dt-src-empty">Error: ' + esc(err.message) + '</div>';
        }
      };
    });
  }

  function updateSourceTree(searchQuery) {
    var treeContainer = dev.panel.querySelector('.dt-src-tree');
    if (!treeContainer) return;
    treeContainer.innerHTML = renderSourceTreeHtml(buildSourceTree(dev.sources), 0, searchQuery.toLowerCase());
    attachTreeListeners(treeContainer);
  }

  function renderSources() {
    var host = dev.panel && dev.panel.querySelector('#dt-sources');
    if (!host) return;

    if (!host.querySelector('#dt-src-search')) {
      var html = '';
      html += '<div class="dt-src-toolbar" style="display:flex; gap:8px; padding:8px;">';
      html += '<input id="dt-src-search" type="text" placeholder="Search files and contents..." style="flex:1; padding:6px 10px; background:#0d1117; border:1px solid #30363d; border-radius:6px; color:#eaf0fa; font-family:inherit; font-size:12px; outline:none;">';
      html += '<button class="dt-src-refresh" id="dt-src-refresh">Refresh</button>';
      html += '</div>';
      html += '<div class="dt-src-tree"></div>';
      html += '<div id="dt-src-view" class="dt-src-view"><div class="dt-src-empty">Select a file to view</div></div>';
      host.innerHTML = html;

      var searchInput = document.getElementById('dt-src-search');
      if (searchInput) {
        searchInput.oninput = function() { updateSourceTree(searchInput.value); };
        searchInput.onclick = function(e) { e.stopPropagation(); };
      }

      var refresh = document.getElementById('dt-src-refresh');
      if (refresh) {
        refresh.onclick = function(e) {
          if(e) e.preventDefault();
          collectSources();
          updateSourceTree(searchInput ? searchInput.value : '');
        };
      }
    }

    if (!dev.sources.length) collectSources();
    var currentVal = (document.getElementById('dt-src-search') || {}).value || '';
    updateSourceTree(currentVal);
  }

  function clearHighlights() {
    document.querySelectorAll('.dt-highlight, .dt-selected').forEach(function(el) {
      el.classList.remove('dt-highlight', 'dt-selected');
      try {
        el.style.outline = '';
        el.style.boxShadow = '';
      } catch (e) {}
    });
  }

  function renderElements() {
    if (!dev.panel) return;
    var host = dev.panel.querySelector('#dt-elements');
    if (!host) return;
    host.innerHTML = '';
    var tree = el('div', 'dt-tree');
    host.appendChild(tree);
    var renderedNodes = 0;
    var maxRenderedNodes = 2500;

    function isDevToolsNode(node) {
      if (!node || node.nodeType !== 1) return false;
      if (node === dev.panel || dev.panel.contains(node)) return true;
      if (node.hasAttribute('data-devtools-root')) return true;
      if (node.closest && node.closest('[data-devtools-root]')) return true;
      return false;
    }

    function getChildren(node, tagName) {
      if (tagName === 'script' || tagName === 'style') return [];
      if (tagName === 'iframe') {
        try {
          var frameDoc = node.contentDocument;
          return frameDoc && frameDoc.documentElement ? [frameDoc.documentElement] : [];
        } catch (e) {
          return [];
        }
      }
      return Array.from(node.children || []).filter(function(child) {
        return !isDevToolsNode(child);
      });
    }

    function walk(node, depth, sourceDocument, path) {
      if (!node || node.nodeType !== 1 || isDevToolsNode(node)) return null;
      renderedNodes++;
      if (renderedNodes > maxRenderedNodes) return el('div', 'dt-empty-state', 'Tree limited to ' + maxRenderedNodes + ' elements.');

      var tagName = node.tagName.toLowerCase();
      var wrap = el('div', 'dt-el-wrap');
      var row = el('div', 'dt-el');
      row.style.paddingLeft = (Math.min(depth, 40) * 14) + 'px';

      var tag = el('span', 'dt-el-tag');
      tag.innerHTML = '&lt;<span class="dt-el-name">' + esc(tagName) + '</span>' + Array.from(node.attributes || []).map(function(a) {
        return ' <span class="dt-el-attr">' + esc(a.name) + '</span>="<span class="dt-el-val">' + esc(a.value) + '</span>"';
      }).join('') + '&gt;';

      var children = getChildren(node, tagName);
      var hasSource = tagName === 'script' || tagName === 'style';
      var frameBlocked = tagName === 'iframe' && !children.length;

      var textContent = '';
      if (!hasSource && !frameBlocked) {
        for (var i = 0; i < node.childNodes.length; i++) {
          if (node.childNodes[i].nodeType === 3) {
            textContent += node.childNodes[i].textContent.trim() + ' ';
          }
        }
        textContent = textContent.trim();
      }

      var isVoid = ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'].indexOf(tagName) >= 0;
      var canExpand = children.length > 0 || hasSource || frameBlocked || textContent.length > 0;

      if (isVoid) canExpand = false;

      var isExpanded = dev.elementsExpanded[path] === true;
      var toggle = el('button', 'dt-el-toggle', canExpand ? (isExpanded ? '▾' : '▸') : '·');
      toggle.type = 'button';

      row.appendChild(toggle);
      row.appendChild(tag);
      if (isVoid) {
        row.appendChild(el('span', 'dt-void-tag', ' (void)'));
      }
      wrap.appendChild(row);

      var kids = el('div', 'dt-el-kids');
      kids.hidden = !isExpanded;
      var built = false;

      function buildChildren() {
        if (built) return;
        built = true;

        if (hasSource) {
          var sourceText = node.textContent || '';
          if (sourceText.trim().length === 0) {
            kids.appendChild(el('div', 'dt-empty-state', 'Empty source'));
          } else {
            var pre = el('pre', 'dt-element-source');
            pre.textContent = sourceText;
            kids.appendChild(pre);
          }
        } else if (frameBlocked) {
          kids.appendChild(el('div', 'dt-frame-unavailable', 'Iframe unavailable.'));
        } else {
          if (textContent.length > 0) {
            var textNode = el('div', 'dt-text-node', '"' + textContent + '"');
            kids.appendChild(textNode);
          }

          children.forEach(function(child, index) {
            if (renderedNodes >= maxRenderedNodes) {
              kids.appendChild(el('div', 'dt-empty-state', 'Tree limited.'));
              return;
            }
            var childPath = path + '>' + index;
            var childView = walk(child, depth + 1, sourceDocument, childPath);
            if (childView) kids.appendChild(childView);
          });
        }
      }

      if (canExpand) {
        if (isExpanded) buildChildren();

        toggle.onclick = function(e) {
          e.preventDefault();
          e.stopPropagation();
          if (!built) buildChildren();
          kids.hidden = !kids.hidden;
          toggle.textContent = kids.hidden ? '▸' : '▾';
          dev.elementsExpanded[path] = !kids.hidden;
        };
        row.onclick = function(e) {
          e.preventDefault();
          e.stopPropagation();
          if (e.target === toggle) return;
          if (!built) buildChildren();
          kids.hidden = !kids.hidden;
          toggle.textContent = kids.hidden ? '▸' : '▾';
          dev.elementsExpanded[path] = !kids.hidden;
        };
        wrap.appendChild(kids);
      }

      row.onmouseenter = function() {
        if (dev.elementsSelected === node) return;
        try { node.classList.add('dt-highlight'); } catch (e) {}
      };
      row.onmouseleave = function() {
        if (dev.elementsSelected === node) return;
        try { node.classList.remove('dt-highlight'); } catch (e) {}
      };
      row.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
         if (e.target === toggle) return;
         if (dev.elementsSelected && dev.elementsSelected !== node) {
        try { dev.elementsSelected.classList.remove('dt-selected'); } catch (err) {}
      }
      dev.elementsSelected = node;
        try { node.classList.add('dt-selected'); } catch (err) {}
      });

      row.addEventListener('dblclick', function(e) {
       e.preventDefault();
       e.stopPropagation();
       copyText(node.outerHTML);
      });
      return wrap;
    }

    var root = document.documentElement;
    if (!root) {
      tree.appendChild(el('div', 'dt-empty-state', 'No document available.'));
      return;
    }
    var rootView = walk(root, 0, document, '0');
    if (rootView) tree.appendChild(rootView);
  }

  function showModal(title, contentHTML) {
    var modal = el('div', 'dt-modal');
    var box = el('div', 'dt-modal-box');
    box.innerHTML = '<div class="dt-modal-head">' +
      '<span class="dt-url-full">' + esc(title) + '</span>' +
      '<button class="dt-x">x</button></div>' +
      '<div class="dt-modal-body">' + contentHTML + '</div>';
    modal.appendChild(box);
    modal.onclick = function(e) { if (e.target === modal) modal.remove(); };
    box.querySelector('.dt-x').onclick = function() { modal.remove(); };
    document.documentElement.appendChild(modal);
  }

  function openAndShowObjectStore(dbName, storeName) {
    if (!window.indexedDB) {
      showModal('Error', 'IndexedDB not supported');
      return;
    }
    var req = indexedDB.open(dbName);
    req.onsuccess = function(e) {
      var db = e.target.result;
      try {
        var tx = db.transaction(storeName, 'readonly');
        var store = tx.objectStore(storeName);
        var getAllReq = store.getAll();

        getAllReq.onsuccess = function() {
          var records = getAllReq.result;
          if (!records || !records.length) {
            showModal('Object Store: ' + storeName, '<div class="dt-empty">Empty Store</div>');
            db.close();
            return;
          }

          var keysReq = store.getAllKeys();
          keysReq.onsuccess = function() {
            var keys = keysReq.result;
            var html = '<div class="dt-sec">Object Store: ' + esc(storeName) + ' (' + records.length + ' records)</div>';
            html += '<table class="dt-table"><thead><tr><th style="width:30%;">Key</th><th style="width:70%;">Value</th></tr></thead><tbody>';

            for (var i = 0; i < records.length; i++) {
              var key = keys[i];
              var val = records[i];
              var valStr = typeof val === 'object' ? JSON.stringify(val, null, 2) : String(val);
              html += '<tr><td class="dt-k">' + esc(String(key)) + '</td>' +
                      '<td class="dt-v" style="white-space: pre-wrap; word-break: break-word;">' + esc(valStr) + '</td></tr>';
            }
            html += '</tbody></table>';
            showModal('IndexedDB: ' + dbName + ' > ' + storeName, html);
            db.close();
          };

          keysReq.onerror = function() {
            showModal('Error', 'Error reading keys');
            db.close();
          };
        };

        getAllReq.onerror = function() {
          showModal('Error', 'Error reading data from store: ' + storeName);
          db.close();
        };

      } catch (err) {
        showModal('Error', 'Error accessing object store: ' + err.message);
        db.close();
      }
    };

    req.onerror = function() {
      showModal('Error', 'Error opening database: ' + dbName);
    };
  }

  function renderApplication() {
    if (!dev.panel) return;
    var host = dev.panel.querySelector('#dt-application');
    if (!host) return;
    var previousSelection = host.querySelector('.dt-app-item.active');
    var selectedSection = previousSelection ? previousSelection.dataset.s : null;
    host.innerHTML = '';
    var layout = el('div', 'dt-app-layout');
    var sidebar = el('div', 'dt-app-side');
    var sections = ['localStorage', 'sessionStorage', 'cookies', 'indexedDB'];
    var labels = {
      localStorage: L.localStorage, sessionStorage: L.sessionStorage,
      cookies: L.cookies, indexedDB: L.indexedDB
    };
    var counts = {
      localStorage: Object.keys(dev.storage.local).length,
      sessionStorage: Object.keys(dev.storage.session).length,
      cookies: dev.storage.cookies.length,
      indexedDB: dev.storage.idb.length
    };
    sidebar.innerHTML = sections.map(function(s) {
      return '<div class="dt-app-item" data-s="' + s + '">' +
        '<span class="dt-app-name">' + esc(labels[s]) + '</span>' +
        '<span class="dt-app-count">' + counts[s] + '</span></div>';
    }).join('');
    var viewer = el('div', 'dt-app-viewer');
    sidebar.querySelectorAll('.dt-app-item').forEach(function(item) {
      item.onclick = function(e) {
        if(e) e.preventDefault();
        sidebar.querySelectorAll('.dt-app-item').forEach(function(x){ x.classList.remove('active'); });
        item.classList.add('active');
        var s = item.dataset.s;
        viewer.innerHTML = '';
        if (s === 'localStorage' || s === 'sessionStorage') {
          var data = dev.storage[s === 'localStorage' ? 'local' : 'session'];
          var keys = Object.keys(data);
          if (!keys.length) { viewer.innerHTML = '<div class="dt-empty">' + esc(L.empty) + '</div>'; return; }
          viewer.innerHTML = '<table class="dt-table"><thead><tr>' +
            '<th>' + esc(L.key) + '</th><th>' + esc(L.value) + '</th></tr></thead><tbody>' +
            keys.map(function(k) {
              return '<tr><td class="dt-k">' + esc(k) + '</td>' +
                '<td class="dt-v">' + esc(String(data[k])).slice(0, 200) + '</td></tr>';
            }).join('') + '</tbody></table>';
        } else if (s === 'cookies') {
          var cs = dev.storage.cookies;
          if (!cs.length) { viewer.innerHTML = '<div class="dt-empty">' + esc(L.empty) + '</div>'; return; }
          viewer.innerHTML = '<table class="dt-table"><thead><tr>' +
            '<th>' + esc(L.name) + '</th><th>' + esc(L.value) + '</th></tr></thead><tbody>' +
            cs.map(function(c) {
              return '<tr><td class="dt-k">' + esc(c.name) + '</td>' +
                '<td class="dt-v">' + esc(c.value).slice(0, 200) + '</td></tr>';
            }).join('') + '</tbody></table>';
        } else {
          var dbs = dev.storage.idb;
          if (!dbs.length) {
            viewer.innerHTML = '<div class="dt-empty">' + esc(L.empty) + '</div>';
            return;
          }

          viewer.innerHTML = '<table class="dt-table"><thead><tr>' +
            '<th style="width: 25%;">' + esc(L.name) + '</th><th style="width: 15%;">Version</th><th style="width: 60%;">Object Stores</th></tr></thead><tbody>' +
            dbs.map(function(d) {
              return '<tr data-dbname="' + esc(d.name) + '">' +
                '<td class="dt-k">' + esc(d.name) + '</td>' +
                '<td class="dt-v">' + (d.version || '?') + '</td>' +
                '<td class="dt-v db-stores-cell"><span class="dt-db-loading">Loading...</span></td></tr>';
            }).join('') + '</tbody></table>';

          viewer.querySelectorAll('tr[data-dbname]').forEach(function(tr) {
            var dbName = tr.getAttribute('data-dbname');
            var storeCell = tr.querySelector('.db-stores-cell');

            if (!window.indexedDB) {
              storeCell.textContent = 'IndexedDB not supported';
              return;
            }

            var req = indexedDB.open(dbName);
            req.onsuccess = function(e) {
              var db = e.target.result;
              try {
                var stores = Array.from(db.objectStoreNames);
                if (stores.length) {
                  storeCell.innerHTML = '<div class="dt-db-store-container">' + stores.map(function(s) {
                    return '<span class="dt-db-store" data-db="' + esc(dbName) + '" data-store="' + esc(s) + '">' + esc(s) + '</span>';
                  }).join('') + '</div>';

                  storeCell.querySelectorAll('.dt-db-store').forEach(function(storeEl) {
                    storeEl.onclick = function(e) {
                      if(e) e.preventDefault();
                      openAndShowObjectStore(this.getAttribute('data-db'), this.getAttribute('data-store'));
                    };
                  });

                } else {
                  storeCell.textContent = 'No stores';
                }
              } catch (err) {
                storeCell.textContent = 'Error reading stores';
              }
              db.close();
            };

            req.onerror = function() {
              storeCell.textContent = 'Error opening DB';
            };
          });
        }
      };
    });

    layout.appendChild(sidebar);
    layout.appendChild(viewer);
    host.appendChild(layout);
    var target = selectedSection ? sidebar.querySelector('.dt-app-item[data-s="' + selectedSection + '"]') : null;
    if (!target) target = sidebar.querySelector('.dt-app-item');
    if (target) target.click();
  }

  function renderPerformance() {
    if (!dev.panel) return;
    var host = dev.panel.querySelector('#dt-performance');
    if (!host) return;
    var t = performance.timing || {};
    var nav = performance.navigation || {};
    var mem = performance.memory || {};
    var base = t.navigationStart || 0;
    var items = [
      ['Navigation Start', base ? new Date(base).toLocaleString() : '-'],
      ['DOM Loading', base ? (t.domLoading - base) + ' ms' : '-'],
      ['DOM Interactive', base ? (t.domInteractive - base) + ' ms' : '-'],
      ['DOM Complete', base ? (t.domComplete - base) + ' ms' : '-'],
      ['Load Event', base ? (t.loadEventEnd - base) + ' ms' : '-'],
      ['Redirect Count', nav.redirectCount || 0],
      ['Navigation Type', nav.type != null ? nav.type : '-'],
      ['Used JS Heap', mem.usedJSHeapSize ? (mem.usedJSHeapSize / 1048576).toFixed(2) + ' MB' : '-'],
      ['Total JS Heap', mem.totalJSHeapSize ? (mem.totalJSHeapSize / 1048576).toFixed(2) + ' MB' : '-'],
      ['JS Heap Limit', mem.jsHeapSizeLimit ? (mem.jsHeapSizeLimit / 1048576).toFixed(2) + ' MB' : '-']
    ];
    host.innerHTML = '<table class="dt-table"><tbody>' +
      items.map(function(it) {
        return '<tr><td class="dt-k">' + esc(it[0]) + '</td>' +
          '<td class="dt-v">' + esc(String(it[1])) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function runCmd(input) {
    var code = input.value.trim();
    if (!code) return;
    dev.cmdHistory.push(code);
    if (dev.cmdHistory.length > MAX_COMMAND_HISTORY) dev.cmdHistory.shift();
    dev.cmdIndex = dev.cmdHistory.length;
    console.log('> ' + code);
    try {
      var r = (0, eval)(code);
      var out;
      try {
        out = (typeof r === 'object' && r !== null) ? JSON.stringify(r) : String(r);
      } catch (_) { out = String(r); }
      if (out && out.length > CMD_STRING_LIMIT) out = out.slice(0, CMD_STRING_LIMIT) + '...';
      console.log('< ' + out);
    } catch (e) {
      console.error(e.message);
    }
    input.value = '';
    renderConsole();
    var host = dev.panel.querySelector('#dt-console');
    if (host) host.scrollTop = host.scrollHeight;
  }

  function switchTab(p, tabId) {
    if (dev.activeTab === tabId) return;
    dev.activeTab = tabId;
    clearHighlights();

    p.classList.remove('tab-console', 'tab-sources', 'tab-network', 'tab-elements', 'tab-application', 'tab-performance');
    p.classList.add('tab-' + tabId);

    p.querySelectorAll('#devtools-tabs button[data-tab]').forEach(function(b) {
      if (b.getAttribute('data-tab') === tabId) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });

    p.querySelectorAll('.dt-tab').forEach(function(tab) {
      if (tab.id === 'dt-' + tabId) {
        tab.classList.add('active');
        tab.style.display = 'flex';
      } else {
        tab.classList.remove('active');
        tab.style.display = 'none';
      }
    });

    renderActive();
  }

  function buildPanel() {
    var p = el('div');
    p.id = 'devtools-panel';
    p.classList.add('tab-console');

    var tabsBar = el('div');
    tabsBar.id = 'devtools-tabs';
    var tabs = [
      { id: 'console',     l: L.console },
      { id: 'sources',     l: L.sources },
      { id: 'network',     l: L.network },
      { id: 'elements',    l: L.elements },
      { id: 'application', l: L.application },
      { id: 'performance', l: L.performance }
    ];
    tabs.forEach(function(t, i) {
      var b = el('button', i === 0 ? 'active' : null, t.l);
      b.setAttribute('data-tab', t.id);
      b.setAttribute('type', 'button');
      b.onclick = function(e) {
        if(e) { e.preventDefault(); e.stopPropagation(); }
        switchTab(p, t.id);
        return false;
      };
      b.addEventListener('touchend', function(e) {
        e.preventDefault();
        e.stopPropagation();
        switchTab(p, t.id);
        return false;
      }, { passive: false });
      tabsBar.appendChild(b);
    });

    var closeBtn = el('button', 'dt-btn', L.close);
    closeBtn.title = L.close;
    closeBtn.setAttribute('type', 'button');
    closeBtn.onclick = function(e) {
      if(e) { e.preventDefault(); e.stopPropagation(); }
      toggle(false);
      return false;
    };
    tabsBar.appendChild(closeBtn);

    p.appendChild(tabsBar);

    var content = el('div');
    content.id = 'devtools-content';
    ['console','sources','network','elements','application','performance'].forEach(function(id, i) {
      var tab = el('div', 'dt-tab' + (i === 0 ? ' active' : ''));
      tab.id = 'dt-' + id;
      tab.style.display = i === 0 ? 'flex' : 'none';
      content.appendChild(tab);
    });
    p.appendChild(content);

    var filterBar = el('div', 'dt-filter-bar');

    var searchInput = el('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Search logs...';
    searchInput.style.cssText = 'flex:1; margin-right:8px; padding:4px 8px; background:#0d1117; border:1px solid #30363d; border-radius:4px; color:#eaf0fa; font-size:11px; font-family:inherit; outline:none;';
    searchInput.oninput = function() { dev.consoleSearch = searchInput.value; renderConsole(); };
    filterBar.appendChild(searchInput);

    var filtersDiv = el('div');
    filtersDiv.style.cssText = 'display:flex; gap:2px;';
    ['all','log','info','warn','error','debug'].forEach(function(f) {
      var b = el('button', f === 'all' ? 'active' : null, f);
      b.setAttribute('type', 'button');
      b.onclick = function(e) {
        if(e) e.preventDefault();
        dev.consoleFilter = f;
        filtersDiv.querySelectorAll('button').forEach(function(x) { x.classList.remove('active'); });
        b.classList.add('active');
        renderConsole();
        return false;
      };
      filtersDiv.appendChild(b);
    });
    filterBar.appendChild(filtersDiv);

    var copyAllBtn = el('button', 'dt-btn', 'Copy All');
    copyAllBtn.title = 'Copy all logs';
    copyAllBtn.style.marginLeft = 'auto';
    copyAllBtn.setAttribute('type', 'button');
    copyAllBtn.onclick = function(e) {
      if(e) e.preventDefault();
      var txt = dev.logs.map(function(l) {
        return l.time + ' [' + l.level.toUpperCase() + '] ' + l.args.map(fmtVal).join(' ');
      }).join('\n');
      copyText(txt);
      return false;
    };
    filterBar.appendChild(copyAllBtn);

    var clearBtn = el('button', 'dt-btn', L.clear);
    clearBtn.title = 'Clear';
    clearBtn.setAttribute('type', 'button');
    clearBtn.onclick = function(e) {
      if(e) e.preventDefault();
      if (dev.activeTab === 'console') dev.logs = [];
      else if (dev.activeTab === 'network') dev.network = [];
      renderActive();
      return false;
    };
    filterBar.appendChild(clearBtn);
    p.appendChild(filterBar);

    var netBar = el('div', 'dt-filter-bar');
    netBar.id = 'dt-net-bar';
    netBar.style.display = 'none';
    var netSearch = el('input');
    netSearch.type = 'text';
    netSearch.placeholder = 'Filter URLs...';
    netSearch.style.cssText = 'flex:1; margin-right:8px; padding:4px 8px; background:#0d1117; border:1px solid #30363d; border-radius:4px; color:#eaf0fa; font-size:11px; font-family:inherit; outline:none;';
    netSearch.oninput = function() { dev.networkFilter = netSearch.value; renderNetwork(); };
    netBar.appendChild(netSearch);

    var copyNetBtn = el('button', 'dt-btn', 'Copy JSON');
    copyNetBtn.title = 'Copy network as JSON';
    copyNetBtn.setAttribute('type', 'button');
    copyNetBtn.onclick = function(e) {
      if(e) e.preventDefault();
      var arr = dev.network.map(function(n) { return { status: n.status, url: n.url }; });
      copyText(JSON.stringify(arr, null, 2));
      return false;
    };
    netBar.appendChild(copyNetBtn);

    p.appendChild(netBar);

    var cmdRow = el('div');
    cmdRow.id = 'devtools-cmd-row';
    var prompt = el('span', 'dt-prompt', '>');
    var input = el('input');
    input.id = 'dt-input';
    input.type = 'text';
    input.placeholder = L.placeholder;
    input.setAttribute('autocomplete', 'off');
    input.setAttribute('spellcheck', 'false');
    input.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') { e.preventDefault(); runCmd(input); }
      else if (e.key === 'ArrowUp') {
        if (dev.cmdIndex > 0) { dev.cmdIndex--; input.value = dev.cmdHistory[dev.cmdIndex]; }
      } else if (e.key === 'ArrowDown') {
        if (dev.cmdIndex < dev.cmdHistory.length - 1) { dev.cmdIndex++; input.value = dev.cmdHistory[dev.cmdIndex]; }
        else { dev.cmdIndex = dev.cmdHistory.length; input.value = ''; }
      }
    });
    var runBtn = el('button', 'dt-btn primary', L.run);
    runBtn.setAttribute('type', 'button');
    runBtn.onclick = function(e) {
      if(e) e.preventDefault();
      runCmd(input);
      return false;
    };
    cmdRow.appendChild(prompt);
    cmdRow.appendChild(input);
    cmdRow.appendChild(runBtn);
    p.appendChild(cmdRow);

    document.documentElement.appendChild(p);
    dev.panel = p;

    if (dev.scc) { clearInterval(dev.scc); dev.scc = null; }
    var rebuildCount = 0;
    dev.startWatchdog = function() {
      if (dev.scc) return;
      rebuildCount = 0;
      dev.scc = setInterval(function() {
        if (!document.documentElement.contains(p)) {
          document.documentElement.appendChild(p);
          rebuildCount++;
          if (rebuildCount > REBUILD_LIMIT) {
            clearInterval(dev.scc);
            dev.scc = null;
          }
        }
      }, 800);
    };
  }

  function renderActive() {
    var p = dev.panel;
    if (!p) return;

    var filterBar = p.querySelector('.dt-filter-bar');
    var netBar = p.querySelector('#dt-net-bar');
    var cmdRow = p.querySelector('#devtools-cmd-row');

    if (dev.activeTab === 'console') {
      if(filterBar) filterBar.style.display = 'flex';
      if(netBar) netBar.style.display = 'none';
      if(cmdRow) cmdRow.style.display = 'flex';
      renderConsole();
    } else if (dev.activeTab === 'network') {
      if(filterBar) filterBar.style.display = 'none';
      if(netBar) netBar.style.display = 'flex';
      if(cmdRow) cmdRow.style.display = 'none';
      renderNetwork();
    } else {
      if(filterBar) filterBar.style.display = 'none';
      if(netBar) netBar.style.display = 'none';
      if(cmdRow) cmdRow.style.display = 'none';
      if (dev.activeTab === 'sources') renderSources();
      else if (dev.activeTab === 'elements') renderElements();
      else if (dev.activeTab === 'application') renderApplication();
      else if (dev.activeTab === 'performance') renderPerformance();
    }
  }

  function toggle(force) {
    if (!dev.panel) buildPanel();
    dev.visible = (force !== undefined) ? force : !dev.visible;
    if (dev.visible) {
      dev.panel.classList.add('show');
      if (typeof dev.startWatchdog === 'function') dev.startWatchdog();
      if (dev.activeTab === 'sources' && !dev.sources.length) collectSources();
      if (dev.activeTab === 'application') collectStorage();
      renderActive();
    } else {
      dev.panel.classList.remove('show');
      if (dev.scc) { clearInterval(dev.scc); dev.scc = null; }
      clearHighlights();
    }
  }

  dev.toggle = function() { toggle(); };
  dev.show = function() { toggle(true); };
  dev.hide = function() { toggle(false); };

  window.__devtools_onSourceLoaded = function(cbId, text) {
    var cb = (window.__devtools_callbacks && window.__devtools_callbacks[cbId])
          || (window.__devtools_zip_callbacks && window.__devtools_zip_callbacks[cbId]);
    if (cb) {
      delete window.__devtools_callbacks[cbId];
      delete window.__devtools_zip_callbacks[cbId];
      cb(text);
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { collectSources(); collectStorage(); });
  } else {
    collectSources();
    collectStorage();
  }

  return 'injected';
})();