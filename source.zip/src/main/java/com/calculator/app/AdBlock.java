package com.calculator.app;

import android.content.Context;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import android.webkit.WebResourceResponse;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdBlock {
  private static final Set<String> hosts = new HashSet<>(200000);
  private static final CountDownLatch loadedLatch = new CountDownLatch(1);
  private static Context appContext;
  private static volatile boolean isLoadingList = false;
  private static volatile boolean isListLoaded = false;

  private static final Set<String> whitelist = new HashSet<>(Arrays.asList(
      "google.com", "www.google.com", "gstatic.com", "googleapis.com",
      "google.co.ir", "google.co.uk", "googleusercontent.com",
      "youtube.com", "www.youtube.com", "youtu.be", "ytimg.com", "ggpht.com",
      "youtubei.googleapis.com", "gmail.com", "mail.google.com", "drive.google.com",
      "cloudflare.com", "cdnjs.cloudflare.com", "jsdelivr.net",
      "cdn.jsdelivr.net", "unpkg.com", "bootstrapcdn.com",
      "maxcdn.bootstrapcdn.com", "fontawesome.com", "use.fontawesome.com",
      "recaptcha.net", "www.recaptcha.net",
      "github.com", "githubusercontent.com", "raw.githubusercontent.com",
      "stackoverflow.com", "wikipedia.org", "wikimedia.org",
      "bing.com", "www.bing.com", "microsoft.com",
      "apple.com", "icloud.com", "mozilla.org", "mozilla.net",
      "androidplatform.net", "appassets.androidplatform.net"
  ));

  private static final Pattern suspiciousHostPattern = Pattern.compile(
      "(^|\\.)(adserver|adservice|adsystem|googlesyndication|googleadservices|doubleclick|adnxs|taboola|outbrain|criteo|moatads|scorecardresearch|adsrvr|pubmatic|rubiconproject|openx|casalemedia|33across|adform|adsafeprotected)(\\.|$)",
      Pattern.CASE_INSENSITIVE
  );

  private static final Pattern proxyPattern = Pattern.compile(
      "[?&](url|u|q|target|redirect|dest|link|adurl|goto)=([^&]+)",
      Pattern.CASE_INSENSITIVE
  );

  public static void init(Context context) {
    if (appContext == null) appContext = context.getApplicationContext();
    triggerListLoad();
    try { loadedLatch.await(3000, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
  }

  public static void ensureLoaded() { triggerListLoad(); }

  private static void triggerListLoad() {
    if (isLoadingList || isListLoaded || appContext == null) return;
    isLoadingList = true;
    new Thread(() -> {
      try {
        loadRawList(R.raw.mini);
        loadRawList(R.raw.ads);
      } catch (Exception e) { Log.e("AdBlock", "Failed to load lists", e); }
      finally { isListLoaded = true; isLoadingList = false; loadedLatch.countDown(); }
    }, "AdBlock-ListLoader").start();
  }

  private static void loadRawList(int resourceId) {
    try (InputStream is = appContext.getResources().openRawResource(resourceId);
         BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8), 32768)) {
      String line;
      while ((line = reader.readLine()) != null) {
        line = line.trim().toLowerCase(Locale.ROOT);
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("!") || line.startsWith("[")) continue;
        if (line.contains("$") || line.contains("#") || line.contains("/") || line.contains("*")) continue;
        if (line.startsWith("0.0.0.0 ")) line = line.substring(8).trim();
        else if (line.startsWith("127.0.0.1 ")) line = line.substring(10).trim();
        else if (line.startsWith("||")) {
          line = line.substring(2).trim();
          if (line.endsWith("^")) line = line.substring(0, line.length() - 1);
        }
        if (line.isEmpty()) continue;
        if (line.startsWith(".")) line = line.substring(1);
        while (line.endsWith(".")) line = line.substring(0, line.length() - 1);
        if (!line.isEmpty() && line.contains(".")) hosts.add(line);
      }
    } catch (Exception ignored) {}
  }

  public static String decodeProxyUrl(String urlStr) {
    if (urlStr == null) return null;
    String decoded = urlStr;
    try {
      Matcher m = proxyPattern.matcher(urlStr);
      if (m.find()) {
        String val = m.group(2);
        val = URLDecoder.decode(val, "UTF-8");
        String base64Str = val.replace('-', '+').replace('_', '/');
        while (base64Str.length() % 4 != 0) base64Str += "=";
        try {
          byte[] bytes = Base64.decode(base64Str, Base64.DEFAULT);
          String b = new String(bytes, "UTF-8");
          if (b.startsWith("http") || b.startsWith("//")) return b;
        } catch (Exception ignored) {}
      }
    } catch (Exception ignored) {}
    return decoded;
  }

  private static String normalizeHost(String host) {
    if (host == null) return null;
    host = host.trim().toLowerCase(Locale.ROOT);
    if (host.startsWith("http://") || host.startsWith("https://")) {
      try { host = Uri.parse(host).getHost(); } catch (Exception ignored) {}
    }
    if (host == null || host.isEmpty()) return null;
    int port = host.indexOf(':');
    if (port >= 0) host = host.substring(0, port);
    while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
    return host.isEmpty() ? null : host;
  }

  public static boolean isInList(String host) {
    host = normalizeHost(host);
    if (host == null) return false;
    if (!isListLoaded) { triggerListLoad(); return false; }
    if (hosts.contains(host)) return true;
    int idx = host.indexOf('.');
    while (idx != -1 && idx < host.length() - 1) {
      if (hosts.contains(host.substring(idx + 1))) return true;
      idx = host.indexOf('.', idx + 1);
    }
    return false;
  }

  public static boolean isBlockedHost(String host, String pageHost) {
    if (host == null || host.isEmpty()) return false;
    String normalized = normalizeHost(host);
    if (normalized == null) return false;

    if (whitelist.contains(normalized)) return false;
    for (String wl : whitelist) {
      if (normalized.endsWith("." + wl)) return false;
    }

    if (pageHost != null) {
      String normPage = normalizeHost(pageHost);
      if (normPage != null && (normalized.equals(normPage) || normalized.endsWith("." + normPage))) return false;
    }

    return isInList(normalized) || suspiciousHostPattern.matcher(normalized).find();
  }

  public static boolean isBlockedResource(String urlStr, String pageHost) {
    if (urlStr == null || urlStr.isEmpty()) return false;
    try {
      String decoded = decodeProxyUrl(urlStr);
      Uri uri = Uri.parse(decoded);
      String host = uri.getHost();
      if (host == null) return false;
      return isBlockedHost(host, pageHost);
    } catch (Exception ignored) {}
    return false;
  }

  public static WebResourceResponse createBlockedResponse(String mime) {
    try {
      if (mime == null || mime.isEmpty()) mime = "text/plain";
      return new WebResourceResponse(mime, "UTF-8", 200, "OK", null, new ByteArrayInputStream(new byte[0]));
    } catch (Exception e) { return null; }
  }
}