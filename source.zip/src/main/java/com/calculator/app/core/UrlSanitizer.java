package com.calculator.app.core;

public final class UrlSanitizer {
  private UrlSanitizer() {}
  public static String forDisplay(String value) {
    if (value == null) return "";
    return value.replace("\n", "").replace("\r", "").trim();
  }
  public static String safeFilename(String value) {
    if (value == null) return "download";
    String result = value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
    return result.isEmpty() ? "download" : result;
  }
}