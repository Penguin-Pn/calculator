package com.calculator.app.core;

public final class BrowserHistoryItem {
  public final String title;
  public final String url;
  public final long visitedAt;
  public BrowserHistoryItem(String title, String url, long visitedAt) {
    this.title = title == null ? "" : title;
    this.url = url == null ? "" : url;
    this.visitedAt = visitedAt;
  }
}