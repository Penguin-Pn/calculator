package com.calculator.app.core;

public final class ReaderMode {
  private ReaderMode() {}
  public static String toJavaScript() {
    return "(function(){var old=document.getElementById('__reader_mode_overlay');" +
      "if(old){old.remove();return 'off';}" +
      "var a=document.querySelector('article')||document.querySelector('main')||document.body;" +
      "var t=(a.innerText||'').trim();if(!t)return 'empty';" +
      "var d=document.createElement('div');d.id='__reader_mode_overlay';" +
      "d.style.cssText='position:fixed;inset:0;z-index:2147483647;overflow:auto;background:#f7f4ec;color:#222;padding:7vh max(7vw,20px);font:20px/1.8 Georgia,serif;white-space:pre-wrap';" +
      "d.textContent=t;document.documentElement.appendChild(d);return 'on';})()";
  }
}