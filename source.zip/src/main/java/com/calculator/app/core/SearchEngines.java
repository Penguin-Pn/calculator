package com.calculator.app.core;

public final class SearchEngines {
  public static final String GOOGLE = "https://www.google.com/search?q=";
  public static final String DUCKDUCKGO = "https://duckduckgo.com/?q=";
  public static final String BING = "https://www.bing.com/search?q=";
  public static final String BRAVE = "https://search.brave.com/search?q=";
  private SearchEngines() {}
}