package com.calculator.app.core;

import com.calculator.app.MainActivity;
import com.calculator.app.R;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import android.graphics.Color;

public final class Settings {
  private final MainActivity activity;

  public Settings(MainActivity activity) {
    this.activity = activity;
  }

  public void show() {
    final Dialog dialog = new Dialog(activity);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout root = new LinearLayout(activity);
    root.setOrientation(LinearLayout.VERTICAL);

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(activity.COLOR_BG_INPUT);
    bg.setCornerRadius(activity.dp(18));
    root.setBackground(bg);
    root.setClipToOutline(true);
    root.setPadding(activity.dp(4), activity.dp(14), activity.dp(4), activity.dp(10));

    TextView title = new TextView(activity);
    title.setText(activity.getString(R.string.settings_title));
    title.setTextColor(activity.COLOR_TEXT);
    title.setTextSize(16);
    title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    title.setGravity(activity.appStartGravity());
    title.setPadding(activity.dp(16), 0, activity.dp(16), activity.dp(10));
    root.addView(title);

    activity.addMenuDivider(root);

    root.addView(activity.sectionHeader(activity.getString(R.string.settings_section_search)));
    activity.addSettingRow(root, dialog, "🌐", activity.getString(R.string.settings_engine),
        activity.getSearchEngineName(), activity::showSearchEngineDialog);
    activity.addSettingRow(root, dialog, "🏠", activity.getString(R.string.settings_home),
        activity.getHomePageName(), activity::showHomePageDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.settings_section_view)));
    activity.addSettingRow(root, dialog, "🌐", activity.getString(R.string.settings_language),
        activity.getLanguageName(AppLanguage.get(activity)), activity::showLanguageDialog);
    activity.addSettingRow(root, dialog, "🖥", activity.getString(R.string.settings_desktop),
        activity.desktopMode ? activity.getString(R.string.settings_on) : activity.getString(R.string.settings_off),
        activity::toggleDesktop);
    activity.addSettingRow(root, dialog, "🔎", activity.getString(R.string.settings_zoom),
        (int) activity.currentZoom + "%", activity::showZoomDialog);
    activity.addSettingRow(root, dialog, "🧍", activity.stripLeadingSymbols(activity.getString(R.string.menu_custom_ua)),
        activity.customUserAgent.isEmpty() ? activity.getString(R.string.settings_off) : activity.getString(R.string.settings_on),
        activity::showCustomUaDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.settings_section_adblock)));
    activity.addSettingRow(root, dialog, "🚫", activity.getString(R.string.settings_adblock),
        activity.adblockEnabled ? activity.getString(R.string.settings_on) : activity.getString(R.string.settings_off),
        activity::toggleAdblock);
    activity.addSettingRow(root, dialog, "🤖", activity.getString(R.string.settings_adblock_ai),
        activity.adblockAiEnabled ? activity.getString(R.string.settings_on) : activity.getString(R.string.settings_off),
        activity::toggleAdblockAi);
    activity.addSettingRow(root, dialog, "📊", activity.getString(R.string.settings_adblock_stats),
        String.valueOf(activity.adblockTotalBlocked), activity::showAdblockStatsDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.settings_section_data)));
    activity.addSettingRow(root, dialog, "🗑", activity.getString(R.string.settings_clear_history), "", activity::clearHistoryConfirm);
    activity.addSettingRow(root, dialog, "🍪", activity.getString(R.string.menu_clear_cookies).substring(2), "", activity::clearCookies);
    activity.addSettingRow(root, dialog, "🗑", activity.getString(R.string.menu_clear_cache).substring(2), "", activity::clearCache);
    activity.addSettingRow(root, dialog, "⭐", activity.getString(R.string.settings_manage_bookmarks), "", activity::showBookmarks);
    activity.addSettingRow(root, dialog, "🗑", activity.getString(R.string.settings_clear_all_browser_data), "", activity::clearAllBrowserData);
    activity.addSettingRow(root, dialog, "⚙️", activity.getString(R.string.settings_reset_browser_settings), "", activity::resetBrowserSettings);
    activity.addSettingRow(root, dialog, "🗑", activity.getString(R.string.settings_clear_bookmarks),
        activity.bookmarksGetAll().size() + "", () -> {
      new AlertDialog.Builder(activity)
          .setTitle(activity.getString(R.string.settings_clear_bookmarks))
          .setMessage(activity.getString(R.string.settings_clear_bookmarks_msg))
          .setPositiveButton(activity.getString(R.string.clear), (d, w) -> {
            activity.getSharedPreferences(activity.PREF_BOOKMARKS, Context.MODE_PRIVATE).edit().clear().apply();
            activity.toast(activity.getString(R.string.toast_bookmarks_cleared));
          })
          .setNegativeButton(activity.getString(R.string.br_cancel), null)
          .show();
    });

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.settings_section_about)));
    activity.addSettingRow(root, dialog, "ℹ️", activity.getString(R.string.settings_version), activity.APP_VERSION, null);

    ScrollView sc = new ScrollView(activity);
    sc.setBackgroundColor(Color.TRANSPARENT);
    sc.addView(root);

    dialog.setContentView(sc);
    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (activity.getResources().getDisplayMetrics().widthPixels * 0.88),
          WindowManager.LayoutParams.WRAP_CONTENT);
    }
    dialog.show();
  
  }
}
