package com.calculator.app.core;

import java.util.Locale;

public final class UrlRisk {
  public enum Level { INTERNAL, SECURE, INSECURE, UNKNOWN }
  private UrlRisk() {}
  public static Level classify(String url) {
    if (url == null || url.trim().isEmpty()) return Level.UNKNOWN;
    String s = url.toLowerCase(Locale.ROOT);
    if (s.startsWith("this://") || s.startsWith("about:")) return Level.INTERNAL;
    if (s.startsWith("https://")) return Level.SECURE;
    if (s.startsWith("http://")) return Level.INSECURE;
    return Level.UNKNOWN;
  }
}