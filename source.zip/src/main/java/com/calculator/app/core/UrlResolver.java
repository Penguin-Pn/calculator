package com.calculator.app.core;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public final class UrlResolver {
  public enum Kind { INTERNAL, WEB, SEARCH, BLOCKED, EMPTY }
  public static final class Result {
    public final Kind kind;
    public final String value;
    Result(Kind kind, String value) { this.kind = kind; this.value = value; }
  }
  private UrlResolver() {}
  public static Result resolve(String input, String searchBase) {
    if (input == null || input.trim().isEmpty()) return new Result(Kind.EMPTY, "");
    String value = input.trim();
    String lower = value.toLowerCase(Locale.ROOT);
    if (lower.startsWith("about://")) value = "this://" + value.substring(8);
    lower = value.toLowerCase(Locale.ROOT);
    if (lower.startsWith("this://")) return new Result(Kind.INTERNAL, value);
    if (lower.startsWith("file:") || lower.startsWith("javascript:") || lower.startsWith("intent:"))
      return new Result(Kind.BLOCKED, value);
    if (lower.startsWith("http://") || lower.startsWith("https://"))
      return new Result(Kind.WEB, value);
    if (!value.contains(" ") && looksLikeHost(value))
      return new Result(Kind.WEB, "https://" + value);
    try {
      return new Result(Kind.SEARCH, searchBase + URLEncoder.encode(value, StandardCharsets.UTF_8.name()));
    } catch (Exception e) {
      return new Result(Kind.SEARCH, searchBase + value.replace(" ", "+"));
    }
  }
  private static boolean looksLikeHost(String value) {
    String v = value;
    int slash = v.indexOf('/');
    if (slash >= 0) v = v.substring(0, slash);
    return v.contains(".") && !v.startsWith(".") && !v.endsWith(".") && !v.contains("..");
  }
}