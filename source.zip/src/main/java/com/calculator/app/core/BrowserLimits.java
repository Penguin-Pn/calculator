package com.calculator.app.core;

public final class BrowserLimits {
  public static final int MAX_HISTORY = 500;
  public static final int MAX_BOOKMARKS = 2000;
  public static final int MAX_TABS = 50;
  public static final int MAX_BLOB_DOWNLOAD_BYTES = 25 * 1024 * 1024;
  public static final int MAX_DOWNLOAD_NAME_LENGTH = 180;
  private BrowserLimits() {}
}