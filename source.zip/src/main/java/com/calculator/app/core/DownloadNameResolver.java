package com.calculator.app.core;

import android.net.Uri;
import android.webkit.MimeTypeMap;

import java.net.URLDecoder;
import java.util.Locale;

public class DownloadNameResolver {

  public static String resolve(String url, String contentDisposition, String mimeType) {
    String fromUrl = extractFileNameFromUrl(url);
    if (!fromUrl.isEmpty()) {
      if (fromUrl.indexOf('.') < 0 && mimeType != null && !mimeType.isEmpty()) {
        try {
          String cleanMime = mimeType.split(";")[0].trim();
          String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(cleanMime);
          if (ext != null && !ext.isEmpty()) {
            fromUrl = fromUrl + "." + ext;
          }
        } catch (Exception ignored) {}
      }
      return fromUrl;
    }

    String fromDisposition = extractFromContentDisposition(contentDisposition);
    if (!fromDisposition.isEmpty()) {
      return fromDisposition;
    }

    return "download";
  }

  private static String extractFileNameFromUrl(String url) {
    if (url == null || url.trim().isEmpty()) return "";
    try {
      String clean = url;
      
      int qIdx = clean.indexOf('?');
      if (qIdx >= 0) clean = clean.substring(0, qIdx);
      
      int hIdx = clean.indexOf('#');
      if (hIdx >= 0) clean = clean.substring(0, hIdx);

      clean = clean.replace('\\', '/');

      String host = "";
      try {
        Uri uri = Uri.parse(clean);
        if (uri.getHost() != null) host = uri.getHost().toLowerCase(Locale.ROOT);
      } catch (Exception ignored) {}

      String[] parts = clean.split("/");
      
      for (int i = parts.length - 1; i >= 0; i--) {
        String part = parts[i].trim();
        
        if (part.isEmpty() || part.startsWith(":") || part.startsWith(";") || part.endsWith(":")) {
          continue;
        }
        
        try {
          part = URLDecoder.decode(part, "UTF-8");
        } catch (Exception ignored) {}
        
        part = part.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        
        if (!part.isEmpty()) {
          if (!host.isEmpty() && part.equalsIgnoreCase(host)) {
            continue;
          }
          return part;
        }
      }
    } catch (Exception e) {
      return "";
    }
    return "";
  }

  private static String extractFromContentDisposition(String contentDisposition) {
    if (contentDisposition == null || contentDisposition.isEmpty()) return "";
    try {
      String lower = contentDisposition.toLowerCase(Locale.ROOT);
      int idx = lower.indexOf("filename=");
      if (idx >= 0) {
        String name = contentDisposition.substring(idx + 9).trim();
        if (name.startsWith("\"") && name.endsWith("\"") && name.length() > 1) {
          name = name.substring(1, name.length() - 1);
        } else if (name.startsWith("'") && name.endsWith("'") && name.length() > 1) {
          name = name.substring(1, name.length() - 1);
        }
        int semi = name.indexOf(';');
        if (semi >= 0) name = name.substring(0, semi).trim();
        
        try {
          name = URLDecoder.decode(name, "UTF-8");
        } catch (Exception ignored) {}
        
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (!name.isEmpty()) return name;
      }
    } catch (Exception ignored) {}
    return "";
  }
}