package com.calculator.app.core;

import android.net.Uri;
import java.util.Locale;

public final class WebSecurityPolicy {
  private WebSecurityPolicy() {}
  public static boolean isForbiddenNavigation(String url) {
    if (url == null) return true;
    String s = url.trim().toLowerCase(Locale.ROOT);
    return s.startsWith("file:") || s.startsWith("javascript:") ||
        s.startsWith("intent:") || s.startsWith("content:") || s.startsWith("data:");
  }
  public static boolean isHttps(String url) {
    return url != null && url.regionMatches(true, 0, "https://", 0, 8);
  }
  public static boolean isHttp(String url) {
    return url != null && url.regionMatches(true, 0, "http://", 0, 7);
  }
  public static String host(String url) {
    try { return Uri.parse(url).getHost(); } catch (Exception e) { return null; }
  }
  public static boolean sameOrigin(String a, String b) {
    try {
      Uri x = Uri.parse(a), y = Uri.parse(b);
      return x.getScheme() != null && x.getScheme().equalsIgnoreCase(y.getScheme()) &&
          x.getHost() != null && x.getHost().equalsIgnoreCase(y.getHost()) &&
          x.getPort() == y.getPort();
    } catch (Exception e) { return false; }
  }
}