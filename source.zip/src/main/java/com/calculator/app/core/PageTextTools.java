package com.calculator.app.core;

public final class PageTextTools {
  private PageTextTools() {}
  public static String selectionScript() {
    return "javascript:(function(){var s=window.getSelection();return s?s.toString():''})()";
  }
  public static String wordCountScript() {
    return "(function(){var t=(document.body&&document.body.innerText)||'';" +
      "var trimmed=t.trim();var words=trimmed?trimmed.split(/\\s+/).length:0;" +
      "var paragraphs=document.body?document.body.querySelectorAll('p').length:0;" +
      "return {words:words,characters:t.length,paragraphs:paragraphs};})()";
  }
}
