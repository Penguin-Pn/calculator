package com.calculator.app.core;

public final class BookmarkItem {
  public final String title;
  public final String url;
  public final long createdAt;
  public BookmarkItem(String title, String url, long createdAt) {
    this.title = title == null ? "" : title;
    this.url = url == null ? "" : url;
    this.createdAt = createdAt;
  }
}