package com.calculator.app.core;

public enum PrivacyMode {
  STANDARD, STRICT, INCOGNITO;
  public boolean shouldPersistHistory() { return this == STANDARD; }
  public boolean shouldAllowThirdPartyCookies() { return this == STANDARD; }
  public boolean shouldKeepDownloads() { return this != INCOGNITO; }
}