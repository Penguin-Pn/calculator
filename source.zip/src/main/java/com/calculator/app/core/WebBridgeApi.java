package com.calculator.app.core;

import com.calculator.app.MainActivity;
import com.calculator.app.core.AppLanguage;

import android.content.Context;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import com.calculator.app.AdBlock;

public final class WebBridgeApi {
  private final MainActivity a;

  public WebBridgeApi(MainActivity activity) {
    this.a = activity;
  }

    @JavascriptInterface public String getHistory() {
      if (!a.isTrustedOrigin()) return "[]";
      return a.buildHistoryJson();
    }
    @JavascriptInterface public String getShortcuts() {
      if (!a.isTrustedOrigin()) return "[]";
      return a.getSharedPreferences(a.PREF_SHORTCUTS, Context.MODE_PRIVATE).getString("list", "[]");
    }
    @JavascriptInterface public void saveShortcuts(String json) {
      if (!a.isTrustedOrigin()) return;
      a.getSharedPreferences(a.PREF_SHORTCUTS, Context.MODE_PRIVATE).edit().putString("list", json).apply();
    }
    @JavascriptInterface public String faviconFor(String url) {
      if (!a.isTrustedOrigin()) return "";
      return a.faviconUrl(url);
    }
    
    @JavascriptInterface public void openUrl(String url) {
      a.runOnUiThread(() -> a.loadUrl(url));
    }
    @JavascriptInterface public void navigate(String input) {
      a.runOnUiThread(() -> a.navigateTo(input));
    }
    @JavascriptInterface public void newTab(String url) {
      a.runOnUiThread(() -> a.newTab(url, false));
    }
    @JavascriptInterface public void removeHistory(String url) {
      if (!a.isTrustedOrigin()) return;
      a.runOnUiThread(() -> a.historyRemove(url));
    }
    @JavascriptInterface public String prettyUrlFor(String url) {
      if (!a.isTrustedOrigin()) return url;
      return a.prettyUrl(url);
    }
    
    @JavascriptInterface public String getSettingsJson() {
      if (!a.isTrustedOrigin()) return "{}";
      try {
        JSONObject o = new JSONObject();
        o.put("engine", a.getSearchEngineName());
        o.put("homePage", a.getHomePageName());
        o.put("desktopMode", a.desktopMode);
        o.put("zoom", (int) a.currentZoom);
        o.put("hasCustomUa", a.customUserAgent != null && !a.customUserAgent.isEmpty());
        o.put("adblock", a.adblockEnabled);
        o.put("adblockAi", a.adblockAiEnabled);
        o.put("adblockTotalBlocked", a.adblockTotalBlocked);
        o.put("version", a.APP_VERSION);
        o.put("language", a.getLanguageName(AppLanguage.get(a)));
        return o.toString();
      } catch (Exception e) {
        return "{}";
      }
    }
    @JavascriptInterface public void showNativePicker(String type) {
      if (!a.isTrustedOrigin() || type == null) return;
      a.runOnUiThread(() -> {
        switch (type) {
          case "engine": a.showSearchEngineDialog(); break;
          case "home": a.showHomePageDialog(); break;
          case "language": a.showLanguageDialog(); break;
          case "zoom": a.showZoomDialog(); break;
          case "ua": a.showCustomUaDialog(); break;
        }
      });
    }
    @JavascriptInterface public void performAction(String action) {
      if (action == null) return;
      a.runOnUiThread(() -> {
        switch (action) {
          case "toggleDesktop": a.toggleDesktop(); break;
          case "toggleAdblock": a.toggleAdblock(); break;
          case "toggleAdblockAi": a.toggleAdblockAi(); break;
          case "showAdblockStats": a.showAdblockStatsDialog(); break;
          case "clearHistory": a.clearHistoryConfirm(); break;
          case "clearBookmarks": a.clearBookmarksConfirm(); break;
          case "clearCache": a.clearCache(); break;
          case "clearCookies": a.clearCookies(); break;
          case "clearCurrentSiteData": a.clearCurrentSiteData(); break;
          case "clearCurrentSiteCookies": a.clearCurrentSiteCookies(); break;
          case "clearAllBrowserData": a.clearAllBrowserData(); break;
          case "resetBrowserSettings": a.resetBrowserSettings(); break;
          case "manageBookmarks": a.showBookmarks(); break;
          case "devtools": a.toggleDevTools(); break;
        }
      });
    }

    @JavascriptInterface public void saveBase64Download(String base64, String fileName, String mimeType) {
      a.runOnUiThread(() -> a.handleBlobDownload(base64, fileName, mimeType));
    }

    @JavascriptInterface public void downloadUrl(String url, String fileName) {
      a.runOnUiThread(() -> {
        try {
          if (url.startsWith("this://")) {
            String path = url.substring(7);
            a.copyAssetToDownloads(path, fileName);
          } else {
            String name = fileName == null || fileName.isEmpty() ? "download" : fileName;
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle(name);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.addRequestHeader("User-Agent", a.UA_MOBILE);
            DownloadManager dm = (DownloadManager) a.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(req);
          }
        } catch (Exception e) {
          android.util.Log.e("DevTools", "Download failed", e);
        }
      });
    }

    @JavascriptInterface public void fetchText(String url, String cbId) {
      new Thread(() -> {
        String result = null;
        java.net.HttpURLConnection conn = null;
        try {
          String xurl = url;
          if (xurl.startsWith("this://")) {
            xurl = a.ASSET_PATH + xurl.substring(7);
          }
          URL u = new URL(xurl);
          conn = (java.net.HttpURLConnection) u.openConnection();
          conn.setConnectTimeout(10000);
          conn.setReadTimeout(10000);
          conn.setRequestProperty("User-Agent", a.UA_MOBILE);
          conn.setRequestProperty("Accept", "*/*");
          if (a.currentPageUrl != null && !a.currentPageUrl.isEmpty()) {
              conn.setRequestProperty("Referer", a.currentPageUrl);
          }
          String cookie = CookieManager.getInstance().getCookie(url);
          if (cookie != null) conn.setRequestProperty("Cookie", cookie);
          int code = conn.getResponseCode();
          if (code == 200) {
            try (InputStream is = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
              byte[] buf = new byte[8192];
              int n;
              while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
              result = bos.toString("UTF-8");
            }
          } else {
              android.util.Log.w("DevTools", "HTTP Error " + code + " for " + url);
          }
        } catch (Exception e) {
          android.util.Log.e("DevTools", "Fetch failed", e);
        } finally {
          if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
        final String finalResult = result;
        a.runOnUiThread(() -> {
          String js = "(function(){try{if(window.__devtools_onSourceLoaded)window.__devtools_onSourceLoaded(" + a.jsStr(cbId) + "," + (finalResult == null ? "null" : a.jsStr(finalResult)) + ");}catch(e){}})();";
          if (a.mWebView != null) a.mWebView.evaluateJavascript(js, null);
        });
      }).start();
    }

    @JavascriptInterface public void fetchBase64(String url, String cbId) {
      new Thread(() -> {
        String result = null;
        java.net.HttpURLConnection conn = null;
        try {
          String xurl = url;
          if (xurl.startsWith("this://")) {
            xurl = a.ASSET_PATH + xurl.substring(7);
          }
          URL u = new URL(xurl);
          conn = (java.net.HttpURLConnection) u.openConnection();
          conn.setConnectTimeout(10000);
          conn.setReadTimeout(10000);
          conn.setRequestProperty("User-Agent", a.UA_MOBILE);
          conn.setRequestProperty("Accept", "*/*");
          if (a.currentPageUrl != null && !a.currentPageUrl.isEmpty()) {
              conn.setRequestProperty("Referer", a.currentPageUrl);
          }
          String cookie = CookieManager.getInstance().getCookie(url);
          if (cookie != null) conn.setRequestProperty("Cookie", cookie);
          int code = conn.getResponseCode();
          if (code == 200) {
            try (InputStream is = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
              byte[] buf = new byte[8192];
              int n;
              while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
              result = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            }
          } else {
              android.util.Log.w("DevTools", "HTTP Error " + code + " for " + url);
          }
        } catch (Exception e) {
          android.util.Log.e("DevTools", "Fetch base64 failed", e);
        } finally {
          if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
        final String finalResult = result;
        a.runOnUiThread(() -> {
          String js = "(function(){try{if(window.__devtools_onSourceBase64Loaded)window.__devtools_onSourceBase64Loaded(" + a.jsStr(cbId) + "," + (finalResult == null ? "null" : a.jsStr(finalResult)) + ");}catch(e){}})();";
          if (a.mWebView != null) a.mWebView.evaluateJavascript(js, null);
        });
      }).start();
    }

    @JavascriptInterface
    public boolean isBlocked(String host) {
      String pageHost = null;
      try { pageHost = Uri.parse(a.currentPageUrl).getHost(); } catch (Exception ignored) {}
      return AdBlock.isBlockedHost(host, pageHost);
    }

    @JavascriptInterface
    public void translateText(String text, String lang, String cbId) {
      if (text == null || text.isEmpty() || lang == null || lang.isEmpty() || cbId == null) return;
      final String finalCbId = cbId;
      final String finalText = text;
      final String finalLang = lang;
      a.translatePool.execute(() -> {
        String result = null;
        java.net.HttpURLConnection conn = null;
        try {
          String url = "https://translate.googleapis.com/translate_a/single?client=gtx"
              + "&sl=auto&tl=" + Uri.encode(finalLang)
              + "&dt=t&q=" + Uri.encode(finalText);
          conn = (java.net.HttpURLConnection) new URL(url).openConnection();
          conn.setConnectTimeout(10000);
          conn.setReadTimeout(10000);
          conn.setRequestMethod("GET");
          conn.setRequestProperty("User-Agent", a.UA_MOBILE);
          conn.setRequestProperty("Accept-Encoding", "identity");
          int code = conn.getResponseCode();
          if (code == 200) {
            try (InputStream is = conn.getInputStream();
                 ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
              byte[] buf = new byte[8192];
              int n;
              while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
              JSONArray arr = new JSONArray(bos.toString("UTF-8"));
              JSONArray chunks = arr.getJSONArray(0);
              StringBuilder sb = new StringBuilder();
              for (int i = 0; i < chunks.length(); i++) {
                JSONArray chunk = chunks.optJSONArray(i);
                if (chunk != null && chunk.length() > 0) {
                  String s = chunk.optString(0, "");
                  if (!s.isEmpty()) sb.append(s);
                }
              }
              if (sb.length() > 0) result = sb.toString();
            }
          }
        } catch (Exception e) {
          android.util.Log.w("Translate", "http failed: " + e.getMessage());
        } finally {
          if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
        }
        final String escaped = result == null ? "null" : a.jsStr(result);
        final String js = "(function(){try{"
            + "if(window.__onTranslateResult)window.__onTranslateResult("
            + a.jsStr(finalCbId) + "," + escaped + ");"
            + "}catch(e){}})()";
        a.mainHandler.post(() -> {
          if (a.mWebView != null) a.mWebView.evaluateJavascript(js, null);
        });
      });
    }

    @JavascriptInterface
    public void onTranslateResult(String cbId, boolean ok) {
      Translate.handleResult(cbId, ok);
    }
}
