package com.calculator.app.core;

import java.util.Locale;

public final class MimeTypes {
  private MimeTypes() {}
  public static String fromName(String name) {
    if (name == null) return "application/octet-stream";
    String s = name.toLowerCase(Locale.ROOT);
    if (s.endsWith(".html") || s.endsWith(".htm")) return "text/html";
    if (s.endsWith(".css")) return "text/css";
    if (s.endsWith(".js") || s.endsWith(".mjs")) return "text/javascript";
    if (s.endsWith(".json")) return "application/json";
    if (s.endsWith(".xml")) return "application/xml";
    if (s.endsWith(".pdf")) return "application/pdf";
    if (s.endsWith(".zip")) return "application/zip";
    if (s.endsWith(".png")) return "image/png";
    if (s.endsWith(".jpg") || s.endsWith(".jpeg")) return "image/jpeg";
    if (s.endsWith(".webp")) return "image/webp";
    if (s.endsWith(".svg")) return "image/svg+xml";
    if (s.endsWith(".mp3")) return "audio/mpeg";
    if (s.endsWith(".mp4")) return "video/mp4";
    return "application/octet-stream";
  }
}