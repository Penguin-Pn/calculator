package com.calculator.app.core;

public final class BrowserFeatureFlags {
  public static final boolean SMART_URL_RESOLUTION = true;
  public static final boolean SAFE_DOWNLOAD_NAMES = true;
  public static final boolean READER_MODE = true;
  public static final boolean PAGE_TEXT_STATS = true;
  public static final boolean NETWORK_STATUS = true;
  public static final boolean PRIVACY_PROFILES = true;
  public static final boolean DIAGNOSTICS_RING_BUFFER = true;
  private BrowserFeatureFlags() {}
}