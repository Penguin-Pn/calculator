package com.calculator.app.core;

import android.net.Uri;

public final class DomainTools {
  private DomainTools() {}
  public static String getHost(String url) {
    try { String host = Uri.parse(url).getHost(); return host == null ? "" : host; }
    catch (Exception e) { return ""; }
  }
  public static String registrableHint(String url) {
    String host = getHost(url);
    if (host.isEmpty()) return "";
    String[] parts = host.split("\\\\.");
    if (parts.length < 2) return host;
    return parts[parts.length - 2] + "." + parts[parts.length - 1];
  }
}