package com.calculator.app.core;

import java.util.regex.Pattern;

public final class TextUtilities {
  private static final Pattern SPACE = Pattern.compile("\\s+");
  private TextUtilities() {}
  public static String normalizeWhitespace(String text) {
    return text == null ? "" : SPACE.matcher(text.trim()).replaceAll(" ");
  }
  public static String truncate(String text, int max) {
    if (text == null || max < 1) return "";
    if (text.length() <= max) return text;
    return text.substring(0, max - 1) + "…";
  }
}