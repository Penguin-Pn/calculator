package com.calculator.app.core;

import android.webkit.WebView;

public class Tab {
  public String url;
  public String title;
  public String favicon;
  public boolean incognito;
  public boolean ephemeral;
  public WebView webView;

  public Tab(String url, boolean incognito) {
    this.url = url;
    this.title = url;
    this.favicon = "";
    this.incognito = incognito;
    this.ephemeral = false;
  }
}
