package com.calculator.app.core;

public final class DownloadValidation {
  private DownloadValidation() {}
  public static boolean allowedUrl(String url) {
    if (url == null) return false;
    String s = url.trim().toLowerCase();
    return s.startsWith("https://") || s.startsWith("http://");
  }
  public static boolean withinLimit(long size, long limit) {
    return size >= 0 && size <= limit;
  }
}