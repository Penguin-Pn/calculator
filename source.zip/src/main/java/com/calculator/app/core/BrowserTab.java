package com.calculator.app.core;

public final class BrowserTab {
  public final String id;
  public String url;
  public String title;
  public final boolean incognito;
  public long lastActiveAt;
  public BrowserTab(String id, String url, String title, boolean incognito) {
    this.id = id;
    this.url = url == null ? "" : url;
    this.title = title == null ? "" : title;
    this.incognito = incognito;
    this.lastActiveAt = System.currentTimeMillis();
  }
}