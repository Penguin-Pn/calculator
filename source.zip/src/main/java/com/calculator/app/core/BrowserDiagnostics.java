package com.calculator.app.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class BrowserDiagnostics {
  private final ArrayDeque<BrowserEvent> events = new ArrayDeque<>();
  private final int capacity;
  public BrowserDiagnostics() { this(200); }
  public BrowserDiagnostics(int capacity) { this.capacity = Math.max(10, capacity); }
  public synchronized void add(String type, String detail) {
    if (events.size() >= capacity) events.removeFirst();
    events.addLast(new BrowserEvent(type, detail));
  }
  public synchronized List<BrowserEvent> snapshot() { return new ArrayList<>(events); }
  public synchronized void clear() { events.clear(); }
}