package com.calculator.app.core;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;

public final class NetworkStatus {
  private NetworkStatus() {}
  public static boolean isOnline(Context context) {
    try {
      ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
      if (cm == null) return false;
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Network n = cm.getActiveNetwork();
        NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        return c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
      }
      return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    } catch (Exception e) { return false; }
  }
}