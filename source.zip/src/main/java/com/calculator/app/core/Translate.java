package com.calculator.app.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.ValueCallback;
import android.webkit.WebView;

import com.calculator.app.R;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.concurrent.ConcurrentHashMap;

public final class Translate {

    private static volatile String cachedJs = null;
    private static final Object LOCK = new Object();
    private static final ConcurrentHashMap<String, Callback> PENDING = new ConcurrentHashMap<>();
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    private Translate() {}

    public interface Callback {
        void onDone(boolean ok);
    }

    private static String loadJavaScript(Context ctx) {
        if (cachedJs != null) return cachedJs;
        synchronized (LOCK) {
            if (cachedJs != null) return cachedJs;
            try (InputStream is = ctx.getResources().openRawResource(R.raw.translate);
                 ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                cachedJs = bos.toString("UTF-8");
            } catch (Exception e) {
                android.util.Log.w("Translate", "res/raw/translate.js missing", e);
                cachedJs = "";
            }
            return cachedJs;
        }
    }

    private static void ensureLoaded(WebView wv, Context ctx) {
        if (wv == null || ctx == null) return;
        String src = loadJavaScript(ctx);
        if (src.isEmpty()) return;
        String wrapped = "(function(){if(window.__translate)return;\n" + src + "\n})();";
        wv.evaluateJavascript(wrapped, null);
    }

    public static void translate(WebView wv, Context ctx, String targetLang, Callback cb) {
        if (wv == null || ctx == null || targetLang == null || targetLang.isEmpty()) {
            if (cb != null) cb.onDone(false);
            return;
        }
        ensureLoaded(wv, ctx);

        final String cbId = "trcb_" + System.currentTimeMillis() + "_" +
            Integer.toHexString((int) (Math.random() * 0xFFFF));
        if (cb != null) PENDING.put(cbId, cb);

        String js = "(function(){try{"
            + "if(!window.__translate){"
            + "  try{if(window.Bridge&&Bridge.onTranslateResult)"
            + "Bridge.onTranslateResult(" + jsStr(cbId) + ",false);}catch(e){}"
            + "  return;"
            + "}"
            + "window.__translate.translate(" + jsStr(targetLang) + ", function(ok){"
            + "  try{if(window.Bridge&&Bridge.onTranslateResult)"
            + "Bridge.onTranslateResult(" + jsStr(cbId) + ",!!ok);}catch(e){}"
            + "});"
            + "}catch(e){"
            + "  try{if(window.Bridge&&Bridge.onTranslateResult)"
            + "Bridge.onTranslateResult(" + jsStr(cbId) + ",false);}catch(e2){}"
            + "}})()";
        wv.evaluateJavascript(js, null);

        HANDLER.postDelayed(() -> {
            Callback pending = PENDING.remove(cbId);
            if (pending != null) pending.onDone(false);
        }, 20000);
    }

    public static void restore(WebView wv, Context ctx, Callback cb) {
        if (wv == null || ctx == null) {
            if (cb != null) cb.onDone(false);
            return;
        }
        ensureLoaded(wv, ctx);
        String js = "(function(){try{"
            + "if(!window.__translate){"
            + "  try{if(window.Bridge&&Bridge.onTranslateResult)"
            + "Bridge.onTranslateResult(" + jsStr("rs_" + System.currentTimeMillis()) + ",false);}catch(e){}"
            + "  return;"
            + "}"
            + "window.__translate.restore();"
            + "  try{if(window.Bridge&&Bridge.onTranslateResult)"
            + "Bridge.onTranslateResult(" + jsStr("rs_" + System.currentTimeMillis()) + ",true);}catch(e){}"
            + "}catch(e){}})()";
        // restore سنکرون است؛ نیازی به انتظار نیست
        wv.evaluateJavascript(js, null);
        if (cb != null) cb.onDone(true);
    }

    public static void handleResult(String cbId, boolean ok) {
        if (cbId == null) return;
        Callback cb = PENDING.remove(cbId);
        if (cb != null) cb.onDone(ok);
    }

    public static void getState(WebView wv, Context ctx, ValueCallback<String> cb) {
        if (wv == null || ctx == null) {
            if (cb != null) cb.onReceiveValue(null);
            return;
        }
        ensureLoaded(wv, ctx);
        String js = "(function(){try{"
            + "if(!window.__translate)return null;"
            + "return JSON.stringify(window.__translate.state());"
            + "}catch(e){return null;}})()";
        wv.evaluateJavascript(js, cb);
    }

    private static String jsStr(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"':  sb.append("\\\""); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                case '\u2028': sb.append("\\u2028"); break;
                case '\u2029': sb.append("\\u2029"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append("\"");
        return sb.toString();
    }
}