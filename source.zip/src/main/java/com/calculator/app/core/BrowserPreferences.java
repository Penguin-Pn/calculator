package com.calculator.app.core;

import android.content.Context;
import android.content.SharedPreferences;

public final class BrowserPreferences {
  private static final String FILE = "browser_preferences_v2";
  private final SharedPreferences prefs;
  public BrowserPreferences(Context context) {
    prefs = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
  }
  public boolean getBoolean(String key, boolean fallback) { return prefs.getBoolean(key, fallback); }
  public int getInt(String key, int fallback) { return prefs.getInt(key, fallback); }
  public String getString(String key, String fallback) { return prefs.getString(key, fallback); }
  public void putBoolean(String key, boolean value) { prefs.edit().putBoolean(key, value).apply(); }
  public void putInt(String key, int value) { prefs.edit().putInt(key, value).apply(); }
  public void putString(String key, String value) { prefs.edit().putString(key, value).apply(); }
  public void remove(String key) { prefs.edit().remove(key).apply(); }
  public void clear() { prefs.edit().clear().apply(); }
}