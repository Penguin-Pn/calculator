package com.calculator.app.core;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

public final class PathHelper {
  private PathHelper() {}

  public static void drawWarning(Canvas c, Paint p, float x, float y, float r) {
    Path path = new Path();
    path.moveTo(x, y - r);
    path.lineTo(x + r, y + r);
    path.lineTo(x - r, y + r);
    path.close();
    c.drawPath(path, p);
    p.setStyle(Paint.Style.FILL);
    c.drawCircle(x, y + r / 3, r / 5, p);
    p.setStyle(Paint.Style.STROKE);
  }
}
