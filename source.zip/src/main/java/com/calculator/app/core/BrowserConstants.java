package com.calculator.app.core;

public final class BrowserConstants {
  public static final String PREF_FILE = "browser_preferences_v2";
  public static final String PREF_READER_MODE = "reader_mode";
  public static final String PREF_TRACKING_PROTECTION = "tracking_protection";
  public static final String PREF_SAVE_DATA = "save_data";
  public static final String PREF_DESKTOP_MODE = "desktop_mode";
  public static final String PREF_SEARCH_ENGINE = "search_engine";
  private BrowserConstants() {}
}