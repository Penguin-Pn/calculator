package com.calculator.app.core;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public final class BrowserClock {
  private BrowserClock() {}
  public static String format(long timeMillis, Locale locale) {
    return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT,
        locale == null ? Locale.getDefault() : locale).format(new Date(timeMillis));
  }
}