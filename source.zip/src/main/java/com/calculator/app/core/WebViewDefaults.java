package com.calculator.app.core;

import android.os.Build;
import android.webkit.WebSettings;

public final class WebViewDefaults {
  private WebViewDefaults() {}
  public static void applySecurityDefaults(WebSettings settings) {
    settings.setAllowFileAccess(false);
    settings.setAllowContentAccess(false);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
      settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
      settings.setSafeBrowsingEnabled(true);
  }
}