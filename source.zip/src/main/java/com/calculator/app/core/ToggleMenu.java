package com.calculator.app.core;

import com.calculator.app.MainActivity;
import com.calculator.app.R;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public final class ToggleMenu {
  private final MainActivity activity;

  public ToggleMenu(MainActivity activity) {
    this.activity = activity;
  }

  public void show() {
    final Dialog dialog = new Dialog(activity);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout root = new LinearLayout(activity);
    root.setOrientation(LinearLayout.VERTICAL);

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(activity.COLOR_BG_INPUT);
    bg.setCornerRadius(activity.dp(16));
    root.setBackground(bg);
    root.setClipToOutline(true);
    root.setPadding(activity.dp(4), activity.dp(8), activity.dp(4), activity.dp(8));

    LinearLayout iconRow = new LinearLayout(activity);
    iconRow.setOrientation(LinearLayout.HORIZONTAL);
    iconRow.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams iconRowLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    iconRowLp.bottomMargin = activity.dp(4);
    iconRow.setLayoutParams(iconRowLp);

    iconRow.addView(activity.iconButton(activity.getString(R.string.br_reload),
        v -> { dialog.dismiss(); if (activity.mWebView != null) activity.mWebView.reload(); }));
    iconRow.addView(activity.iconButton(activity.getString(R.string.br_download),
        v -> { dialog.dismiss(); activity.downloadCurrent(); }));
    iconRow.addView(activity.iconButton(activity.getString(R.string.br_back),
        v -> { dialog.dismiss(); if (activity.mWebView != null && activity.mWebView.canGoBack()) activity.mWebView.goBack(); }));
    iconRow.addView(activity.iconButton(activity.getString(R.string.br_forward),
        v -> { dialog.dismiss(); if (activity.mWebView != null && activity.mWebView.canGoForward()) activity.mWebView.goForward(); }));

    root.addView(iconRow);
    activity.addMenuDivider(root);

    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_nav)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_calculator), () -> activity.loadUrl(activity.HOME_URL));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_new_tab), () -> activity.newTab(activity.NEWTAB_URL, false));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_incognito), () -> activity.newTab(activity.NEWTAB_URL, true));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_bookmark), activity::toggleBookmark);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_add_home), activity::showAddHomeShortcutDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_library)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_bookmarks), activity::showBookmarks);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_history), activity::showHistory);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_view)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_find), activity::showFindDialog);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_zoom), activity::showZoomDialog);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_desktop), activity::toggleDesktop);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_tools)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_devtools), activity::toggleDevTools);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_reader_mode), activity::toggleReaderMode);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_translate), activity::translatePage);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_page_text_statistics), activity::showPageTextStatistics);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_adblock), activity::toggleAdblock);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_save_page), activity::saveCurrentPageAsMht);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_copy_link), activity::copyLink);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_share), activity::sharePage);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_settings)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_settings), activity::showSettings);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_settings_page), () -> activity.newTab(activity.SETTINGS_URL, false));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_search_engine), activity::showSearchEngineDialog);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_home_page), activity::showHomePageDialog);
    activity.addMenuItem(root, dialog, ("🌐 " + activity.getString(R.string.settings_language)), activity::showLanguageDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_privacy)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_clear_site_data), activity::clearCurrentSiteData);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_clear_site_cookies), activity::clearCurrentSiteCookies);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_clear_cache), activity::clearCache);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_clear_cookies), activity::clearCookies);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_custom_ua), activity::showCustomUaDialog);

    activity.addMenuDivider(root);
    root.addView(activity.sectionHeader(activity.getString(R.string.menu_section_tabs)));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_close_tab), () -> activity.closeTab(activity.activeTabIndex));
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_close_all_tabs), activity::closeAllTabs);
    activity.addMenuItem(root, dialog, activity.getString(R.string.menu_exit), activity::finish);

    ScrollView sc = new ScrollView(activity);
    sc.setBackgroundColor(Color.TRANSPARENT);
    sc.addView(root);

    dialog.setContentView(sc);
    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (activity.getResources().getDisplayMetrics().widthPixels * 0.72),
          WindowManager.LayoutParams.WRAP_CONTENT);
      WindowManager.LayoutParams lp = w.getAttributes();
      lp.gravity = Gravity.TOP | Gravity.START;
      lp.x = activity.dp(6);
      lp.y = activity.dp(6);
      w.setAttributes(lp);
    }
    dialog.show();
  
  }
}
