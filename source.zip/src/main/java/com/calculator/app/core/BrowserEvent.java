package com.calculator.app.core;

public final class BrowserEvent {
  public final String type;
  public final String detail;
  public final long timestamp;
  public BrowserEvent(String type, String detail) {
    this.type = type == null ? "info" : type;
    this.detail = detail == null ? "" : detail;
    this.timestamp = System.currentTimeMillis();
  }
}