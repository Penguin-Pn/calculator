package com.calculator.app.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import java.util.Locale;

public final class AppLanguage {
  private static final String PREFS = "browser_language";
  private static final String KEY = "language";

  private AppLanguage() {}

  public static Context wrap(Context context) {
    String code = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "system");
    if (code == null || code.equals("system")) return context;
    Locale locale = new Locale(code);
    Locale.setDefault(locale);
    Configuration configuration = new Configuration(context.getResources().getConfiguration());
    configuration.setLocale(locale);
    return context.createConfigurationContext(configuration);
  }

  public static String get(Context context) {
    return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "system");
  }

  public static void set(Context context, String code) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, code).apply();
  }
}
