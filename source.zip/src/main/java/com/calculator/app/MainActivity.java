package com.calculator.app;

import java.io.FileInputStream;
import com.calculator.app.core.UrlResolver;
import com.calculator.app.core.DownloadNameResolver;
import com.calculator.app.core.WebSecurityPolicy;
import com.calculator.app.core.WebViewDefaults;
import com.calculator.app.core.ReaderMode;
import com.calculator.app.core.PageTextTools;
import com.calculator.app.core.Translate;
import com.calculator.app.core.Tab;
import com.calculator.app.core.PathHelper;
import com.calculator.app.core.WebBridgeApi;
import com.calculator.app.core.AppLanguage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.MimeTypeMap;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

  public static final String ASSET_DOMAIN = "appassets.androidplatform.net";
  public static final String ASSET_BASE = "https://" + ASSET_DOMAIN;
  public static final String ASSET_PATH = ASSET_BASE + "/assets/";
  public static final String NEWTAB_PATH = ASSET_BASE + "/newtab";
  public static final String SETTINGS_PATH = ASSET_BASE + "/settings";

  public static final String HOME_URL = "this://index.html";
  public static final String NEWTAB_URL = "this://newtab";
  public static final String SETTINGS_URL = "this://settings";

  public static final String PREF_TABS = "tabs_store";
  public static final String PREF_HISTORY = "history_store";
  public static final String PREF_SHORTCUTS = "newtab_shortcuts";
  public static final String PREF_BOOKMARKS = "bookmarks_store";
  public static final String PREF_UI = "ui_state";
  public static final String PREF_SEARCH = "search_engine";
  public static final String PREF_ADBLOCK = "adblock_prefs";
  public static final String PREF_UA = "custom_ua";

  public static final String APP_VERSION = BuildConfig.VERSION_NAME;

  public static final String UA_MOBILE =
      "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 " +
          "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
  public static final String UA_DESKTOP =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
          "AppleWebKit/537.36 (KHTML, like Gecko) " +
          "Chrome/120.0.0.0 Safari/537.36";

  public static final int COLOR_BG_INPUT = 0xFF1E2A3D;
  public static final int COLOR_BG_BTN = 0xFF253B54;
  public static final int COLOR_BG_PANEL = 0xFF131A2A;
  public static final int COLOR_BORDER = 0xFF2A3A4D;
  public static final int COLOR_TEXT = 0xFFEAF0FA;
  public static final int COLOR_TEXT_SUB = 0xFF8FA8C8;
  public static final int COLOR_ACCENT = 0xFF4A9EFF;
  public static final int COLOR_ACCENT_DARK = 0xFF2A5C8A;
  public static final int COLOR_DANGER = 0xFFC24B4B;
  public static final int COLOR_SUCCESS = 0xFF17A86B;

  public static final int MAX_BLOB_BYTES = 25 * 1024 * 1024;
  public static final int MAX_BASE64_CHARS = 35_000_000;
  public static final int MAX_HISTORY_ITEMS = 300;
  public static final int HISTORY_PREVIEW = 10;
  public static final long FAVICON_TIMEOUT_MS = 6000L;
  public static final long ADBLOCK_STATS_DELAY_MS = 900L;

  public WebView mWebView;
  public Bitmap currentFaviconBitmap;
  public ViewGroup webViewContainer;
  public EditText urlBar;
  public TextView btnTabCount;
  public TextView btnMenu;
  public TextView btnHome;
  public TextView btnBack;
  public TextView btnForward;
  public TextView btnReload;
  public TextView btnNewTab;
  public TextView securityIndicator;
  public LinearLayout tabsContainer;
  public ProgressBar progressBar;

  public String devtoolsJsCache = null;
  public String adblockJsCache = null;
  public String controllerJsCache = null;
  public String settingsHtmlCache = null;
  public String customUserAgent = "";
  public final List<Tab> tabs = new ArrayList<>();
  public final List<WeakReference<WebView>> popups = new ArrayList<>();
  public int activeTabIndex = 0;
  public boolean desktopMode = false;
  public boolean showingError = false;
  public float currentZoom = 100f;
  public boolean sslErrorDetected = false;
  public ValueCallback<Uri[]> fileChooserCallback;
  public static final int FILE_CHOOSER_REQUEST = 7402;

  public volatile String currentPageUrl = "";

  public boolean adblockEnabled = true;
  public boolean adblockAiEnabled = true;
  public int adblockPageHidden = 0;
  public int adblockPageBlocked = 0;
  public int adblockTotalHidden = 0;
  public int adblockTotalBlocked = 0;
  public int adblockSessionBlocked = 0;
  public final Map<String, Integer> adblockPageTotals = new HashMap<>();

  public final ExecutorService faviconPool = Executors.newFixedThreadPool(3);
  public final ExecutorService translatePool = Executors.newFixedThreadPool(2);
  public final Handler mainHandler = new Handler(Looper.getMainLooper());

  public static final int EDGE_WIDTH_DP = 24;
  public static final int SWIPE_MIN_DP = 70;
  public static final int SWIPE_MAX_OFF_PATH_DP = 100;
  public float swipeStartX = 0;
  public float swipeStartY = 0;
  public boolean swipeFromLeft = false;
  public boolean swipeFromRight = false;
  public boolean swipeInProgress = false;
  public boolean swipeConsumed = false;

  public static final String[][] SEARCH_ENGINES = {
      {"Google",     "https://www.google.com/search?q="},
      {"DuckDuckGo", "https://duckduckgo.com/?q="},
      {"Bing",       "https://www.bing.com/search?q="},
      {"Startpage",  "https://www.startpage.com/sp/search?query="},
      {"Brave",      "https://search.brave.com/search?q="},
      {"Ecosia",     "https://www.ecosia.org/search?q="}
  };

  public final Runnable adblockStatsRunnable = new Runnable() {
    @Override public void run() { refreshAdblockStats(); }
  };

  public int dp(float v) {
    return (int) (getResources().getDisplayMetrics().density * v);
  }

  public int appStartGravity() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
      return getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL
          ? Gravity.RIGHT : Gravity.LEFT;
    }
    return Gravity.LEFT;
  }

  public View spacer(int widthDp) {
    View v = new View(this);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(widthDp), 1);
    v.setLayoutParams(lp);
    return v;
  }

  public boolean isTrustedOrigin() {
    String url = currentPageUrl;
    if (url == null) return false;
    return url.startsWith(ASSET_BASE);
  }

  public void haptic() {
    try {
      View v = findViewById(android.R.id.content);
      if (v != null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
        } else {
          v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
        }
      }
    } catch (Exception ignored) {}
  }

  public static String readRawText(Context ctx, int resId) throws IOException {
    try (InputStream is = ctx.getResources().openRawResource(resId);
         ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
      byte[] buf = new byte[8192];
      int n;
      while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
      return bos.toString("UTF-8");
    }
  }

  public String getHomePageUrl() {
    String home = getSharedPreferences(PREF_UI, MODE_PRIVATE)
        .getString("homePage", "calculator");
    return "newtab".equals(home) ? NEWTAB_URL : HOME_URL;
  }

  public boolean isNewtabUrl(String url) {
    if (url == null) return false;
    String lower = url.toLowerCase();
    if (lower.startsWith("this://newtab")) return true;
    return url.startsWith(NEWTAB_PATH);
  }

  public void destroyPopups() {
    for (int i = popups.size() - 1; i >= 0; i--) {
      WebView w = popups.get(i).get();
      if (w != null) {
        try { w.stopLoading(); w.destroy(); } catch (Exception ignored) {}
      }
    }
    popups.clear();
  }

  public Tab getTabForWebView(WebView wv) {
    for (Tab t : tabs) {
      if (t.webView == wv) return t;
    }
    return null;
  }

  public WebView createNewWebView() {
    WebView wv = new WebView(this);
    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT,
        FrameLayout.LayoutParams.MATCH_PARENT);
    wv.setLayoutParams(lp);
    configureWebView(wv);
    return wv;
  }

  @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
  @Override
  protected void attachBaseContext(Context newBase) {
    super.attachBaseContext(AppLanguage.wrap(newBase));
  }

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      getWindow().setStatusBarColor(Color.parseColor("#131a2a"));
      getWindow().setNavigationBarColor(Color.parseColor("#0a0e1a"));
    }

    btnTabCount = findViewById(R.id.btnTabCount);
    btnMenu = findViewById(R.id.btnMenu);
    urlBar = findViewById(R.id.urlBar);
    progressBar = findViewById(R.id.progressBar);
    mWebView = findViewById(R.id.activity_main_webview);
    btnHome = findViewById(R.id.btnHome);
    btnBack = findViewById(R.id.btnBack);
    btnForward = findViewById(R.id.btnForward);
    btnReload = findViewById(R.id.btnReload);
    btnNewTab = findViewById(R.id.btnNewTab);
    securityIndicator = findViewById(R.id.securityIndicator);
    tabsContainer = findViewById(R.id.tabsContainer);

    webViewContainer = (ViewGroup) mWebView.getParent();
    webViewContainer.removeView(mWebView);
    mWebView = null;

    applyRoundedBackgrounds();
    updateSecurityIndicator(null);
    loadAdblockPrefs();
    customUserAgent = getSharedPreferences(PREF_UA, MODE_PRIVATE).getString("ua", "");
    AdBlock.init(this);

    btnTabCount.setOnClickListener(v -> { haptic(); showTabsDialog(); });
    btnMenu.setOnClickListener(v -> { haptic(); showMenu(); });
    if (btnHome != null) {
      btnHome.setOnClickListener(v -> { haptic(); loadUrl(getHomePageUrl()); });
    }
    if (btnBack != null) btnBack.setOnClickListener(v -> {
      haptic();
      if (mWebView != null && mWebView.canGoBack()) mWebView.goBack();
    });
    if (btnForward != null) btnForward.setOnClickListener(v -> {
      haptic();
      if (mWebView != null && mWebView.canGoForward()) mWebView.goForward();
    });
    if (btnReload != null) btnReload.setOnClickListener(v -> {
      haptic();
      if (mWebView != null) mWebView.reload();
    });
    if (btnNewTab != null) btnNewTab.setOnClickListener(v -> {
      haptic();
      newTab(NEWTAB_URL, false);
    });

    urlBar.setOnEditorActionListener((v, actionId, event) -> {
      boolean isGo = actionId == EditorInfo.IME_ACTION_GO
          || actionId == EditorInfo.IME_ACTION_DONE
          || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
      if (isGo) {
        navigateTo(urlBar.getText().toString().trim());
        urlBar.clearFocus();
        hideKeyboard();
        return true;
      }
      return false;
    });

    urlBar.setOnFocusChangeListener((v, hasFocus) -> {
      if (hasFocus) urlBar.selectAll();
    });

    restoreUiState();
    restoreTabs();
    Intent initialIntent = getIntent();
    if (initialIntent != null && initialIntent.getAction() != null) {
      mainHandler.post(() -> handleExternalIntent(initialIntent));
    }
  }

  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    if (intent != null && intent.getAction() != null) handleExternalIntent(intent);
  }

  @Override
  protected void onPause() {
    super.onPause();
    saveTabs();
    saveUiState();
    saveAdblockPrefs();
  }

  @Override
  protected void onDestroy() {
    saveTabs();
    saveUiState();
    saveAdblockPrefs();
    devtoolsJsCache = null;
    adblockJsCache = null;
    controllerJsCache = null;
    faviconPool.shutdownNow();
    translatePool.shutdownNow();
    mainHandler.removeCallbacksAndMessages(null);
    destroyPopups();
    
    for (Tab t : tabs) {
        if (t.webView != null) {
            t.webView.removeJavascriptInterface("Bridge");
            t.webView.removeJavascriptInterface("AndroidAdBlock");
            t.webView.stopLoading();
            t.webView.destroy();
        }
    }
    tabs.clear();
    mWebView = null;
    
    super.onDestroy();
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode != FILE_CHOOSER_REQUEST) return;
    if (fileChooserCallback == null) return;
    Uri[] results = null;
    if (resultCode == RESULT_OK) {
      if (data != null) {
        if (data.getClipData() != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
          ClipData clip = data.getClipData();
          results = new Uri[clip.getItemCount()];
          for (int i = 0; i < clip.getItemCount(); i++) {
            results[i] = clip.getItemAt(i).getUri();
          }
        } else if (data.getData() != null) {
          results = new Uri[]{data.getData()};
        }
      }
    }
    fileChooserCallback.onReceiveValue(results);
    fileChooserCallback = null;
  }

  @Override
  public boolean dispatchKeyEvent(KeyEvent event) {
    if (event.getAction() == KeyEvent.ACTION_DOWN) {
      int key = event.getKeyCode();
      boolean ctrl = event.isCtrlPressed();
      boolean shift = event.isShiftPressed();
      if (ctrl) {
        if (key == KeyEvent.KEYCODE_L) {
          urlBar.requestFocus();
          urlBar.selectAll();
          ((android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(urlBar, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
          return true;
        }
        if (key == KeyEvent.KEYCODE_T) { newTab(NEWTAB_URL, false); return true; }
        if (key == KeyEvent.KEYCODE_W) { closeTab(activeTabIndex); return true; }
        if (key == KeyEvent.KEYCODE_R) { if (mWebView != null) mWebView.reload(); return true; }
        if (key == KeyEvent.KEYCODE_D) { toggleBookmark(); return true; }
        if (key == KeyEvent.KEYCODE_TAB && !tabs.isEmpty()) {
          int next = shift ? activeTabIndex - 1 : activeTabIndex + 1;
          if (next < 0) next = tabs.size() - 1;
          if (next >= tabs.size()) next = 0;
          switchTab(next);
          return true;
        }
      }
      if (event.isAltPressed() && key == KeyEvent.KEYCODE_DPAD_LEFT) {
        if (mWebView != null && mWebView.canGoBack()) mWebView.goBack();
        return true;
      }
      if (event.isAltPressed() && key == KeyEvent.KEYCODE_DPAD_RIGHT) {
        if (mWebView != null && mWebView.canGoForward()) mWebView.goForward();
        return true;
      }
      if (key == KeyEvent.KEYCODE_ESCAPE) {
        if (mWebView != null) mWebView.stopLoading();
        hideKeyboard();
        if (urlBar != null) urlBar.clearFocus();
        return true;
      }
    }
    return super.dispatchKeyEvent(event);
  }

  @Override
  public void onBackPressed() {
    if (mWebView == null) { super.onBackPressed(); return; }
    mWebView.evaluateJavascript(
        "(function(){" +
            "if(window.__devtools&&window.__devtools.visible){window.__devtools.hide();return 'dev';}" +
            "var panels=document.querySelectorAll('.panel.show');" +
            "if(panels.length>0){panels.forEach(function(p){p.classList.remove('show');});return 'closed';}" +
            "if(document.activeElement&&document.activeElement.tagName==='TEXTAREA'){document.activeElement.blur();return 'blur';}" +
            "return 'exit';" +
            "})()",
        value -> {
          if (value == null || !value.contains("exit")) return;
          if (mWebView == null) return;
          if (mWebView.canGoBack()) mWebView.goBack();
          else MainActivity.super.onBackPressed();
        });
  }

  @Override
  public boolean dispatchTouchEvent(MotionEvent ev) {
    if (mWebView == null) return super.dispatchTouchEvent(ev);

    int edgeWidth = dp(EDGE_WIDTH_DP);
    int minSwipe = dp(SWIPE_MIN_DP);
    int maxOffPath = dp(SWIPE_MAX_OFF_PATH_DP);
    int screenWidth = getResources().getDisplayMetrics().widthPixels;

    switch (ev.getActionMasked()) {
      case MotionEvent.ACTION_DOWN: {
        float x = ev.getX();
        swipeFromLeft = x < edgeWidth;
        swipeFromRight = x > screenWidth - edgeWidth;
        if (swipeFromLeft || swipeFromRight) {
          swipeInProgress = true;
          swipeConsumed = false;
          swipeStartX = x;
          swipeStartY = ev.getY();
        }
        break;
      }
      case MotionEvent.ACTION_MOVE: {
        if (swipeInProgress && !swipeConsumed) {
          float dx = ev.getX() - swipeStartX;
          float dy = ev.getY() - swipeStartY;
          if (Math.abs(dy) > maxOffPath) {
            swipeInProgress = false;
            swipeConsumed = true;
            break;
          }
          if (Math.abs(dx) >= minSwipe && Math.abs(dx) > Math.abs(dy) * 2f) {
            if (dx > 0 && swipeFromLeft) {
              if (mWebView.canGoBack()) { mWebView.goBack(); haptic(); }
              swipeConsumed = true;
              return true;
            } else if (dx < 0 && swipeFromRight) {
              if (mWebView.canGoForward()) { mWebView.goForward(); haptic(); }
              swipeConsumed = true;
              return true;
            }
          }
        }
        break;
      }
      case MotionEvent.ACTION_UP:
      case MotionEvent.ACTION_CANCEL: {
        boolean wasConsumed = swipeConsumed;
        swipeInProgress = false;
        swipeConsumed = false;
        swipeFromLeft = false;
        swipeFromRight = false;
        if (wasConsumed) return true;
        break;
      }
    }
    return super.dispatchTouchEvent(ev);
  }


  public void loadAdblockPrefs() {
    SharedPreferences sp = getSharedPreferences(PREF_ADBLOCK, MODE_PRIVATE);
    adblockEnabled = sp.getBoolean("enabled", true);
    adblockAiEnabled = sp.getBoolean("ai", true);
    adblockTotalHidden = sp.getInt("totalHidden", 0);
    adblockTotalBlocked = sp.getInt("totalBlocked", 0);
    synchronized (adblockPageTotals) {
      adblockPageTotals.clear();
      try {
        JSONObject saved = new JSONObject(sp.getString("pageTotals", "{}"));
        java.util.Iterator<String> keys = saved.keys();
        while (keys.hasNext()) {
          String key = keys.next();
          adblockPageTotals.put(key, Math.max(0, saved.optInt(key, 0)));
        }
      } catch (Exception ignored) {}
    }
  }

  public void saveAdblockPrefs() {
    JSONObject pageTotals = new JSONObject();
    synchronized (adblockPageTotals) {
      for (Map.Entry<String, Integer> entry : adblockPageTotals.entrySet()) {
        try { pageTotals.put(entry.getKey(), entry.getValue()); } catch (Exception ignored) {}
      }
    }
    getSharedPreferences(PREF_ADBLOCK, MODE_PRIVATE).edit()
        .putBoolean("enabled", adblockEnabled)
        .putBoolean("ai", adblockAiEnabled)
        .putInt("totalHidden", adblockTotalHidden)
        .putInt("totalBlocked", adblockTotalBlocked)
        .putString("pageTotals", pageTotals.toString())
        .apply();
  }

  public String adblockPageKey(String url) {
    if (url == null || url.trim().isEmpty()) return "";
    try { return Uri.parse(url).buildUpon().fragment(null).build().toString(); }
    catch (Exception ignored) { return url; }
  }

  public int getAdblockCurrentPageTotal() {
    String key = adblockPageKey(currentPageUrl);
    if (key.isEmpty()) return 0;
    synchronized (adblockPageTotals) {
      Integer value = adblockPageTotals.get(key);
      return value == null ? 0 : value;
    }
  }

  public void recordAdblockEvents(String pageUrl, int count) {
    if (count <= 0) return;
    adblockSessionBlocked += count;
    String key = adblockPageKey(pageUrl);
    if (!key.isEmpty()) {
      synchronized (adblockPageTotals) {
        Integer old = adblockPageTotals.get(key);
        adblockPageTotals.put(key, (old == null ? 0 : old) + count);
      }
    }
    saveAdblockPrefs();
  }

  public WebResourceResponse blockedResponse(String mime) {
    return AdBlock.createBlockedResponse(mime);
  }

  public String getAdblockJs() {
    if (adblockJsCache != null) return adblockJsCache;
    try {
      adblockJsCache = readRawText(this, R.raw.adblock_js);
    } catch (Exception e) {
      adblockJsCache = "console.warn('adblock_js missing');";
    }
    return adblockJsCache;
  }

  public String getControllerJs() {
    if (controllerJsCache != null) return controllerJsCache;
    try {
      controllerJsCache = readRawText(this, R.raw.controller_js);
    } catch (Exception e) {
      controllerJsCache = "";
    }
    return controllerJsCache;
  }

  public void injectDesktopController() {
    if (mWebView == null || !desktopMode) return;
    String js = getControllerJs();
    if (js == null || js.isEmpty()) return;
    mWebView.evaluateJavascript(js, null);
  }

  public boolean isInternalPage(String url) {
    if (url == null) return true;
    String lower = url.toLowerCase();
    return lower.startsWith("this://")
        || lower.startsWith(ASSET_BASE)
        || lower.startsWith("about:")
        || lower.startsWith("data:");
  }

  public void injectAdblock() {
    if (mWebView == null || !adblockEnabled) return;
    if (isInternalPage(currentPageUrl)) return;
    String prelude =
        "(function(){" +
            "if(window.__adblock_pre){return;}" +
            "window.__adblock_pre=1;" +
            "window.__adblock_ai=" + (adblockAiEnabled ? "true" : "false") + ";" +
            "})();\n";
    mWebView.evaluateJavascript(prelude + getAdblockJs(), null);
  }

  public void refreshAdblockStats() {
    if (mWebView == null || !adblockEnabled) return;
    final String statsUrl = currentPageUrl;
    if (isInternalPage(statsUrl)) return;
  
    mWebView.evaluateJavascript(
      "(function(){try{var a=window.__adblock;" +
          "if(!a||!a.report)return '{}';return a.report();}catch(e){return '{}';}})()",
      value -> {
        if (value == null || !statsUrl.equals(currentPageUrl)) return;
        try {
          String v = value.trim();
          if (v.startsWith("\"") && v.endsWith("\"")) {
            v = v.substring(1, v.length() - 1).replace("\\\"", "\"");
          }
          JSONObject o = new JSONObject(v);
          int h = o.optInt("hidden", 0);
          
          if (h > adblockPageHidden) { 
              int delta = h - adblockPageHidden; 
              adblockPageHidden = h; 
              adblockTotalHidden += delta;
          }
        } catch (Exception ignored) {}
      });
  }
  
  public void toggleAdblock() {
    adblockEnabled = !adblockEnabled;
    if (adblockEnabled) {
      AdBlock.ensureLoaded();
      toast(getString(R.string.toast_adblock_on));
    } else {
      toast(getString(R.string.toast_adblock_off));
    }
    saveAdblockPrefs();
    if (mWebView != null) mWebView.reload();
  }

  public void toggleAdblockAi() {
    adblockAiEnabled = !adblockAiEnabled;
    if (adblockAiEnabled) {
      toast(getString(R.string.toast_adblock_ai_on));
    } else {
      toast(getString(R.string.toast_adblock_ai_off));
    }
    saveAdblockPrefs();
    if (mWebView != null && adblockEnabled && !isInternalPage(currentPageUrl)) {
      mWebView.evaluateJavascript(
          "(function(){if(window.__adblock)window.__adblock.setAI(" +
              (adblockAiEnabled ? "true" : "false") + ");})()", null);
    }
  }

  public void clearAdblockStats() {
    adblockPageHidden = 0;
    adblockPageBlocked = 0;
    adblockTotalHidden = 0;
    adblockTotalBlocked = 0;
    adblockSessionBlocked = 0;
    synchronized (adblockPageTotals) { adblockPageTotals.clear(); }
    saveAdblockPrefs();
    toast(getString(R.string.toast_adblock_stats_cleared));
  }

  public void showAdblockStatsDialog() {
    int thisPage = adblockPageBlocked + adblockPageHidden;
    int totalBrowser = adblockTotalBlocked + adblockTotalHidden;
  
    String msg = getString(R.string.adblock_stats_body, thisPage, totalBrowser);
  
    new AlertDialog.Builder(this)
      .setTitle(getString(R.string.settings_adblock_stats_title))
      .setMessage(msg)
      .setPositiveButton(getString(R.string.br_cancel), null)
      .setNeutralButton(getString(R.string.settings_adblock_clear_stats),
          (d, w) -> clearAdblockStats())
      .show();
  }
  
  public void handleBlobDownload(String base64, String fileName, String mimeType) {
    Uri pendingUri = null;
    try {
      if (base64 == null || base64.length() > MAX_BASE64_CHARS) {
        toast(getString(R.string.toast_file_too_big));
        return;
      }
      byte[] bytes = Base64.decode(base64, Base64.NO_WRAP);
      if (bytes.length > MAX_BLOB_BYTES) {
        toast(getString(R.string.toast_blob_limit));
        return;
      }
      String safeName = fileName == null ? ""
          : fileName.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
      String mime = mimeType == null ? ""
          : mimeType.trim().split(";")[0].toLowerCase(Locale.ROOT);
      if (safeName.isEmpty()) safeName = "download";
      if (mime.isEmpty()) mime = "application/octet-stream";

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
        values.put(MediaStore.Downloads.MIME_TYPE, mime);
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("Cannot create download entry");
        pendingUri = uri;
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
          if (out == null) throw new IOException("Cannot open download output");
          out.write(bytes);
        }
        pendingUri = null;
      } else {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) throw new IOException("Downloads directory unavailable");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create downloads directory");
        try (FileOutputStream out = new FileOutputStream(new File(dir, safeName))) {
          out.write(bytes);
        }
      }
      toast(getString(R.string.toast_file_saved, safeName));
    } catch (Exception e) {
      if (pendingUri != null) {
        try { getContentResolver().delete(pendingUri, null, null); } catch (Exception ignored) {}
      }
      android.util.Log.e("BrowserDownload", "Blob download failed", e);
      toast(getString(R.string.toast_save_failed));
    }
  }

  public void applyRoundedBackgrounds() {
    if (urlBar != null) urlBar.setBackgroundColor(Color.TRANSPARENT);
  }

  public void hideKeyboard() {
    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    if (imm != null && urlBar != null && urlBar.getWindowToken() != null) {
      imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }
  }

  public void toast(String msg) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
  }

  public String faviconUrl(String url) {
    if (url == null || url.isEmpty()) return "";
    if (url.startsWith("this://") || url.startsWith("about:")) return "";
    if (url.startsWith(ASSET_BASE)) return "";
    if (url.startsWith("data:")) return "";
    if (url.startsWith("file://")) return "";
    try {
      Uri u = Uri.parse(url);
      String host = u.getHost();
      if (host == null || host.isEmpty()) return "";
      return "https://www.google.com/s2/favicons?domain=" + host + "&sz=64";
    } catch (Exception e) { return ""; }
  }

  public void loadFaviconAsync(final ImageView target, final String url) {
    final String favUrl = faviconUrl(url);
    if (favUrl.isEmpty()) return;
    final WeakReference<ImageView> ref = new WeakReference<>(target);
    faviconPool.execute(() -> {
      InputStream is = null;
      try {
        URL u = new URL(favUrl);
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
        conn.setConnectTimeout((int) FAVICON_TIMEOUT_MS);
        conn.setReadTimeout((int) FAVICON_TIMEOUT_MS);
        conn.setInstanceFollowRedirects(true);
        is = conn.getInputStream();
        final Bitmap bm = BitmapFactory.decodeStream(is);
        if (bm == null) return;
        mainHandler.post(() -> {
          ImageView iv = ref.get();
          if (iv == null) { bm.recycle(); return; }
          try { iv.setImageBitmap(bm); } catch (Exception ignored) {}
        });
      } catch (Exception ignored) {
      } finally {
        if (is != null) try { is.close(); } catch (Exception ignored) {}
      }
    });
  }

  public boolean isInternalUrl(String url) {
    return url != null && url.startsWith(ASSET_BASE);
  }

  public void navigateTo(String input) {
    if (input == null || input.trim().isEmpty()) return;
    UrlResolver.Result result = UrlResolver.resolve(input, getSearchEngineUrl());
    if (result.kind == UrlResolver.Kind.BLOCKED) {
      toast(getString(R.string.err_file_not_allowed));
      urlBar.setText(prettyUrl(mWebView == null ? HOME_URL : mWebView.getUrl()));
      return;
    }
    if (result.kind == UrlResolver.Kind.EMPTY) return;
    showingError = false;
    if (result.kind == UrlResolver.Kind.INTERNAL) loadUrl(result.value);
    else if (mWebView != null) mWebView.loadUrl(result.value);
  }

  public void updateSecurityIndicator(String url) {
    boolean internal = url == null || url.isEmpty() || url.startsWith("this://") || url.startsWith("about:");
    boolean secure = url != null && url.toLowerCase().startsWith("https://") && !sslErrorDetected;
    if (securityIndicator != null) {
      securityIndicator.setText(internal ? "◈" : secure ? "🔒" : "⚠");
      securityIndicator.setTextColor(internal ? 0xFF8CA2BA : secure ? 0xFF48D597 : 0xFFFFC36A);
      securityIndicator.setContentDescription(internal ? getString(R.string.url_internal_page) : secure ? getString(R.string.url_https_secure) : getString(R.string.url_not_secure));
    }
    if (urlBar != null) {
      urlBar.setCompoundDrawables(null, null, null, null);
      if (internal) urlBar.setContentDescription(getString(R.string.url_internal_page));
      else if (secure) urlBar.setContentDescription(getString(R.string.url_https_secure));
      else urlBar.setContentDescription(getString(R.string.url_not_secure));
    }
  }

  public void installBlobDownloadHandler() {
    if (mWebView == null) return;
    String js = "(function(){if(window.__browserDownloadHook)return;window.__browserDownloadHook=1;" +
        "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[download]'):null;if(!a)return;var u=a.href||'',n=a.download||'';" +
        "if(!(u.indexOf('blob:')===0||u.indexOf('data:')===0))return;e.preventDefault();" +
        "try{var p=u.indexOf(',');if(u.indexOf('data:')===0){var head=u.slice(0,p),body=u.slice(p+1),mime=(head.match(/^data:([^;,]+)/)||[])[1]||'application/octet-stream';var b=head.indexOf(';base64')>=0?body: btoa(unescape(encodeURIComponent(decodeURIComponent(body))));Bridge.saveBase64Download(b,n,mime);}else{fetch(u).then(function(r){return r.blob()}).then(function(blob){if(blob.size>26214400){alert('max 25MB');return;}var fr=new FileReader();fr.onload=function(){Bridge.saveBase64Download(String(fr.result).split(',')[1],n,blob.type||'application/octet-stream')};fr.readAsDataURL(blob)}).catch(function(){alert('download failed')});}}catch(ex){console.error(ex)}},true);})();";
    mWebView.evaluateJavascript(js, null);
  }

  public String prettyUrl(String url) {
    if (url == null) return "";
    if (url.startsWith("this://")) return url;
    if (url.equals(NEWTAB_PATH) || url.equals(NEWTAB_PATH + "/")) return NEWTAB_URL;
    if (url.equals(SETTINGS_PATH) || url.equals(SETTINGS_PATH + "/")) return SETTINGS_URL;
    if (url.startsWith(ASSET_PATH)) return "this://" + url.substring(ASSET_PATH.length());
    if (url.startsWith(ASSET_BASE)) {
      String p = url.substring(ASSET_BASE.length());
      while (p.startsWith("/")) p = p.substring(1);
      if (p.isEmpty()) p = "index.html";
      return "this://" + p;
    }
    return url;
  }

  public void loadUrl(String url) {
    if (mWebView == null) return;
    if (url == null || url.isEmpty()) url = HOME_URL;
    showingError = false;
    String lower = url.toLowerCase();
    if (lower.startsWith("about://")) {
      url = "this://" + url.substring(8);
      lower = url.toLowerCase();
    }
    if (lower.startsWith("this://")) {
      String path = url.substring(7);
      while (path.startsWith("/")) path = path.substring(1);
      if (path.toLowerCase().startsWith("app/")) path = path.substring(4);
      String lpath = path.toLowerCase();
      if (lpath.equals("newtab") || lpath.equals("newtab.html")) {
        mWebView.loadUrl(NEWTAB_PATH);
        return;
      }
      if (lpath.equals("settings") || lpath.equals("setting") || lpath.equals("settings.html")) {
        mWebView.loadUrl(SETTINGS_PATH);
        return;
      }
      if (path.isEmpty()) path = "index.html";
      mWebView.loadUrl(ASSET_PATH + path);
      return;
    }
    if (lower.startsWith("file://")) {
      toast(getString(R.string.err_file_not_allowed));
      mWebView.loadUrl(ASSET_PATH + "index.html");
      return;
    }
    mWebView.loadUrl(url);
  }

  public void newTab(String url, boolean incognito) {
    Tab t = new Tab(url, incognito);
    t.webView = createNewWebView();
    t.webView.setVisibility(View.GONE);
    webViewContainer.addView(t.webView);
    tabs.add(t);
    
    if (mWebView != null) {
        mWebView.setVisibility(View.GONE);
    }
    
    activeTabIndex = tabs.size() - 1;
    mWebView = t.webView;
    mWebView.setVisibility(View.VISIBLE);
    
    renderTabs();
    loadUrl(url);
    if (!incognito) saveTabs();
  }

  public void switchTab(int i) {
    if (i < 0 || i >= tabs.size()) return;
    if (i == activeTabIndex) return;
    
    if (mWebView != null) {
      mWebView.setVisibility(View.GONE);
      Tab current = tabs.get(activeTabIndex);
      if (mWebView.getUrl() != null) current.url = mWebView.getUrl();
      if (mWebView.getTitle() != null) current.title = mWebView.getTitle();
    }
    
    activeTabIndex = i;
    mWebView = tabs.get(i).webView;
    mWebView.setVisibility(View.VISIBLE);
    
    renderTabs();
    if (mWebView.getUrl() == null) {
        loadUrl(tabs.get(i).url);
    } else {
        urlBar.setText(prettyUrl(mWebView.getUrl()));
        updateSecurityIndicator(mWebView.getUrl());
        updateNavigationControls();
    }
  }

  public void closeTab(int i) {
    if (i < 0 || i >= tabs.size()) return;
    Tab t = tabs.remove(i);
    if (t.webView != null) {
        if (t.webView.getParent() != null) {
            ((ViewGroup)t.webView.getParent()).removeView(t.webView);
        }
        t.webView.destroy();
    }
    
    if (tabs.size() == 0) {
        finish();
        return;
    }
    
    if (i == activeTabIndex) {
        activeTabIndex = Math.min(activeTabIndex, tabs.size() - 1);
        mWebView = tabs.get(activeTabIndex).webView;
        mWebView.setVisibility(View.VISIBLE);
        urlBar.setText(prettyUrl(mWebView.getUrl()));
        updateSecurityIndicator(mWebView.getUrl());
        updateNavigationControls();
    } else if (i < activeTabIndex) {
        activeTabIndex--;
    }
    
    renderTabs();
    saveTabs();
  }

  public void closeAllTabs() {
    for (Tab t : tabs) {
        if (t.webView != null) {
            if (t.webView.getParent() != null) {
                ((ViewGroup)t.webView.getParent()).removeView(t.webView);
            }
            t.webView.destroy();
        }
    }
    tabs.clear();
    
    String homeUrl = getHomePageUrl();
    Tab homeTab = new Tab(homeUrl, false);
    homeTab.title = prettyUrl(homeUrl);
    homeTab.ephemeral = HOME_URL.equals(homeUrl);
    homeTab.webView = createNewWebView();
    webViewContainer.addView(homeTab.webView);
    
    tabs.add(homeTab);
    activeTabIndex = 0;
    mWebView = homeTab.webView;
    mWebView.setVisibility(View.VISIBLE);
    
    renderTabs();
    loadUrl(homeUrl);
    saveTabs();
  }

  public void renderTabs() {
    if (btnTabCount != null) {
      int n = tabs.size();
      btnTabCount.setText(n > 99 ? "99+" : String.valueOf(n));
    }
    if (tabsContainer == null) return;
    tabsContainer.removeAllViews();
    for (int i = 0; i < tabs.size(); i++) {
      final int index = i;
      Tab tab = tabs.get(i);
      LinearLayout chip = new LinearLayout(this);
      chip.setOrientation(LinearLayout.HORIZONTAL);
      chip.setGravity(Gravity.CENTER_VERTICAL);
      chip.setPadding(dp(9), 0, dp(5), 0);
      GradientDrawable chipBg = new GradientDrawable();
      chipBg.setColor(i == activeTabIndex ? 0xFF23364A : 0xFF111923);
      chipBg.setCornerRadii(new float[] {dp(9), dp(9), dp(9), dp(9), 0, 0, 0, 0});
      if (i == activeTabIndex) chipBg.setStroke(dp(1), 0xFF304B65);
      chip.setBackground(chipBg);
      LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(dp(184), dp(34));
      chipLp.setMargins(dp(2), 0, dp(3), 0);
      chip.setLayoutParams(chipLp);

      TextView title = new TextView(this);
      String tabTitle = tab.title == null || tab.title.trim().isEmpty() ? getString(R.string.br_new_tab) : tab.title;
      title.setText(tabTitle.replace('\n', ' '));
      title.setTextColor(i == activeTabIndex ? 0xFFF0F5FB : 0xFF9BAEC3);
      title.setTextSize(12);
      title.setSingleLine(true);
      title.setEllipsize(android.text.TextUtils.TruncateAt.END);
      title.setGravity(Gravity.CENTER_VERTICAL);
      title.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1));
      chip.addView(title);

      TextView close = new TextView(this);
      close.setText("×");
      close.setTextSize(19);
      close.setTextColor(i == activeTabIndex ? 0xFFE3EDF8 : 0xFF7F91A5);
      close.setGravity(Gravity.CENTER);
      close.setBackground(makeRoundDrawable(0x332F4054, dp(8)));
      LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(25), dp(25));
      closeLp.setMargins(dp(4), 0, 0, 0);
      close.setLayoutParams(closeLp);
      close.setContentDescription(getString(R.string.br_close_tab));
      close.setOnClickListener(v -> { haptic(); closeTab(index); });
      chip.addView(close);
      chip.setOnClickListener(v -> { haptic(); if (index != activeTabIndex) switchTab(index); });
      tabsContainer.addView(chip);
    }
    updateNavigationControls();
  }

  public GradientDrawable makeRoundDrawable(int color, int radius) {
    GradientDrawable d = new GradientDrawable();
    d.setColor(color);
    d.setCornerRadius(radius);
    return d;
  }

  public void updateNavigationControls() {
    boolean canBack = mWebView != null && mWebView.canGoBack();
    boolean canForward = mWebView != null && mWebView.canGoForward();
    if (btnBack != null) btnBack.setAlpha(canBack ? 1f : 0.42f);
    if (btnForward != null) btnForward.setAlpha(canForward ? 1f : 0.42f);
  }

  public void saveUiState() {
    try {
      SharedPreferences.Editor e = getSharedPreferences(PREF_UI, Context.MODE_PRIVATE).edit();
      e.putBoolean("desktopMode", desktopMode);
      e.putFloat("currentZoom", currentZoom);
      e.apply();
    } catch (Exception ignored) {}
  }

  public void restoreUiState() {
    try {
      SharedPreferences sp = getSharedPreferences(PREF_UI, Context.MODE_PRIVATE);
      desktopMode = sp.getBoolean("desktopMode", false);
      currentZoom = sp.getFloat("currentZoom", 100f);
      if (currentZoom < 25f || currentZoom > 300f) currentZoom = 100f;
      if (mWebView == null) return;
      WebSettings s = mWebView.getSettings();
      if (desktopMode) {
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
      }
      applyUserAgent();
      s.setTextZoom((int) currentZoom);
    } catch (Exception ignored) {}
  }

  public void saveTabs() {
    try {
      JSONArray arr = new JSONArray();
      for (Tab t : tabs) {
        if (t.incognito || t.ephemeral) continue;
        JSONObject o = new JSONObject();
        o.put("url", t.url == null ? "" : t.url);
        o.put("title", t.title == null ? "" : t.title);
        o.put("favicon", t.favicon == null ? "" : t.favicon);
        arr.put(o);
      }
      getSharedPreferences(PREF_TABS, Context.MODE_PRIVATE).edit()
          .putString("list", arr.toString()).apply();
    } catch (Exception ignored) {}
  }

  public void restoreTabs() {
    String homeUrl = getHomePageUrl();
    boolean homeIsCalc = HOME_URL.equals(homeUrl);

    List<Tab> saved = new ArrayList<>();
    try {
      SharedPreferences sp = getSharedPreferences(PREF_TABS, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        String u = o.optString("url");
        if (u == null || u.isEmpty()) continue;
        String l = u.toLowerCase();
        if (homeIsCalc) {
          if (l.contains("index.html") && !l.contains("newtab")) continue;
        } else {
          if (isNewtabUrl(u)) continue;
        }
        Tab t = new Tab(u, false);
        t.title = o.optString("title");
        t.favicon = o.optString("favicon");
        saved.add(t);
      }
    } catch (Exception ignored) {}

    Tab homeTab = new Tab(homeUrl, false);
    homeTab.title = prettyUrl(homeUrl);
    homeTab.ephemeral = homeIsCalc;
    homeTab.webView = createNewWebView();
    webViewContainer.addView(homeTab.webView);

    tabs.clear();
    tabs.add(homeTab);
    
    for (Tab t : saved) {
        t.webView = createNewWebView();
        t.webView.setVisibility(View.GONE);
        webViewContainer.addView(t.webView);
        tabs.add(t);
    }
    
    activeTabIndex = 0;
    mWebView = tabs.get(0).webView;
    mWebView.setVisibility(View.VISIBLE);
    
    renderTabs();
    loadUrl(tabs.get(0).url);
  }

  public void historyAdd(String title, String url) {
    if (url == null || url.isEmpty()) return;
    if (url.startsWith("about:")) return;
    if (isInternalUrl(url)) return;
    String lower = url.toLowerCase();
    if (lower.startsWith("file://")) return;
    if (lower.startsWith("content://")) return;
    if (lower.startsWith("data:")) return;
    try {
      SharedPreferences sp = getSharedPreferences(PREF_HISTORY, Context.MODE_PRIVATE);
      JSONArray old = new JSONArray(sp.getString("list", "[]"));
      JSONArray out = new JSONArray();
      JSONObject o = new JSONObject();
      o.put("title", title);
      o.put("url", url);
      o.put("ts", System.currentTimeMillis());
      out.put(o);
      int count = 1;
      for (int i = 0; i < old.length() && count < MAX_HISTORY_ITEMS; i++) {
        JSONObject item = old.getJSONObject(i);
        if (url.equals(item.optString("url"))) continue;
        out.put(item);
        count++;
      }
      sp.edit().putString("list", out.toString()).apply();
    } catch (Exception ignored) {}
  }

  public List<String[]> historyGetAll() {
    List<String[]> list = new ArrayList<>();
    try {
      SharedPreferences sp = getSharedPreferences(PREF_HISTORY, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        String url = o.optString("url");
        if (url.toLowerCase().startsWith("file://")) continue;
        if (isInternalUrl(url)) continue;
        list.add(new String[]{o.optString("title"), url});
      }
    } catch (Exception ignored) {}
    return list;
  }

  public void historyClear() {
    getSharedPreferences(PREF_HISTORY, Context.MODE_PRIVATE).edit().clear().apply();
  }

  public void historyRemove(String url) {
    try {
      SharedPreferences sp = getSharedPreferences(PREF_HISTORY, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      JSONArray out = new JSONArray();
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        if (!url.equals(o.optString("url"))) out.put(o);
      }
      sp.edit().putString("list", out.toString()).apply();
    } catch (Exception ignored) {}
  }

  public String buildHistoryJson() {
    try {
      List<String[]> list = historyGetAll();
      JSONArray arr = new JSONArray();
      int max = Math.min(list.size(), HISTORY_PREVIEW);
      for (int i = 0; i < max; i++) {
        JSONObject o = new JSONObject();
        o.put("title", list.get(i)[0]);
        o.put("url", list.get(i)[1]);
        o.put("favicon", faviconUrl(list.get(i)[1]));
        arr.put(o);
      }
      return arr.toString();
    } catch (Exception e) { return "[]"; }
  }

  public void bookmarksAdd(String title, String url) {
    try {
      SharedPreferences sp = getSharedPreferences(PREF_BOOKMARKS, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      for (int i = 0; i < arr.length(); i++) {
        if (url.equals(arr.getJSONObject(i).optString("url"))) return;
      }
      JSONArray out = new JSONArray();
      JSONObject o = new JSONObject();
      o.put("title", title);
      o.put("url", url);
      o.put("ts", System.currentTimeMillis());
      out.put(o);
      for (int i = 0; i < arr.length(); i++) out.put(arr.get(i));
      sp.edit().putString("list", out.toString()).apply();
    } catch (Exception ignored) {}
  }

  public void bookmarksRemove(String url) {
    try {
      SharedPreferences sp = getSharedPreferences(PREF_BOOKMARKS, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      JSONArray out = new JSONArray();
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        if (!url.equals(o.optString("url"))) out.put(o);
      }
      sp.edit().putString("list", out.toString()).apply();
    } catch (Exception ignored) {}
  }

  public List<String[]> bookmarksGetAll() {
    List<String[]> list = new ArrayList<>();
    try {
      SharedPreferences sp = getSharedPreferences(PREF_BOOKMARKS, Context.MODE_PRIVATE);
      JSONArray arr = new JSONArray(sp.getString("list", "[]"));
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        list.add(new String[]{o.optString("title"), o.optString("url")});
      }
    } catch (Exception ignored) {}
    return list;
  }

  public boolean isBookmarked(String url) {
    if (url == null) return false;
    for (String[] b : bookmarksGetAll()) if (url.equals(b[1])) return true;
    return false;
  }

  public void toggleBookmark() {
    String url = mWebView == null ? null : mWebView.getUrl();
    if (url == null) return;
    if (isInternalUrl(url)) { toast(getString(R.string.br_cant_bookmark_internal)); return; }
    String title = mWebView.getTitle() != null ? mWebView.getTitle() : url;
    if (isBookmarked(url)) {
      bookmarksRemove(url);
      toast(getString(R.string.br_bookmark_removed));
    } else {
      bookmarksAdd(title, url);
      toast(getString(R.string.br_bookmarked));
    }
  }

  public String getSettingsHtml() {
    if (settingsHtmlCache != null) return settingsHtmlCache;
    try {
      String html = readRawText(this, R.raw.settings);
      JSONObject labels = new JSONObject();
      labels.put("title", stripLeadingSymbols(getString(R.string.settings_title)));
      labels.put("subtitle", getString(R.string.settings_subtitle));
      labels.put("sec_search", getString(R.string.settings_section_search));
      labels.put("lbl_language", getString(R.string.settings_language));
      labels.put("sec_view", getString(R.string.settings_section_view));
      labels.put("sec_adblock", getString(R.string.settings_section_adblock));
      labels.put("sec_data", getString(R.string.settings_section_data));
      labels.put("lbl_engine", getString(R.string.settings_engine));
      labels.put("lbl_home", getString(R.string.settings_home));
      labels.put("lbl_desktop", getString(R.string.settings_desktop));
      labels.put("desc_desktop", getString(R.string.settings_desc_desktop));
      labels.put("lbl_zoom", getString(R.string.settings_zoom));
      labels.put("lbl_ua", stripLeadingSymbols(getString(R.string.menu_custom_ua)));
      labels.put("desc_ua", getString(R.string.settings_desc_ua));
      labels.put("lbl_adblock", getString(R.string.settings_adblock));
      labels.put("lbl_ai", getString(R.string.settings_adblock_ai));
      labels.put("badge_beta", getString(R.string.settings_badge_beta));
      labels.put("desc_ai", getString(R.string.settings_adblock_ai_desc));
      labels.put("lbl_stats", getString(R.string.settings_adblock_stats));
      labels.put("lbl_clr_hist", getString(R.string.settings_clear_history));
      labels.put("lbl_clr_bm", stripLeadingSymbols(getString(R.string.settings_clear_bookmarks)));
      labels.put("lbl_clr_cache", stripLeadingSymbols(getString(R.string.menu_clear_cache)));
      labels.put("lbl_clr_cookies", stripLeadingSymbols(getString(R.string.menu_clear_cookies)));
      labels.put("lbl_manage_bookmarks", stripLeadingSymbols(getString(R.string.settings_manage_bookmarks)));
      labels.put("lbl_clear_all_data", stripLeadingSymbols(getString(R.string.settings_clear_all_browser_data)));
      labels.put("lbl_reset_settings", stripLeadingSymbols(getString(R.string.settings_reset_browser_settings)));
      labels.put("about", getString(R.string.app_name));
      labels.put("ver_label", getString(R.string.settings_version));
      labels.put("lang", getResources().getConfiguration().locale.getLanguage());
      labels.put("language", getLanguageName(AppLanguage.get(this)));
      labels.put("lang_dir", appStartGravity() == Gravity.RIGHT ? "rtl" : "ltr");
      settingsHtmlCache = html.replace("<!--STRINGS-->", "<script>window.__strings=" + labels.toString() + ";</script>");
      return settingsHtmlCache;
    } catch (Exception e) {
      return "<!DOCTYPE html><html><body style='background:#0a0e1a;color:#eaf0fa;padding:40px;font-family:sans-serif'>settings not found</body></html>";
    }
  }

  public static String stripLeadingSymbols(String value) {
    if (value == null) return "";
    int i = 0;
    while (i < value.length() && !Character.isLetterOrDigit(value.charAt(i))) i++;
    return value.substring(i).trim();
  }

  public Map<String, String> corsHeaders() {
    Map<String, String> h = new HashMap<>();
    h.put("Access-Control-Allow-Origin", "*");
    h.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    h.put("Access-Control-Allow-Headers", "*");
    h.put("Cache-Control", "no-cache");
    return h;
  }

  public WebResourceResponse htmlResponse(String html, int status, String reason) {
    try {
      InputStream is = new ByteArrayInputStream(html.getBytes("UTF-8"));
      return new WebResourceResponse("text/html", "UTF-8", status, reason, corsHeaders(), is);
    } catch (Exception e) { return null; }
  }

  public String errorHtml(String code, String desc, String url) {
    return "<!DOCTYPE html><html lang='en'><head>" +
        "<meta charset='UTF-8'>" +
        "<meta name='viewport' content='width=device-width,initial-scale=1,user-scalable=no'>" +
        "<title>" + escapeHtml(code) + "</title><style>" +
        "*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}" +
        "html,body{height:100%;overflow:hidden}" +
        "body{background:#202124;color:#e8eaed;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;" +
        "display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 24px;text-align:center;gap:16px;min-height:100vh}" +
        ".icon{font-size:96px;line-height:1;opacity:.85;margin-bottom:4px}" +
        ".code{font-size:22px;font-weight:500;color:#e8eaed;letter-spacing:.5px;margin-top:4px}" +
        ".desc{font-size:14px;color:#9aa0a6;max-width:360px;line-height:1.6;margin-top:2px}" +
        ".url{font-size:12px;color:#5f6368;max-width:340px;margin-top:12px;padding:8px 14px;background:#292a2d;border-radius:8px;word-break:break-all;font-family:monospace}" +
        ".btn{margin-top:20px;padding:11px 26px;border-radius:22px;border:none;background:#8ab4f8;color:#202124;font-size:14px;font-weight:500;cursor:pointer;font-family:inherit;transition:.15s}" +
        ".btn:hover{background:#aecbfa}.btn:active{transform:scale(.95)}" +
        "</style></head><body>" +
        "<div class='icon'>☁️</div>" +
        "<div class='code'>" + escapeHtml(code) + "</div>" +
        "<div class='desc'>" + escapeHtml(desc) + "</div>" +
        (url != null && !url.isEmpty() ? "<div class='url'>" + escapeHtml(url) + "</div>" : "") +
        "<button class='btn' onclick='location.reload()'>" + escapeHtml(getString(R.string.error_reload)) + "</button>" +
        "</body></html>";
  }

  public String escapeHtml(String s) {
    if (s == null) return "";
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&#39;");
  }

  public void showErrorPage(String code, String desc, String failedUrl) {
    if (mWebView == null) return;
    showingError = true;
    String html = errorHtml(code, desc, failedUrl);
    urlBar.setText(prettyUrl(failedUrl));
    mWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
  }

  public String webErrorCode(int errorCode) {
    switch (errorCode) {
      case WebViewClient.ERROR_HOST_LOOKUP: return "ERR_NAME_NOT_RESOLVED";
      case WebViewClient.ERROR_CONNECT: return "ERR_CONNECTION_REFUSED";
      case WebViewClient.ERROR_TIMEOUT: return "ERR_TIMED_OUT";
      case WebViewClient.ERROR_FAILED_SSL_HANDSHAKE: return "ERR_SSL_PROTOCOL_ERROR";
      case WebViewClient.ERROR_BAD_URL: return "ERR_INVALID_URL";
      case WebViewClient.ERROR_FILE_NOT_FOUND: return "ERR_FILE_NOT_FOUND";
      case WebViewClient.ERROR_FILE: return "ERR_FILE_ERROR";
      case WebViewClient.ERROR_UNSUPPORTED_SCHEME: return "ERR_UNSUPPORTED_SCHEME";
      case WebViewClient.ERROR_TOO_MANY_REQUESTS: return "ERR_TOO_MANY_REQUESTS";
      case WebViewClient.ERROR_REDIRECT_LOOP: return "ERR_TOO_MANY_REDIRECTS";
      case WebViewClient.ERROR_UNKNOWN: return "ERR_FAILED";
      case WebViewClient.ERROR_IO: return "ERR_IO_ERROR";
      case WebViewClient.ERROR_PROXY_AUTHENTICATION: return "ERR_PROXY_AUTH";
      case WebViewClient.ERROR_AUTHENTICATION: return "ERR_AUTH_REQUIRED";
      default: return "ERR_FAILED";
    }
  }

  public String webErrorDesc(int errorCode) {
    switch (errorCode) {
      case WebViewClient.ERROR_HOST_LOOKUP: return getString(R.string.err_dns);
      case WebViewClient.ERROR_CONNECT: return getString(R.string.err_conn);
      case WebViewClient.ERROR_TIMEOUT: return getString(R.string.err_timeout);
      case WebViewClient.ERROR_FAILED_SSL_HANDSHAKE: return getString(R.string.err_ssl);
      case WebViewClient.ERROR_BAD_URL: return getString(R.string.err_bad_url);
      case WebViewClient.ERROR_FILE_NOT_FOUND: return getString(R.string.err_file_not_found);
      case WebViewClient.ERROR_UNSUPPORTED_SCHEME: return getString(R.string.err_scheme);
      case WebViewClient.ERROR_TOO_MANY_REQUESTS: return getString(R.string.err_too_many);
      case WebViewClient.ERROR_REDIRECT_LOOP: return getString(R.string.err_redirect);
      default: return getString(R.string.err_generic);
    }
  }

  public String httpErrorCode(int status) {
    switch (status) {
      case 400: return "ERR_HTTP_400_BAD_REQUEST";
      case 401: return "ERR_HTTP_401_UNAUTHORIZED";
      case 403: return "ERR_HTTP_403_FORBIDDEN";
      case 404: return "ERR_HTTP_404_NOT_FOUND";
      case 500: return "ERR_HTTP_500_INTERNAL_SERVER_ERROR";
      case 502: return "ERR_HTTP_502_BAD_GATEWAY";
      case 503: return "ERR_HTTP_503_SERVICE_UNAVAILABLE";
      case 504: return "ERR_HTTP_504_GATEWAY_TIMEOUT";
      default: return "ERR_HTTP_" + status;
    }
  }

  public View iconButton(String txt, View.OnClickListener click) {
    int circleSize = dp(38);
    FrameLayout cell = new FrameLayout(this);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
    cell.setLayoutParams(lp);

    FrameLayout circle = new FrameLayout(this);
    GradientDrawable circleBg = new GradientDrawable();
    circleBg.setShape(GradientDrawable.OVAL);
    circleBg.setColor(0xFF2A3A4D);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      RippleDrawable ripple = new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), circleBg, null);
      circle.setBackground(ripple);
    } else {
      circle.setBackground(circleBg);
    }
    FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(circleSize, circleSize);
    clp.gravity = Gravity.CENTER;
    circle.setLayoutParams(clp);

    TextView tv = new TextView(this);
    tv.setText(txt);
    tv.setTextColor(COLOR_TEXT);
    tv.setIncludeFontPadding(false);
    tv.setGravity(Gravity.CENTER);
    int textSize = 20;
    float translationY = 0f;
    if (txt.equals(getString(R.string.br_back))) { textSize = 22; translationY = -2f; }
    else if (txt.equals(getString(R.string.br_forward))) { textSize = 20; translationY = 0f; }
    tv.setTextSize(textSize);
    tv.setTranslationY(translationY * getResources().getDisplayMetrics().density);

    FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
    flp.gravity = Gravity.CENTER;
    tv.setLayoutParams(flp);

    circle.addView(tv);
    cell.addView(circle);
    cell.setOnClickListener(v -> { haptic(); click.onClick(v); });
    return cell;
  }

  public TextView sectionHeader(String text) {
    TextView tv = new TextView(this);
    tv.setText(text);
    tv.setTextSize(10);
    tv.setTextColor(COLOR_ACCENT);
    tv.setLetterSpacing(0.12f);
    tv.setAllCaps(true);
    tv.setPadding(dp(16), dp(14), dp(16), dp(6));
    tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    tv.setGravity(appStartGravity() | Gravity.CENTER_VERTICAL);
    return tv;
  }

  public void showAddHomeShortcutDialog() {
    String url = mWebView == null ? "" : mWebView.getUrl();
    if (url == null || url.trim().isEmpty() || url.startsWith("this://") || url.startsWith("about:") || url.startsWith("file:") || url.startsWith("data:")) {
      toast(getString(R.string.err_cant_shortcut_internal));
      return;
    }
    String defaultName = mWebView.getTitle();
    if (defaultName == null || defaultName.trim().isEmpty()) defaultName = Uri.parse(url).getHost();
    if (defaultName == null || defaultName.trim().isEmpty()) defaultName = url;
    final String fallbackName = defaultName;
    EditText nameInput = new EditText(this);
    nameInput.setSingleLine(true);
    nameInput.setText(defaultName);
    nameInput.setSelectAllOnFocus(true);
    nameInput.setHint(R.string.shortcut_name_hint);
    int pad = dp(20);
    nameInput.setPadding(pad, dp(12), pad, dp(12));
    LinearLayout content = new LinearLayout(this);
    content.setOrientation(LinearLayout.VERTICAL);
    content.setPadding(dp(24), dp(8), dp(24), 0);
    TextView prompt = new TextView(this);
    prompt.setText(R.string.shortcut_name_prompt);
    prompt.setTextColor(COLOR_TEXT);
    prompt.setTextSize(14);
    content.addView(prompt);
    content.addView(nameInput);
    AlertDialog dialog = new AlertDialog.Builder(this)
        .setTitle(R.string.menu_add_home)
        .setView(content)
        .setPositiveButton(R.string.action_confirm, (d, which) -> {
          String name = nameInput.getText().toString().trim();
          if (name.isEmpty()) name = fallbackName;
          createHomeShortcut(name, url);
        })
        .setNegativeButton(R.string.action_cancel, null)
        .create();
    dialog.setOnShowListener(d -> {
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(COLOR_ACCENT);
      dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(COLOR_TEXT_SUB);
    });
    dialog.show();
  }

  public void createHomeShortcut(String name, String url) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
      toast(getString(R.string.toast_shortcut_unsupported));
      return;
    }
    ShortcutManager manager = getSystemService(ShortcutManager.class);
    if (manager == null || !manager.isRequestPinShortcutSupported()) {
      toast(getString(R.string.toast_shortcut_unsupported));
      return;
    }
    Bitmap iconBitmap = currentFaviconBitmap;
    if (iconBitmap == null || iconBitmap.isRecycled()) iconBitmap = createLetterShortcutIcon(name);
    Intent launch = new Intent(Intent.ACTION_VIEW, Uri.parse(url), this, MainActivity.class);
    launch.setComponent(new ComponentName(this, MainActivity.class));
    launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    ShortcutInfo shortcut = new ShortcutInfo.Builder(this, "site_" + Integer.toHexString(url.hashCode()))
        .setShortLabel(name.length() > 40 ? name.substring(0, 40) : name)
        .setLongLabel(name)
        .setIcon(Icon.createWithBitmap(iconBitmap))
        .setIntent(launch)
        .build();
    try {
      boolean accepted = manager.requestPinShortcut(shortcut, null);
      toast(getString(accepted ? R.string.toast_shortcut_added : R.string.toast_shortcut_failed));
    } catch (Exception e) {
      toast(getString(R.string.toast_shortcut_failed));
    }
  }

  public Bitmap createLetterShortcutIcon(String name) {
    int size = dp(96);
    Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
    Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    paint.setColor(night ? 0xFF244D83 : 0xFF3F83D5);
    canvas.drawRoundRect(0, 0, size, size, size * 0.22f, size * 0.22f, paint);
    String letter = name == null || name.trim().isEmpty() ? "?" : name.trim().substring(0, 1).toUpperCase(java.util.Locale.getDefault());
    paint.setColor(Color.WHITE);
    paint.setTextAlign(Paint.Align.CENTER);
    paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
    paint.setTextSize(size * 0.56f);
    Paint.FontMetrics metrics = paint.getFontMetrics();
    canvas.drawText(letter, size / 2f, size / 2f - (metrics.ascent + metrics.descent) / 2f, paint);
    return bitmap;
  }

  public void addMenuItem(LinearLayout parent, Dialog dialog, String text, Runnable action) {
    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setGravity(Gravity.CENTER_VERTICAL);
    row.setPadding(dp(14), dp(10), dp(14), dp(10));

    TextView tv = new TextView(this);
    tv.setText(text);
    tv.setTextSize(13);
    tv.setTextColor(COLOR_TEXT);
    tv.setGravity(appStartGravity() | Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    tv.setLayoutParams(lp);
    row.addView(tv);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      GradientDrawable bg = new GradientDrawable();
      bg.setColor(0x00000000);
      bg.setCornerRadius(dp(10));
      RippleDrawable ripple = new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null);
      row.setBackground(ripple);
    }
    row.setOnClickListener(v -> {
      haptic();
      dialog.dismiss();
      action.run();
    });
    parent.addView(row);
  }

  public void addMenuDivider(LinearLayout parent) {
    View divider = new View(this);
    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
    lp.leftMargin = dp(12);
    lp.rightMargin = dp(12);
    lp.topMargin = dp(4);
    lp.bottomMargin = dp(4);
    divider.setLayoutParams(lp);
    divider.setBackgroundColor(COLOR_BORDER);
    parent.addView(divider);
  }

  public void showTabsDialog() {
    if (tabs.size() == 1) { toast(getString(R.string.br_only_one_tab)); return; }

    LinearLayout container = new LinearLayout(this);
    container.setOrientation(LinearLayout.VERTICAL);
    container.setPadding(dp(8), dp(8), dp(8), dp(8));

    GradientDrawable dialogBg = new GradientDrawable();
    dialogBg.setColor(COLOR_BG_INPUT);
    dialogBg.setCornerRadius(dp(16));
    container.setBackground(dialogBg);

    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(Color.TRANSPARENT);
    scroll.addView(container);

    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    for (int i = 0; i < tabs.size(); i++) {
      final int idx = i;
      Tab t = tabs.get(i);

      LinearLayout row = new LinearLayout(this);
      row.setOrientation(LinearLayout.HORIZONTAL);
      row.setGravity(Gravity.CENTER_VERTICAL);
      row.setPadding(dp(10), dp(10), dp(10), dp(10));
      LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
      rowLp.bottomMargin = dp(4);
      row.setLayoutParams(rowLp);

      GradientDrawable rowBg = new GradientDrawable();
      rowBg.setCornerRadius(dp(12));
      rowBg.setColor(idx == activeTabIndex ? COLOR_ACCENT_DARK : COLOR_BG_BTN);
      row.setBackground(rowBg);

      FrameLayout favWrap = new FrameLayout(this);
      LinearLayout.LayoutParams favLp = new LinearLayout.LayoutParams(dp(32), dp(32));
      favWrap.setLayoutParams(favLp);

      GradientDrawable favBg = new GradientDrawable();
      favBg.setShape(GradientDrawable.OVAL);
      favBg.setColor(0xFF202124);
      favWrap.setBackground(favBg);

      ImageView favImg = new ImageView(this);
      FrameLayout.LayoutParams imgLp = new FrameLayout.LayoutParams(dp(20), dp(20));
      imgLp.gravity = Gravity.CENTER;
      favImg.setLayoutParams(imgLp);
      favImg.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
      favWrap.addView(favImg);

      if (t.incognito) {
        TextView incog = new TextView(this);
        FrameLayout.LayoutParams incogLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        incogLp.gravity = Gravity.CENTER;
        incog.setLayoutParams(incogLp);
        incog.setText("🕶");
        incog.setTextSize(14);
        favWrap.addView(incog);
      } else if (t.ephemeral) {
        TextView ico = new TextView(this);
        FrameLayout.LayoutParams icoLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        icoLp.gravity = Gravity.CENTER;
        ico.setLayoutParams(icoLp);
        ico.setText("🧮");
        ico.setTextSize(14);
        favWrap.addView(ico);
      } else {
        loadFaviconAsync(favImg, t.url);
      }

      row.addView(favWrap);
      row.addView(spacer(12));

      LinearLayout textBox = new LinearLayout(this);
      textBox.setOrientation(LinearLayout.VERTICAL);
      textBox.setGravity(appStartGravity());
      LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
          0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
      textBox.setLayoutParams(textLp);

      TextView titleView = new TextView(this);
      String title = t.title == null || t.title.isEmpty() ? prettyUrl(t.url) : t.title;
      if (title.length() > 40) title = title.substring(0, 40) + "…";
      titleView.setText(title);
      titleView.setTextColor(COLOR_TEXT);
      titleView.setTextSize(14);
      titleView.setSingleLine();
      titleView.setEllipsize(TextUtils.TruncateAt.END);
      titleView.setGravity(appStartGravity());
      textBox.addView(titleView);

      TextView urlView = new TextView(this);
      String u = prettyUrl(t.url);
      if (u.length() > 45) u = u.substring(0, 45) + "…";
      urlView.setText(u);
      urlView.setTextColor(COLOR_TEXT_SUB);
      urlView.setTextSize(11);
      urlView.setSingleLine();
      urlView.setEllipsize(TextUtils.TruncateAt.END);
      urlView.setGravity(appStartGravity());
      textBox.addView(urlView);

      row.addView(textBox);
      row.addView(spacer(8));

      TextView close = new TextView(this);
      close.setText("✕");
      close.setTextColor(COLOR_TEXT);
      close.setTextSize(16);
      close.setGravity(Gravity.CENTER);
      LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(32), dp(32));
      close.setLayoutParams(closeLp);
      close.setOnClickListener(v -> { haptic(); dialog.dismiss(); closeTab(idx); });
      row.addView(close);

      row.setOnClickListener(v -> { haptic(); dialog.dismiss(); switchTab(idx); });

      container.addView(row);
    }

    dialog.setContentView(scroll);
    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88),
          WindowManager.LayoutParams.WRAP_CONTENT);
    }
    dialog.show();
  }

  public void showMenu() {
    new com.calculator.app.core.ToggleMenu(this).show();
  }

  public void showZoomDialog() {
    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(20), dp(18), dp(20), dp(16));

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(COLOR_BG_INPUT);
    bg.setCornerRadius(dp(18));
    root.setBackground(bg);

    TextView title = new TextView(this);
    title.setText(getString(R.string.zoom_title));
    title.setTextColor(COLOR_TEXT);
    title.setTextSize(16);
    title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    title.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    titleLp.bottomMargin = dp(4);
    title.setLayoutParams(titleLp);
    root.addView(title);

    final TextView value = new TextView(this);
    value.setTextColor(COLOR_ACCENT);
    value.setTextSize(34);
    value.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    value.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams valLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    valLp.bottomMargin = dp(14);
    value.setLayoutParams(valLp);
    root.addView(value);

    final SeekBar seek = new SeekBar(this);
    seek.setMax(275);
    seek.setProgress((int) (currentZoom - 25));
    LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    seekLp.bottomMargin = dp(12);
    seek.setLayoutParams(seekLp);
    root.addView(seek);

    LinearLayout presets = new LinearLayout(this);
    presets.setOrientation(LinearLayout.HORIZONTAL);
    presets.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams presetsLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    presetsLp.bottomMargin = dp(14);
    presets.setLayoutParams(presetsLp);

    final int[] presetValues = {50, 75, 100, 125, 150, 200, 300};
    final List<TextView> presetViews = new ArrayList<>();
    for (int v : presetValues) {
      final int val = v;
      TextView p = new TextView(this);
      p.setText(String.valueOf(v));
      p.setTextSize(12);
      p.setTextColor(COLOR_TEXT_SUB);
      p.setGravity(Gravity.CENTER);
      p.setPadding(dp(10), dp(8), dp(10), dp(8));
      LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0,
          LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
      plp.leftMargin = dp(2);
      plp.rightMargin = dp(2);
      p.setLayoutParams(plp);

      GradientDrawable pbg = new GradientDrawable();
      pbg.setCornerRadius(dp(8));
      pbg.setColor(COLOR_BG_BTN);
      p.setBackground(pbg);

      p.setOnClickListener(vv -> { haptic(); seek.setProgress(val - 25); });
      presetViews.add(p);
      presets.addView(p);
    }

    final Runnable updatePresets = () -> {
      int cur = seek.getProgress() + 25;
      for (int i = 0; i < presetViews.size(); i++) {
        TextView p = presetViews.get(i);
        boolean active = presetValues[i] == cur;
        GradientDrawable pbg = new GradientDrawable();
        pbg.setCornerRadius(dp(8));
        pbg.setColor(active ? COLOR_ACCENT : COLOR_BG_BTN);
        p.setBackground(pbg);
        p.setTextColor(active ? 0xFFFFFFFF : COLOR_TEXT_SUB);
      }
    };

    final float originalZoom = currentZoom;

    seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
        int val = progress + 25;
        value.setText(val + "%");
        currentZoom = val;
        if (mWebView != null) mWebView.getSettings().setTextZoom(val);
        updatePresets.run();
      }
      @Override public void onStartTrackingTouch(SeekBar s) {}
      @Override public void onStopTrackingTouch(SeekBar s) {}
    });

    value.setText((int) currentZoom + "%");
    updatePresets.run();

    LinearLayout buttons = new LinearLayout(this);
    buttons.setOrientation(LinearLayout.HORIZONTAL);

    TextView reset = new TextView(this);
    reset.setText(getString(R.string.zoom_reset));
    reset.setTextColor(COLOR_TEXT);
    reset.setTextSize(13);
    reset.setGravity(Gravity.CENTER);
    reset.setPadding(dp(12), dp(11), dp(12), dp(11));
    LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    rlp.rightMargin = dp(4);
    reset.setLayoutParams(rlp);
    GradientDrawable rbg = new GradientDrawable();
    rbg.setCornerRadius(dp(10));
    rbg.setColor(COLOR_BG_BTN);
    reset.setBackground(rbg);
    reset.setOnClickListener(v -> { haptic(); seek.setProgress(75); });

    TextView ok = new TextView(this);
    ok.setText(getString(R.string.zoom_ok));
    ok.setTextColor(0xFFFFFFFF);
    ok.setTextSize(13);
    ok.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    ok.setGravity(Gravity.CENTER);
    ok.setPadding(dp(12), dp(11), dp(12), dp(11));
    LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    olp.leftMargin = dp(4);
    ok.setLayoutParams(olp);
    GradientDrawable obg = new GradientDrawable();
    obg.setCornerRadius(dp(10));
    obg.setColor(COLOR_ACCENT);
    ok.setBackground(obg);
    ok.setOnClickListener(v -> { haptic(); saveUiState(); dialog.dismiss(); });

    buttons.addView(reset);
    buttons.addView(ok);
    root.addView(buttons);

    dialog.setContentView(root);
    dialog.setOnCancelListener(d -> {
      currentZoom = originalZoom;
      if (mWebView != null) mWebView.getSettings().setTextZoom((int) currentZoom);
      saveUiState();
    });

    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88),
          WindowManager.LayoutParams.WRAP_CONTENT);
    }
    dialog.show();
  }

  public void showFindDialog() {
    if (mWebView == null) return;
    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(14), dp(14), dp(14), dp(12));

    GradientDrawable bg = new GradientDrawable();
    bg.setColor(COLOR_BG_INPUT);
    bg.setCornerRadius(dp(18));
    root.setBackground(bg);

    LinearLayout header = new LinearLayout(this);
    header.setOrientation(LinearLayout.HORIZONTAL);
    header.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams headerLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    headerLp.bottomMargin = dp(10);
    header.setLayoutParams(headerLp);

    TextView title = new TextView(this);
    title.setText(getString(R.string.find_title));
    title.setTextColor(COLOR_TEXT);
    title.setTextSize(14);
    title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    title.setGravity(appStartGravity() | Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    title.setLayoutParams(titleLp);
    header.addView(title);

    TextView close = new TextView(this);
    close.setText("✕");
    close.setTextColor(COLOR_TEXT_SUB);
    close.setTextSize(16);
    close.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(30), dp(30));
    close.setLayoutParams(closeLp);
    close.setOnClickListener(v -> {
      haptic();
      dialog.dismiss();
      if (mWebView != null) mWebView.clearMatches();
    });
    header.addView(close);

    root.addView(header);

    LinearLayout searchRow = new LinearLayout(this);
    searchRow.setOrientation(LinearLayout.HORIZONTAL);
    searchRow.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    srLp.bottomMargin = dp(8);
    searchRow.setLayoutParams(srLp);

    FrameLayout inputWrap = new FrameLayout(this);
    LinearLayout.LayoutParams iwLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
    iwLp.rightMargin = dp(5);
    inputWrap.setLayoutParams(iwLp);

    GradientDrawable inputBg = new GradientDrawable();
    inputBg.setCornerRadius(dp(12));
    inputBg.setColor(COLOR_BG_PANEL);
    inputBg.setStroke(dp(1), COLOR_BORDER);

    final EditText input = new EditText(this);
    input.setHint(getString(R.string.find_hint));
    input.setHintTextColor(COLOR_TEXT_SUB);
    input.setTextColor(COLOR_TEXT);
    input.setTextSize(13);
    input.setSingleLine(true);
    input.setBackground(null);
    input.setPadding(dp(12), 0, dp(12), 0);
    input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
    input.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
    input.setGravity(appStartGravity() | Gravity.CENTER_VERTICAL);
    FrameLayout.LayoutParams inLp = new FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
    input.setLayoutParams(inLp);

    View inputBgView = new View(this);
    inputBgView.setBackground(inputBg);

    inputWrap.addView(inputBgView);
    inputWrap.addView(input);

    searchRow.addView(inputWrap);

    TextView prev = new TextView(this);
    prev.setText("▲");
    prev.setTextColor(COLOR_TEXT);
    prev.setTextSize(12);
    prev.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dp(34), dp(38));
    pLp.rightMargin = dp(3);
    prev.setLayoutParams(pLp);
    GradientDrawable prevBg = new GradientDrawable();
    prevBg.setCornerRadius(dp(10));
    prevBg.setColor(COLOR_BG_BTN);
    prev.setBackground(prevBg);
    prev.setOnClickListener(v -> { haptic(); if (mWebView != null) mWebView.findNext(false); });
    searchRow.addView(prev);

    TextView next = new TextView(this);
    next.setText("▼");
    next.setTextColor(COLOR_TEXT);
    next.setTextSize(12);
    next.setGravity(Gravity.CENTER);
    LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(dp(34), dp(38));
    next.setLayoutParams(nLp);
    GradientDrawable nextBg = new GradientDrawable();
    nextBg.setCornerRadius(dp(10));
    nextBg.setColor(COLOR_BG_BTN);
    next.setBackground(nextBg);
    next.setOnClickListener(v -> { haptic(); if (mWebView != null) mWebView.findNext(true); });
    searchRow.addView(next);

    root.addView(searchRow);

    final TextView counter = new TextView(this);
    counter.setText("—");
    counter.setTextColor(COLOR_TEXT_SUB);
    counter.setTextSize(12);
    counter.setGravity(Gravity.CENTER);
    counter.setPadding(dp(8), dp(4), dp(8), dp(4));
    root.addView(counter);

    mWebView.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) -> {
      if (numberOfMatches == 0) {
        counter.setText(getString(R.string.find_no_result));
        counter.setTextColor(COLOR_DANGER);
      } else {
        counter.setText(getString(R.string.find_counter, activeMatchOrdinal + 1, numberOfMatches));
        counter.setTextColor(COLOR_SUCCESS);
      }
    });

    final Runnable doSearch = () -> {
      if (mWebView == null) return;
      String q = input.getText().toString();
      if (q.isEmpty()) {
        mWebView.clearMatches();
        counter.setText("—");
        counter.setTextColor(COLOR_TEXT_SUB);
      } else {
        mWebView.findAllAsync(q);
      }
    };

    input.addTextChangedListener(new TextWatcher() {
      @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
      @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
      @Override public void afterTextChanged(Editable s) { doSearch.run(); }
    });

    input.setOnEditorActionListener((v, actionId, event) -> {
      if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE
          || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
        if (mWebView != null) mWebView.findNext(true);
        return true;
      }
      return false;
    });

    dialog.setContentView(root);
    dialog.setOnDismissListener(d -> {
      if (mWebView != null) {
        try { mWebView.setFindListener(null); } catch (Exception ignored) {}
        mWebView.clearMatches();
      }
    });

    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9),
          WindowManager.LayoutParams.WRAP_CONTENT);
      w.setGravity(Gravity.BOTTOM);
      WindowManager.LayoutParams lp = w.getAttributes();
      lp.y = dp(20);
      w.setAttributes(lp);
    }
    dialog.show();
    input.requestFocus();
    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
  }

  public void toggleDevTools() {
    if (mWebView == null) return;

    mWebView.evaluateJavascript(
      "(function(){return !!(window.__devtools && window.__devtools.__ready);})()",
      value -> {
        if ("true".equals(value)) {
          mWebView.evaluateJavascript("window.__devtools.toggle();", null);
        } else {
          String js = getDevToolsJs();
          mWebView.evaluateJavascript(js, null);
          mWebView.postDelayed(() -> {
            if (mWebView != null) {
              mWebView.evaluateJavascript(
                "if(window.__devtools)window.__devtools.toggle();", null);
            }
          }, 250);
        }
      });
  }

  public void copyLink() {
    if (mWebView == null) return;
    String url = prettyUrl(mWebView.getUrl());
    if (url == null || url.isEmpty()) return;
    if (url.toLowerCase().startsWith("this://")) {
      toast(getString(R.string.err_cant_copy_internal));
      return;
    }
    try {
      ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
      if (cm != null) {
        cm.setPrimaryClip(ClipData.newPlainText("url", url));
        toast(getString(R.string.br_link_copied));
      }
    } catch (Exception e) { toast(getString(R.string.toast_failed, e.getMessage())); }
  }

  public void sharePage() {
    if (mWebView == null) return;
    String url = mWebView.getUrl();
    if (url == null) return;
    if (isInternalUrl(url)) { toast(getString(R.string.err_cant_share_internal)); return; }
    try {
      Intent i = new Intent(Intent.ACTION_SEND);
      i.setType("text/plain");
      String title = mWebView.getTitle();
      i.putExtra(Intent.EXTRA_TEXT, url);
      if (title != null) i.putExtra(Intent.EXTRA_SUBJECT, title);
      startActivity(Intent.createChooser(i, getString(R.string.br_share)));
    } catch (Exception e) { toast(getString(R.string.toast_failed, e.getMessage())); }
  }

  public void showBookmarks() {
    List<String[]> list = bookmarksGetAll();
    if (list.isEmpty()) { toast(getString(R.string.br_no_bookmarks)); return; }

    LinearLayout container = new LinearLayout(this);
    container.setOrientation(LinearLayout.VERTICAL);
    container.setPadding(dp(8), dp(8), dp(8), dp(8));

    GradientDrawable dialogBg = new GradientDrawable();
    dialogBg.setColor(COLOR_BG_INPUT);
    dialogBg.setCornerRadius(dp(16));
    container.setBackground(dialogBg);

    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(Color.TRANSPARENT);
    scroll.addView(container);

    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    for (int i = 0; i < list.size(); i++) {
      final String title = list.get(i)[0];
      final String url = list.get(i)[1];

      LinearLayout row = new LinearLayout(this);
      row.setOrientation(LinearLayout.HORIZONTAL);
      row.setGravity(Gravity.CENTER_VERTICAL);
      row.setPadding(dp(10), dp(10), dp(10), dp(10));
      LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
      rowLp.bottomMargin = dp(3);
      row.setLayoutParams(rowLp);

      GradientDrawable rowBg = new GradientDrawable();
      rowBg.setCornerRadius(dp(12));
      rowBg.setColor(COLOR_BG_BTN);
      row.setBackground(rowBg);

      ImageView fav = new ImageView(this);
      LinearLayout.LayoutParams favLp = new LinearLayout.LayoutParams(dp(26), dp(26));
      fav.setLayoutParams(favLp);
      fav.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
      loadFaviconAsync(fav, url);
      row.addView(fav);
      row.addView(spacer(12));

      LinearLayout textBox = new LinearLayout(this);
      textBox.setOrientation(LinearLayout.VERTICAL);
      textBox.setGravity(appStartGravity());
      LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
          0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
      textBox.setLayoutParams(textLp);

      TextView titleView = new TextView(this);
      String t = title == null || title.isEmpty() ? prettyUrl(url) : title;
      if (t.length() > 40) t = t.substring(0, 40) + "…";
      titleView.setText(t);
      titleView.setTextColor(COLOR_TEXT);
      titleView.setTextSize(13);
      titleView.setSingleLine();
      titleView.setEllipsize(TextUtils.TruncateAt.END);
      titleView.setGravity(appStartGravity());
      textBox.addView(titleView);

      TextView urlView = new TextView(this);
      String u = prettyUrl(url);
      if (u.length() > 45) u = u.substring(0, 45) + "…";
      urlView.setText(u);
      urlView.setTextColor(COLOR_TEXT_SUB);
      urlView.setTextSize(11);
      urlView.setSingleLine();
      urlView.setEllipsize(TextUtils.TruncateAt.END);
      urlView.setGravity(appStartGravity());
      textBox.addView(urlView);

      row.addView(textBox);
      row.addView(spacer(8));

      TextView del = new TextView(this);
      del.setText("🗑");
      del.setTextSize(16);
      del.setGravity(Gravity.CENTER);
      LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(dp(32), dp(32));
      del.setLayoutParams(delLp);
      del.setOnClickListener(v -> {
        haptic();
        dialog.dismiss();
        bookmarksRemove(url);
        toast(getString(R.string.br_bookmark_removed));
      });
      row.addView(del);

      row.setOnClickListener(v -> { haptic(); dialog.dismiss(); loadUrl(url); });
      container.addView(row);
    }

    dialog.setContentView(scroll);
    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88),
          WindowManager.LayoutParams.WRAP_CONTENT);
    }
    dialog.show();
  }

  public void showHistory() {
    List<String[]> list = historyGetAll();
    if (list.isEmpty()) { toast(getString(R.string.br_no_history)); return; }

    LinearLayout container = new LinearLayout(this);
    container.setOrientation(LinearLayout.VERTICAL);
    container.setPadding(dp(8), dp(8), dp(8), dp(8));

    GradientDrawable dialogBg = new GradientDrawable();
    dialogBg.setColor(COLOR_BG_INPUT);
    dialogBg.setCornerRadius(dp(16));
    container.setBackground(dialogBg);

    ScrollView scroll = new ScrollView(this);
    scroll.setBackgroundColor(Color.TRANSPARENT);
    scroll.addView(container);

    final Dialog dialog = new Dialog(this);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    for (int i = 0; i < list.size(); i++) {
      final String title = list.get(i)[0];
      final String url = list.get(i)[1];

      LinearLayout row = new LinearLayout(this);
      row.setOrientation(LinearLayout.HORIZONTAL);
      row.setGravity(Gravity.CENTER_VERTICAL);
      row.setPadding(dp(10), dp(10), dp(10), dp(10));
      LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
      rowLp.bottomMargin = dp(3);
      row.setLayoutParams(rowLp);

      GradientDrawable rowBg = new GradientDrawable();
      rowBg.setCornerRadius(dp(12));
      rowBg.setColor(COLOR_BG_BTN);
      row.setBackground(rowBg);

      ImageView fav = new ImageView(this);
      LinearLayout.LayoutParams favLp = new LinearLayout.LayoutParams(dp(26), dp(26));
      fav.setLayoutParams(favLp);
      fav.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
      loadFaviconAsync(fav, url);
      row.addView(fav);
      row.addView(spacer(12));

      LinearLayout textBox = new LinearLayout(this);
      textBox.setOrientation(LinearLayout.VERTICAL);
      textBox.setGravity(appStartGravity());
      LinearLayout.LayoutParams textLp = new LinearLayout.LayoutParams(
          0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
      textBox.setLayoutParams(textLp);

      TextView titleView = new TextView(this);
      String t = title == null || title.isEmpty() ? prettyUrl(url) : title;
      if (t.length() > 40) t = t.substring(0, 40) + "…";
      titleView.setText(t);
      titleView.setTextColor(COLOR_TEXT);
      titleView.setTextSize(13);
      titleView.setSingleLine();
      titleView.setEllipsize(TextUtils.TruncateAt.END);
      titleView.setGravity(appStartGravity());
      textBox.addView(titleView);

      TextView urlView = new TextView(this);
      String u = prettyUrl(url);
      if (u.length() > 45) u = u.substring(0, 45) + "…";
      urlView.setText(u);
      urlView.setTextColor(COLOR_TEXT_SUB);
      urlView.setTextSize(11);
      urlView.setSingleLine();
      urlView.setEllipsize(TextUtils.TruncateAt.END);
      urlView.setGravity(appStartGravity());
      textBox.addView(urlView);

      row.addView(textBox);
      row.setOnClickListener(v -> { haptic(); dialog.dismiss(); loadUrl(url); });
      container.addView(row);
    }

    dialog.setContentView(scroll);
    Window w = dialog.getWindow();
    if (w != null) {
      w.setBackgroundDrawableResource(android.R.color.transparent);
      w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88),
          WindowManager.LayoutParams.WRAP_CONTENT);
    }
    dialog.show();
  }

  public void translatePage() {
    if (mWebView == null) return;
    String url = mWebView.getUrl();
    if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
      toast(getString(R.string.translate_unavailable));
      return;
    }

    String[] labels = {
        getString(R.string.lang_fa), getString(R.string.lang_en),
        getString(R.string.lang_ko), getString(R.string.lang_zh),
        getString(R.string.lang_ja), getString(R.string.lang_ar)
    };
    String[] codes = {"fa", "en", "ko", "zh-CN", "ja", "ar"};

    new AlertDialog.Builder(this)
        .setTitle(getString(R.string.translate_title))
        .setItems(labels, (dialog, which) -> {
          if (which < 0 || which >= codes.length) return;
          final String lang = codes[which];
          final String langLabel = labels[which];
          toast(getString(R.string.translate_started));
          Translate.translate(mWebView, this, lang, ok -> {
            if (!ok) toast(getString(R.string.translate_failed));
            else toast(getString(R.string.translate_done, langLabel));
          });
        })
        .setNegativeButton(getString(R.string.br_cancel), null)
        .setNeutralButton(getString(R.string.translate_restore), (d, w) ->
            Translate.restore(mWebView, this, ok -> {
              if (!ok) toast(getString(R.string.translate_failed));
            }))
        .show();
  }

  public void toggleDesktop() {
    desktopMode = !desktopMode;
    if (mWebView == null) return;
    WebSettings s = mWebView.getSettings();
    if (desktopMode) {
      s.setUseWideViewPort(true);
      s.setLoadWithOverviewMode(true);
      toast(getString(R.string.br_desktop_on));
    } else {
      toast(getString(R.string.br_mobile_on));
    }
    applyUserAgent();
    saveUiState();
    mWebView.reload();
  }

  public void clearCache() {
    try {
      if (mWebView != null) {
        mWebView.clearCache(true);
        mWebView.clearFormData();
      }
      toast(getString(R.string.toast_cache_cleared));
    } catch (Exception e) {
      toast(getString(R.string.toast_failed, e.getMessage()));
    }
  }

  public void clearCookies() {
    try {
      CookieManager cm = CookieManager.getInstance();
      cm.removeAllCookies(removed -> {
        cm.flush();
        toast(getString(R.string.toast_cookies_cleared));
      });
    } catch (Exception e) {
      toast(getString(R.string.toast_failed, e.getMessage()));
    }
  }

  public void clearCurrentSiteCookies() {
    if (mWebView == null) return;
    String url = mWebView.getUrl();
    Uri uri = url == null ? null : Uri.parse(url);
    String host = uri == null ? null : uri.getHost();
    String scheme = uri == null ? null : uri.getScheme();
    if (url == null || isInternalUrl(url) || host == null || host.isEmpty() || scheme == null
        || !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) {
      toast(getString(R.string.err_cant_clear_internal));
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle(R.string.clear_site_cookies_title)
        .setMessage(getString(R.string.clear_site_cookies_msg, host))
        .setPositiveButton(R.string.br_clear, (d, w) -> {
          CookieManager cm = CookieManager.getInstance();
          String cookies = cm.getCookie(url);
          if (cookies != null) {
            for (String item : cookies.split(";")) {
              int eq = item.indexOf('=');
              if (eq <= 0) continue;
              String name = item.substring(0, eq).trim();
              if (name.isEmpty()) continue;
              String expired = name + "=; Max-Age=0; path=/";
              try { cm.setCookie(url, expired); } catch (Exception ignored) {}
              try { cm.setCookie(scheme + "://" + host, expired); } catch (Exception ignored) {}
              try { cm.setCookie(scheme + "://." + host, expired); } catch (Exception ignored) {}
              try { cm.setCookie(scheme + "://" + host, expired + "; domain=" + host); } catch (Exception ignored) {}
            }
          }
          cm.flush();
          toast(getString(R.string.toast_site_cookies_cleared));
          if (mWebView != null) mWebView.reload();
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void clearCurrentSiteData() {
    if (mWebView == null) return;
    String url = mWebView.getUrl();
    Uri uri = url == null ? null : Uri.parse(url);
    String host = uri == null ? null : uri.getHost();
    String scheme = uri == null ? null : uri.getScheme();
    if (url == null || isInternalUrl(url) || host == null || host.isEmpty() || scheme == null
        || !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) {
      toast(getString(R.string.err_cant_clear_internal));
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle(R.string.clear_site_data_title)
        .setMessage(getString(R.string.clear_site_data_msg, host))
        .setPositiveButton(R.string.br_clear, (d, w) -> {
          CookieManager cm = CookieManager.getInstance();
          String cookies = cm.getCookie(url);
          if (cookies != null) {
            for (String item : cookies.split(";")) {
              int eq = item.indexOf('=');
              if (eq <= 0) continue;
              String name = item.substring(0, eq).trim();
              if (name.isEmpty()) continue;
              String expired = name + "=; Max-Age=0; path=/";
              try { cm.setCookie(url, expired); } catch (Exception ignored) {}
              try { cm.setCookie(scheme + "://" + host, expired); } catch (Exception ignored) {}
              try { cm.setCookie(scheme + "://" + host, expired + "; domain=" + host); } catch (Exception ignored) {}
            }
          }
          cm.flush();
          mWebView.evaluateJavascript("(function(){try{localStorage.clear()}catch(e){}try{sessionStorage.clear()}catch(e){}try{if(indexedDB&&indexedDB.databases)indexedDB.databases().then(function(a){a.forEach(function(d){indexedDB.deleteDatabase(d.name)})})}catch(e){}})()", value -> {
            toast(getString(R.string.toast_site_data_cleared));
            if (mWebView != null) mWebView.reload();
          });
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void clearHistoryConfirm() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.br_clear_history)
        .setMessage(R.string.br_clear_confirm)
        .setPositiveButton(R.string.br_clear, (d, w) -> {
          historyClear();
          if (mWebView != null) mWebView.clearHistory();
          toast(getString(R.string.br_history_cleared));
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void clearBookmarksConfirm() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.settings_clear_bookmarks)
        .setMessage(R.string.settings_clear_bookmarks_msg)
        .setPositiveButton(R.string.clear, (d, w) -> {
          getSharedPreferences(PREF_BOOKMARKS, MODE_PRIVATE).edit().clear().apply();
          toast(getString(R.string.toast_bookmarks_cleared));
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void clearAllBrowserData() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.settings_clear_all_browser_data)
        .setMessage(R.string.settings_clear_all_browser_data_msg)
        .setPositiveButton(R.string.br_clear, (d, w) -> {
          
          historyClear();
          getSharedPreferences(PREF_BOOKMARKS, MODE_PRIVATE).edit().clear().apply();
          getSharedPreferences(PREF_TABS, MODE_PRIVATE).edit().clear().apply();
          getSharedPreferences(PREF_SHORTCUTS, MODE_PRIVATE).edit().clear().apply();
          
          for (Tab t : tabs) {
              if (t.webView != null) {
                  if (t.webView.getParent() != null) {
                      ((ViewGroup)t.webView.getParent()).removeView(t.webView);
                  }
                  t.webView.destroy();
              }
          }
          tabs.clear();
          activeTabIndex = 0;
          
          adblockPageHidden = 0;
          adblockPageBlocked = 0;
          adblockTotalHidden = 0;
          adblockTotalBlocked = 0;
          adblockSessionBlocked = 0;
          synchronized (adblockPageTotals) { adblockPageTotals.clear(); }
          saveAdblockPrefs();

          if (mWebView != null) {
            mWebView.clearCache(true);
            mWebView.clearHistory();
            mWebView.clearFormData();
            mWebView.clearSslPreferences();
            mWebView.evaluateJavascript("try{localStorage.clear();sessionStorage.clear();}catch(e){}", null);
          }
          
          WebStorage.getInstance().deleteAllData();
          
          getSharedPreferences(PREF_UI, MODE_PRIVATE).edit().clear().putString("homePage", "calculator").apply();
          getSharedPreferences(PREF_SEARCH, MODE_PRIVATE).edit().clear().apply();
          getSharedPreferences(PREF_UA, MODE_PRIVATE).edit().clear().apply();
          desktopMode = false;
          currentZoom = 100f;
          customUserAgent = "";
          adblockEnabled = true;
          adblockAiEnabled = true;
          saveUiState();
          saveAdblockPrefs();
          settingsHtmlCache = null;

          CookieManager cm = CookieManager.getInstance();
          cm.removeAllCookies(removed -> {
            cm.flush();
            toast(getString(R.string.toast_browser_data_cleared));
            
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
              Intent intent = new Intent(MainActivity.this, MainActivity.class);
              intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | 
                              Intent.FLAG_ACTIVITY_NEW_TASK | 
                              Intent.FLAG_ACTIVITY_CLEAR_TASK);
              startActivity(intent);
              finish();
              android.os.Process.killProcess(android.os.Process.myPid());
            }, 500);
          });
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void resetBrowserSettings() {
    new AlertDialog.Builder(this)
        .setTitle(R.string.settings_reset_browser_settings)
        .setMessage(R.string.settings_reset_browser_settings_msg)
        .setPositiveButton(R.string.settings_reset_button, (d, w) -> {
          getSharedPreferences(PREF_UI, MODE_PRIVATE).edit().clear().putString("homePage", "calculator").apply();
          getSharedPreferences(PREF_SEARCH, MODE_PRIVATE).edit().clear().apply();
          getSharedPreferences(PREF_UA, MODE_PRIVATE).edit().clear().apply();
          desktopMode = false;
          currentZoom = 100f;
          customUserAgent = "";
          adblockEnabled = true;
          adblockAiEnabled = true;
          saveUiState();
          saveAdblockPrefs();
          settingsHtmlCache = null;
          if (mWebView != null) {
            WebSettings settings = mWebView.getSettings();
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            applyUserAgent();
            settings.setTextZoom(100);
            mWebView.reload();
          }
          toast(getString(R.string.toast_settings_reset));
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void showCustomUaDialog() {
    EditText input = new EditText(this);
    input.setText(customUserAgent);
    input.setHint("Mozilla/5.0 ...");
    input.setSingleLine(true);
    input.setSelectAllOnFocus(true);
    input.setTextColor(COLOR_TEXT);
    input.setHintTextColor(COLOR_TEXT_SUB);
    new AlertDialog.Builder(this)
        .setTitle(R.string.menu_custom_ua)
        .setView(input)
        .setPositiveButton(R.string.zoom_ok, (d, w) -> {
          customUserAgent = input.getText().toString().trim();
          getSharedPreferences(PREF_UA, MODE_PRIVATE).edit().putString("ua", customUserAgent).apply();
          applyUserAgent();
          if (mWebView != null) mWebView.reload();
          settingsHtmlCache = null;
        })
        .setNeutralButton(R.string.br_clear, (d, w) -> {
          customUserAgent = "";
          getSharedPreferences(PREF_UA, MODE_PRIVATE).edit().remove("ua").apply();
          applyUserAgent();
          if (mWebView != null) mWebView.reload();
          settingsHtmlCache = null;
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void applyUserAgent() {
    if (mWebView == null) return;
    String ua = customUserAgent == null || customUserAgent.trim().isEmpty()
        ? (desktopMode ? UA_DESKTOP : UA_MOBILE) : customUserAgent.trim();
    mWebView.getSettings().setUserAgentString(ua);
  }

  public void handleExternalIntent(Intent intent) {
    if (intent == null || mWebView == null) return;
    String action = intent.getAction();
    if (Intent.ACTION_VIEW.equals(action)) {
      Uri uri = intent.getData();
      if (uri == null) return;
      String scheme = uri.getScheme();
      if (scheme == null) return;
      if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
        loadUrl(uri.toString());
        return;
      }
      if ("content".equalsIgnoreCase(scheme) || "file".equalsIgnoreCase(scheme)) {
        String mime = intent.getType();
        if (mime == null || mime.isEmpty() || "application/octet-stream".equalsIgnoreCase(mime) || "*/*".equals(mime)) {
          String guessed = guessMimeFromUri(uri);
          if (guessed != null && !guessed.isEmpty() && !"text/plain".equals(guessed)) mime = guessed;
          else if (mime == null || mime.isEmpty() || "*/*".equals(mime)) {
            try { mime = getContentResolver().getType(uri); } catch (Exception ignored) {}
          }
        }
        if (mime == null || mime.isEmpty()) mime = guessMimeFromUri(uri);
        loadLocalContent(uri, mime);
      }
    } else if (Intent.ACTION_SEND.equals(action)) {
      Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
      String text = intent.getStringExtra(Intent.EXTRA_TEXT);
      if (stream != null) {
        String mime = intent.getType();
        if (mime == null || mime.isEmpty() || "application/octet-stream".equalsIgnoreCase(mime) || "*/*".equals(mime)) mime = guessMimeFromUri(stream);
        loadLocalContent(stream, mime);
      } else if (text != null && !text.trim().isEmpty()) {
        String value = text.trim();
        if (value.startsWith("http://") || value.startsWith("https://") || value.startsWith("this://")) loadUrl(value);
        else navigateTo(value);
      }
    }
  }

  public String getDisplayName(Uri uri) {
    if (uri != null && "content".equalsIgnoreCase(uri.getScheme())) {
      try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
        if (cursor != null && cursor.moveToFirst()) {
          int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
          if (index >= 0) return cursor.getString(index);
        }
      } catch (Exception ignored) {}
    }
    String name = uri == null ? null : uri.getLastPathSegment();
    return name == null || name.trim().isEmpty() ? "document" : name;
  }

  public String guessMimeFromUri(Uri uri) {
    String name = getDisplayName(uri);
    int dot = name.lastIndexOf('.');
    if (dot > 0 && dot < name.length() - 1) {
      String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
      if ("svg".equals(ext)) return "image/svg+xml";
      String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
      if (mime != null && !mime.isEmpty()) return mime;
    }
    return "text/plain";
  }

  public boolean isTextMime(String mime) {
    if (mime == null) return false;
    String value = mime.toLowerCase(Locale.ROOT);
    return value.startsWith("text/") || value.equals("application/json")
        || value.equals("application/xml") || value.equals("application/xhtml+xml")
        || value.equals("application/javascript") || value.equals("application/x-javascript")
        || value.equals("application/rss+xml") || value.equals("application/atom+xml")
        || value.equals("image/svg+xml");
  }

  public void loadLocalContent(Uri uri, String mime) {
    if (uri == null || mWebView == null) return;
    if (mime == null || mime.isEmpty() || "application/octet-stream".equalsIgnoreCase(mime)) mime = guessMimeFromUri(uri);
    if (isTextMime(mime)) {
      try (InputStream input = getContentResolver().openInputStream(uri); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
        if (input == null) throw new IOException("empty input");
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) > 0) output.write(buffer, 0, count);
        String content = output.toString("UTF-8");
        String base = uri.toString();
        String finalMime = mime;
        String name = getDisplayName(uri);
        mWebView.loadDataWithBaseURL(base, content, finalMime, "UTF-8", null);
        if (activeTabIndex >= 0 && activeTabIndex < tabs.size()) {
          tabs.get(activeTabIndex).url = base;
          tabs.get(activeTabIndex).title = name;
          saveTabs();
          renderTabs();
        }
      } catch (Exception e) {
        toast(getString(R.string.toast_file_open_failed));
      }
      return;
    }
    new Thread(() -> {
      try {
        File dir = new File(getCacheDir(), "shared");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("cache directory unavailable");
        String name = getDisplayName(uri).replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (name.isEmpty()) name = "document";
        File output = new File(dir, name);
        try (InputStream input = getContentResolver().openInputStream(uri); FileOutputStream stream = new FileOutputStream(output)) {
          if (input == null) throw new IOException("empty input");
          byte[] buffer = new byte[16384];
          int count;
          while ((count = input.read(buffer)) > 0) stream.write(buffer, 0, count);
        }
        String localUrl = Uri.fromFile(output).toString();

        final String finalName = name;

        runOnUiThread(() -> {
          if (mWebView == null) return;
          mWebView.loadUrl(localUrl);
          if (urlBar != null) urlBar.setText(localUrl);
          if (activeTabIndex >= 0 && activeTabIndex < tabs.size()) {
            tabs.get(activeTabIndex).url = localUrl;
            tabs.get(activeTabIndex).title = finalName;
            saveTabs();
            renderTabs();
          }
        });
      } catch (Exception e) {
        runOnUiThread(() -> toast(getString(R.string.toast_file_open_failed)));
      }
    }).start();
  }

  public String getLanguageName(String code) {
    if ("fa".equals(code)) return getString(R.string.lang_fa);
    if ("en".equals(code)) return getString(R.string.lang_en);
    if ("ar".equals(code)) return getString(R.string.lang_ar);
    if ("ko".equals(code)) return getString(R.string.lang_ko);
    if ("zh".equals(code)) return getString(R.string.lang_zh);
    if ("ja".equals(code)) return getString(R.string.lang_ja);
    return getString(R.string.settings_language_system);
  }

  public void showLanguageDialog() {
    String[] codes = {"system", "en", "fa", "ar", "ko", "zh", "ja"};
    String[] names = {
        getString(R.string.settings_language_system),
        getString(R.string.lang_en), getString(R.string.lang_fa),
        getString(R.string.lang_ar), getString(R.string.lang_ko),
        getString(R.string.lang_zh), getString(R.string.lang_ja)
    };
    String current = AppLanguage.get(this);
    int selected = 0;
    for (int i = 0; i < codes.length; i++) if (codes[i].equals(current)) selected = i;
    new AlertDialog.Builder(this)
        .setTitle(R.string.settings_language)
        .setSingleChoiceItems(names, selected, (dialog, which) -> {
          AppLanguage.set(this, codes[which]);
          dialog.dismiss();
          recreate();
        })
        .setNegativeButton(R.string.br_cancel, null)
        .show();
  }

  public void showSettings() {
    new com.calculator.app.core.Settings(this).show();
  }

  public void addSettingRow(LinearLayout parent, Dialog dialog, String icon,
                             String label, String value, Runnable onClick) {
    int startGrav = appStartGravity();

    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.setGravity(Gravity.CENTER_VERTICAL);
    row.setPadding(dp(14), dp(12), dp(14), dp(12));

    if (icon != null && !icon.isEmpty()) {
      TextView iconView = new TextView(this);
      iconView.setText(icon);
      iconView.setTextSize(18);
      iconView.setGravity(Gravity.CENTER);
      LinearLayout.LayoutParams iLp = new LinearLayout.LayoutParams(dp(28),
          LinearLayout.LayoutParams.WRAP_CONTENT);
      iconView.setLayoutParams(iLp);
      row.addView(iconView);

      row.addView(spacer(14));
    }

    LinearLayout texts = new LinearLayout(this);
    texts.setOrientation(LinearLayout.VERTICAL);
    texts.setGravity(startGrav);
    LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(0,
        LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
    texts.setLayoutParams(tLp);

    TextView labelView = new TextView(this);
    labelView.setText(label);
    labelView.setTextColor(COLOR_TEXT);
    labelView.setTextSize(14);
    labelView.setGravity(startGrav);
    texts.addView(labelView);

    if (value != null && !value.isEmpty()) {
      TextView valueView = new TextView(this);
      valueView.setText(value);
      valueView.setTextColor(COLOR_TEXT_SUB);
      valueView.setTextSize(11);
      valueView.setPadding(0, dp(2), 0, 0);
      valueView.setGravity(startGrav);
      texts.addView(valueView);
    }

    row.addView(texts);

    if (onClick != null) {
      row.addView(spacer(10));

      TextView arrow = new TextView(this);
      arrow.setText("‹");
      arrow.setTextColor(COLOR_TEXT_SUB);
      arrow.setTextSize(20);
      arrow.setGravity(Gravity.CENTER);
      LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dp(24),
          LinearLayout.LayoutParams.WRAP_CONTENT);
      arrow.setLayoutParams(aLp);
      row.addView(arrow);

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        GradientDrawable rbg = new GradientDrawable();
        rbg.setCornerRadius(dp(10));
        rbg.setColor(0x00000000);
        RippleDrawable ripple = new RippleDrawable(
            ColorStateList.valueOf(0x33FFFFFF), rbg, null);
        row.setBackground(ripple);
      }

      row.setOnClickListener(v -> {
        haptic();
        dialog.dismiss();
        onClick.run();
      });
    }

    parent.addView(row);
  }

  public void showSearchEngineDialog() {
    final String[] names = new String[SEARCH_ENGINES.length];
    for (int i = 0; i < SEARCH_ENGINES.length; i++) names[i] = SEARCH_ENGINES[i][0];

    int checked = 0;
    String current = getSearchEngineName();
    for (int i = 0; i < names.length; i++) {
      if (names[i].equals(current)) { checked = i; break; }
    }

    new AlertDialog.Builder(this)
        .setTitle(getString(R.string.settings_engine))
        .setSingleChoiceItems(names, checked, (d, which) -> {
          setSearchEngine(names[which]);
          toast(getString(R.string.toast_search_engine, names[which]));
          d.dismiss();
        })
        .setNegativeButton(getString(R.string.br_cancel), null)
        .show();
  }

  public String getSearchEngineUrl() {
    String name = getSharedPreferences(PREF_SEARCH, MODE_PRIVATE)
        .getString("name", "Google");
    for (String[] e : SEARCH_ENGINES) {
      if (e[0].equals(name)) return e[1];
    }
    return SEARCH_ENGINES[0][1];
  }

  public String getSearchEngineName() {
    return getSharedPreferences(PREF_SEARCH, MODE_PRIVATE)
        .getString("name", "Google");
  }

  public void setSearchEngine(String name) {
    getSharedPreferences(PREF_SEARCH, MODE_PRIVATE)
        .edit().putString("name", name).apply();
  }

  public String getHomePageName() {
    String home = getSharedPreferences(PREF_UI, MODE_PRIVATE)
        .getString("homePage", "calculator");
    if ("newtab".equals(home)) return getString(R.string.settings_home_newtab);
    return getString(R.string.settings_home_calc);
  }

  public void showHomePageDialog() {
    final String[] options = {
        getString(R.string.settings_home_calc),
        getString(R.string.settings_home_newtab)
    };
    final String[] values = {"calculator", "newtab"};

    String current = getSharedPreferences(PREF_UI, MODE_PRIVATE)
        .getString("homePage", "calculator");
    int checked = "newtab".equals(current) ? 1 : 0;

    new AlertDialog.Builder(this)
        .setTitle(getString(R.string.settings_home))
        .setSingleChoiceItems(options, checked, (d, which) -> {
          getSharedPreferences(PREF_UI, MODE_PRIVATE)
              .edit().putString("homePage", values[which]).apply();
          toast(getString(R.string.toast_home_page, options[which]));
          d.dismiss();
        })
        .setNegativeButton(getString(R.string.br_cancel), null)
        .show();
  }

  public void saveCurrentPageAsMht() {
    if (mWebView == null) return;
    String pageUrl = mWebView.getUrl();
    if (pageUrl == null || pageUrl.trim().isEmpty() || isInternalUrl(pageUrl)) {
      toast(getString(R.string.toast_not_downloadable));
      return;
    }
    String pageName = DownloadNameResolver.resolve(pageUrl, null, "text/html");
    int dot = pageName.lastIndexOf('.');
    if (dot > 0) pageName = pageName.substring(0, dot);
    pageName = pageName.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
    if (pageName.isEmpty()) pageName = "page";
    final String outputName = pageName + ".mht";
    File tempDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
    if (tempDir == null) {
      toast(getString(R.string.toast_download_failed));
      return;
    }
    if (!tempDir.exists() && !tempDir.mkdirs()) {
      toast(getString(R.string.toast_download_failed));
      return;
    }
    File tempFile = new File(tempDir, "page_" + System.currentTimeMillis() + ".mht");
    final String originalUrl = pageUrl;
    mWebView.saveWebArchive(tempFile.getAbsolutePath(), false, savedPath -> {
      if (savedPath == null || savedPath.isEmpty() || !tempFile.exists() || tempFile.length() == 0) {
        if (tempFile.exists()) tempFile.delete();
        toast(getString(R.string.toast_download_failed));
        return;
      }
      Uri pendingUri = null;
      try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          ContentValues values = new ContentValues();
          values.put(MediaStore.MediaColumns.DISPLAY_NAME, outputName);
          values.put(MediaStore.MediaColumns.MIME_TYPE, "application/x-mimearchive");
          values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
          Uri dest = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
          if (dest == null) throw new IOException("Could not create download file");
          pendingUri = dest;
          try (InputStream in = new FileInputStream(tempFile);
               OutputStream out = getContentResolver().openOutputStream(dest)) {
            if (out == null) throw new IOException("Could not open download file");
            byte[] buffer = new byte[16384];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
          }
          pendingUri = null;
        } else {
          File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
          if (!downloads.exists() && !downloads.mkdirs()) throw new IOException("Could not create Downloads folder");
          File dest = new File(downloads, outputName);
          try (InputStream in = new FileInputStream(tempFile); OutputStream out = new FileOutputStream(dest)) {
            byte[] buffer = new byte[16384];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
          }
          android.media.MediaScannerConnection.scanFile(this, new String[]{dest.getAbsolutePath()},
              new String[]{"application/x-mimearchive"}, null);
        }
        toast(getString(R.string.toast_saved, "Downloads/" + outputName));
      } catch (Exception e) {
        if (pendingUri != null) try { getContentResolver().delete(pendingUri, null, null); } catch (Exception ignored) {}
        toast(getString(R.string.toast_download_failed));
        android.util.Log.e("BrowserSaveMht", "Could not save MHT for " + originalUrl, e);
      } finally {
        if (tempFile.exists()) tempFile.delete();
      }
    });
  }

  public void downloadCurrent() {
    if (mWebView == null) return;
    String url = mWebView.getUrl();
    if (url == null || url.isEmpty()) { toast(getString(R.string.toast_nothing)); return; }
    if (isInternalUrl(url)) {
      if (url.startsWith(ASSET_PATH)) {
        String assetPath = url.substring(ASSET_PATH.length());
        String filename = assetPath.substring(assetPath.lastIndexOf('/') + 1);
        if (filename.isEmpty()) filename = "index.html";
        copyAssetToDownloads(assetPath, filename);
      } else {
        toast(getString(R.string.toast_not_downloadable));
      }
      return;
    }
    if (url.startsWith("http://") || url.startsWith("https://")) {
      try {
        String name = DownloadNameResolver.resolve(url, null, null);
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
        req.setTitle(name);
        req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
        String cookie = CookieManager.getInstance().getCookie(url);
        if (cookie != null) req.addRequestHeader("Cookie", cookie);
        req.addRequestHeader("User-Agent", mWebView.getSettings().getUserAgentString());
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (dm != null) {
          dm.enqueue(req);
          toast(getString(R.string.toast_started, name));
        }
      } catch (Exception e) { toast(getString(R.string.toast_failed, e.getMessage())); }
      return;
    }
    toast(getString(R.string.toast_not_downloadable));
  }

  public void copyAssetToDownloads(String assetPath, String filename) {
    Uri pendingUri = null;
    try (InputStream is = getAssets().open(assetPath)) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
        values.put(MediaStore.MediaColumns.MIME_TYPE, guessMime(filename));
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) { toast(getString(R.string.toast_failed, "MediaStore error")); return; }
        pendingUri = uri;
        try (OutputStream os = getContentResolver().openOutputStream(uri)) {
          if (os == null) throw new IOException("Output error");
          byte[] buf = new byte[8192];
          int n;
          while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        }
        pendingUri = null;
        toast(getString(R.string.toast_saved, "Downloads/" + filename));
      } else {
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.exists() && !dir.mkdirs()) {
          toast(getString(R.string.toast_failed, "Cannot create directory"));
          return;
        }
        File out = new File(dir, filename);
        try (FileOutputStream fos = new FileOutputStream(out)) {
          byte[] buf = new byte[8192];
          int n;
          while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
        }
        android.media.MediaScannerConnection.scanFile(this,
            new String[]{out.getAbsolutePath()}, null, null);
        toast(getString(R.string.toast_saved, "Downloads/" + filename));
      }
    } catch (Exception e) {
      if (pendingUri != null) {
        try { getContentResolver().delete(pendingUri, null, null); } catch (Exception ignored) {}
      }
      toast(getString(R.string.toast_failed, e.getMessage()));
    }
  }

  public String guessMime(String filename) {
    String f = filename.toLowerCase();
    if (f.endsWith(".html") || f.endsWith(".htm")) return "text/html";
    if (f.endsWith(".js")) return "application/javascript";
    if (f.endsWith(".css")) return "text/css";
    if (f.endsWith(".json")) return "application/json";
    if (f.endsWith(".txt")) return "text/plain";
    if (f.endsWith(".xml")) return "text/xml";
    if (f.endsWith(".png")) return "image/png";
    if (f.endsWith(".jpg") || f.endsWith(".jpeg")) return "image/jpeg";
    if (f.endsWith(".gif")) return "image/gif";
    if (f.endsWith(".webp")) return "image/webp";
    if (f.endsWith(".svg")) return "image/svg+xml";
    if (f.endsWith(".pdf")) return "application/pdf";
    if (f.endsWith(".zip")) return "application/zip";
    if (f.endsWith(".mp3")) return "audio/mpeg";
    if (f.endsWith(".mp4")) return "video/mp4";
    if (f.endsWith(".woff")) return "font/woff";
    if (f.endsWith(".woff2")) return "font/woff2";
    if (f.endsWith(".ttf")) return "font/ttf";
    if (f.endsWith(".ico")) return "image/x-icon";
    return "application/octet-stream";
  }

  @SuppressLint("SetJavaScriptEnabled")
  public void configureWebView(final WebView wv) {
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    WebViewDefaults.applySecurityDefaults(s);
    s.setCacheMode(WebSettings.LOAD_DEFAULT);
    s.setGeolocationEnabled(true);
    s.setSaveFormData(true);
    s.setUseWideViewPort(true);
    s.setLoadWithOverviewMode(true);
    s.setSupportZoom(true);
    s.setBuiltInZoomControls(true);
    s.setDisplayZoomControls(false);
    s.setTextZoom((int) currentZoom);
    s.setMediaPlaybackRequiresUserGesture(false);
    s.setSupportMultipleWindows(true);
    s.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
    s.setLoadsImagesAutomatically(true);
    s.setUserAgentString(customUserAgent == null || customUserAgent.trim().isEmpty()
        ? (desktopMode ? UA_DESKTOP : UA_MOBILE) : customUserAgent.trim());
    s.setDefaultTextEncodingName("UTF-8");
    s.setMinimumFontSize(1);
    s.setMinimumLogicalFontSize(1);
    s.setDefaultFontSize(16);
    s.setDefaultFixedFontSize(13);
    s.setStandardFontFamily("sans-serif");
    s.setFixedFontFamily("monospace");
    s.setSansSerifFontFamily("sans-serif");
    s.setSerifFontFamily("serif");
    s.setCursiveFontFamily("cursive");
    s.setFantasyFontFamily("fantasy");
    s.setBlockNetworkImage(false);
    s.setBlockNetworkLoads(false);
    s.setNeedInitialFocus(true);

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      s.setOffscreenPreRaster(true);
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      s.setAlgorithmicDarkeningAllowed(false);
    }

    CookieManager cm = CookieManager.getInstance();
    cm.setAcceptCookie(true);
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
      cm.setAcceptThirdPartyCookies(wv, true);
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      android.webkit.ServiceWorkerController.getInstance().setServiceWorkerClient(new android.webkit.ServiceWorkerClient() {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
          if (!adblockEnabled || request == null) return null;
          Uri uri = request.getUrl();
          if (uri == null) return null;
          String scheme = uri.getScheme();
          if (scheme == null || (!scheme.equals("http") && !scheme.equals("https"))) return null;
          
          String urlStr = uri.toString();
          String decodedUrl = AdBlock.decodeProxyUrl(urlStr);
          Uri dUri;
          try { dUri = Uri.parse(decodedUrl); } catch (Exception e) { return null; }
          String dHost = dUri.getHost();
          String pageHost = null;
          try { pageHost = Uri.parse(currentPageUrl).getHost(); } catch (Exception ignored) {}

          if (AdBlock.isBlockedHost(dHost, pageHost)) {
            adblockPageBlocked++;
            adblockTotalBlocked++;
            recordAdblockEvents(currentPageUrl, 1);
            return blockedResponse("text/plain");
          }
          return null;
        }
      });
    }

    wv.setBackgroundColor(Color.WHITE);
    wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
    wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    wv.setVerticalScrollBarEnabled(false);
    wv.setHorizontalScrollBarEnabled(false);
    wv.setFocusable(true);
    wv.setFocusableInTouchMode(true);

    wv.addJavascriptInterface(new WebBridgeApi(this), "Bridge");
    wv.addJavascriptInterface(new Object() {
      @JavascriptInterface
      public boolean isBlocked(String host) {
        String pageHost = null;
        try { pageHost = Uri.parse(currentPageUrl).getHost(); } catch (Exception ignored) {}
        return AdBlock.isBlockedHost(host, pageHost);
      }
    }, "AndroidAdBlock");

    wv.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
      try {
        if (url == null || url.trim().isEmpty()) return;
        Uri parsed = Uri.parse(url);
        String fileName = DownloadNameResolver.resolve(url, contentDisposition, mimeType);
        DownloadManager.Request request = new DownloadManager.Request(parsed);
        String cookies = CookieManager.getInstance().getCookie(url);
        if (cookies != null && !cookies.isEmpty()) request.addRequestHeader("Cookie", cookies);
        request.addRequestHeader("User-Agent", userAgent == null ? UA_MOBILE : userAgent);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setTitle(fileName);
        request.setDescription(getString(R.string.toast_download_desc));
        if (mimeType != null && !mimeType.trim().isEmpty()
            && !mimeType.trim().equalsIgnoreCase("application/octet-stream")) {
          request.setMimeType(mimeType.split(";")[0].trim());
        }
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (dm != null) {
          dm.enqueue(request);
          toast(getString(R.string.toast_download_started, fileName));
        } else {
          toast(getString(R.string.toast_download_unavailable));
        }
      } catch (Exception ex) {
        toast(getString(R.string.toast_download_failed));
        android.util.Log.e("BrowserDownload", "Download failed", ex);
      }
    });

    wv.setWebViewClient(new WebViewClient() {

      @Override
      public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        if (request == null) return null;
        Uri uri = request.getUrl();
        if (uri == null) return null;
        String scheme = uri.getScheme();
        if (scheme != null && !scheme.equals("http") && !scheme.equals("https")) return null;
        String host = uri.getHost();
        if (host == null) return null;

        if (host.equals(ASSET_DOMAIN)) {
          String path = uri.getPath();
          if (path == null) path = "/";

          if (path.equals("/jszip_js.js")) {
            try (InputStream raw = getResources().openRawResource(R.raw.jszip_js);
                 ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
              byte[] b = new byte[8192];
              int n;
              while ((n = raw.read(b)) > 0) buf.write(b, 0, n);
              InputStream is = new ByteArrayInputStream(buf.toByteArray());
              return new WebResourceResponse(
                  "application/javascript", "UTF-8",
                  200, "OK", MainActivity.this.corsHeaders(), is);
            } catch (Exception e) {
              try {
                byte[] errBytes = ("// jszip missing: " + e.getMessage()).getBytes("UTF-8");
                return new WebResourceResponse(
                    "application/javascript", "UTF-8", 500, "Error",
                    MainActivity.this.corsHeaders(),
                    new ByteArrayInputStream(errBytes));
              } catch (Exception ignored) { return null; }
            }
          }

          if (path.startsWith("/newtab")) {
            try {
              InputStream is = getAssets().open("newtab.html");
              return new WebResourceResponse("text/html", "UTF-8", 200, "OK", MainActivity.this.corsHeaders(), is);
            } catch (IOException e) {
              return MainActivity.this.htmlResponse("<h1>newtab.html not found</h1>", 404, "Not Found");
            }
          }

          if (path.startsWith("/settings")) {
            String html = MainActivity.this.getSettingsHtml();
            return MainActivity.this.htmlResponse(html, 200, "OK");
          }

          if (path.startsWith("/assets/")) {
            String assetPath = path.substring("/assets/".length());
            if (assetPath.isEmpty()) assetPath = "index.html";
            try {
              InputStream is = getAssets().open(assetPath);
              return new WebResourceResponse(MainActivity.this.guessMime(assetPath), null, 200, "OK", MainActivity.this.corsHeaders(), is);
            } catch (IOException e) {
              String errHtml = MainActivity.this.errorHtml("ERR_FILE_NOT_FOUND", "File missing: " + assetPath, "this://" + assetPath);
              return MainActivity.this.htmlResponse(errHtml, 404, "Not Found");
            }
          }
          try {
            InputStream is = new ByteArrayInputStream(new byte[0]);
            return new WebResourceResponse("text/plain", null, 204, "No Content", MainActivity.this.corsHeaders(), is);
          } catch (Exception e) {
            return null;
          }
        }

        if (request.isForMainFrame()) return null;

        if (!adblockEnabled) return null;

        String decodedUrl = AdBlock.decodeProxyUrl(uri.toString());
        Uri dUri;
        try { dUri = Uri.parse(decodedUrl); } catch (Exception e) { return null; }
        String dHost = dUri.getHost();
        
        String pageHost = null;
        try { pageHost = Uri.parse(currentPageUrl).getHost(); } catch (Exception ignored) {}

        if (AdBlock.isBlockedHost(dHost, pageHost)) {
          adblockPageBlocked++;
          adblockTotalBlocked++;
          recordAdblockEvents(currentPageUrl, 1);
          return blockedResponse("text/plain");
        }

        return null;
      }

      @Override
      public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url == null) return false;
        String lower = url.toLowerCase();
        if (lower.startsWith("this://") || lower.startsWith("about://")) { loadUrl(url); return true; }
        if (lower.startsWith("file://")) {
          String path = Uri.parse(url).getPath();
          String sharedPath = new File(getCacheDir(), "shared").getAbsolutePath();
          if (path != null && path.startsWith(sharedPath + "/")) return false;
          toast(getString(R.string.err_file_not_allowed));
          return true;
        }
        if (lower.startsWith("http://") || lower.startsWith("https://")) { showingError = false; return false; }
        try {
          Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
          startActivity(intent);
        } catch (Exception ignored) {}
        return true;
      }

      @Override
      public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
        return shouldOverrideUrlLoading(view, req.getUrl().toString());
      }

      @Override
      public void onPageStarted(WebView view, String url, Bitmap fav) {
        super.onPageStarted(view, url, fav);
        
        Tab tab = getTabForWebView(view);
        if (tab != null) tab.url = url;

        if (view == mWebView) {
            currentPageUrl = url == null ? "" : url;
            sslErrorDetected = false;
            adblockPageHidden = 0;
            adblockPageBlocked = 0;
            if (!showingError) urlBar.setText(prettyUrl(url));
            updateSecurityIndicator(url);
            urlBar.clearFocus();
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(0);
            updateNavigationControls();
    
            if (desktopMode && !isInternalPage(url)) {
              injectDesktopController();
            }
    
            if (adblockEnabled && !isInternalPage(url)) {
              injectAdblock();
            }
        }
      }

      @Override
      public void onPageCommitVisible(WebView view, String url) {
        super.onPageCommitVisible(view, url);
        if (view == mWebView && !showingError && view != null && !isInternalPage(url)) {
          if (adblockEnabled) injectAdblock();
          view.evaluateJavascript(getDevToolsJs(), null);
        }
      }

      @Override
      public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        
        Tab tab = getTabForWebView(view);
        if (tab != null) {
            tab.url = url;
            String title = view.getTitle();
            if (title == null || title.isEmpty()) title = prettyUrl(url);
            tab.title = title;
            tab.favicon = faviconUrl(url);
            if (!tab.incognito && !isInternalUrl(url)) historyAdd(title, url);
        }

        if (view == mWebView) {
            if (showingError) { progressBar.setVisibility(View.GONE); return; }
            urlBar.setText(prettyUrl(url));
            updateSecurityIndicator(url);
            progressBar.setVisibility(View.GONE);
            updateNavigationControls();
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
              CookieManager.getInstance().flush();
            }
            view.evaluateJavascript(getNoScrollCss(), null);
            view.evaluateJavascript(getDevToolsJs(), null);
            
            installBlobDownloadHandler();
            if (adblockEnabled && !isInternalPage(url)) {
              injectAdblock();
              mainHandler.removeCallbacks(adblockStatsRunnable);
              mainHandler.postDelayed(adblockStatsRunnable, ADBLOCK_STATS_DELAY_MS);
              mainHandler.postDelayed(adblockStatsRunnable, ADBLOCK_STATS_DELAY_MS * 3);
            }
        }
        renderTabs();
        saveTabs();
      }

      @Override
      public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler, android.net.http.SslError error) {
        handler.proceed();
        if (view == mWebView) {
            sslErrorDetected = true;
            updateSecurityIndicator(view.getUrl());
        }
      }

      @Override
      public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        if (view != mWebView) return;
        if (!request.isForMainFrame()) return;
        if (showingError) return;
        String url = request.getUrl().toString();
        if (isInternalUrl(url)) return;
        if (url.startsWith("data:")) return;
        if (url.startsWith("about:")) return;
        int code = error.getErrorCode();
        String errCode = webErrorCode(code);
        CharSequence descSeq = error.getDescription();
        String desc = descSeq != null ? descSeq.toString() : webErrorDesc(code);
        if (desc == null || desc.isEmpty()) desc = webErrorDesc(code);
        showErrorPage(errCode, desc, url);
      }

      @Override
      public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        if (view != mWebView) return;
        if (showingError) return;
        if (failingUrl == null) return;
        if (isInternalUrl(failingUrl)) return;
        if (failingUrl.startsWith("data:")) return;
        if (failingUrl.startsWith("about:")) return;
        String errCode = webErrorCode(errorCode);
        String desc = description != null && !description.isEmpty() ? description : webErrorDesc(errorCode);
        showErrorPage(errCode, desc, failingUrl);
      }

      @Override
      public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
        if (view != mWebView) return;
        if (!request.isForMainFrame()) return;
        if (showingError) return;
        String url = request.getUrl().toString();
        if (isInternalUrl(url)) return;
        int status = errorResponse.getStatusCode();
        if (status >= 400) {
          String code = httpErrorCode(status);
          String reason = errorResponse.getReasonPhrase() != null ? errorResponse.getReasonPhrase() : "";
          String desc = getString(R.string.err_http_desc, status, reason.isEmpty() ? "" : " (" + reason + ")");
          showErrorPage(code, desc, url);
        }
      }
    });

    wv.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
        if (!isUserGesture) return false;
        final WebView popup = new WebView(MainActivity.this);
        popups.add(new WeakReference<>(popup));
        WebSettings ps = popup.getSettings();
        ps.setJavaScriptEnabled(true);
        ps.setDomStorageEnabled(true);
        ps.setSupportMultipleWindows(true);
        popup.setWebViewClient(new WebViewClient() {
          @Override public boolean shouldOverrideUrlLoading(WebView child, String url) {
            if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
              child.stopLoading();
              child.destroy();
              runOnUiThread(() -> newTab(url, false));
              return true;
            }
            return false;
          }
          @Override public void onPageStarted(WebView child, String url, Bitmap favicon) {
            if (child == mWebView) currentFaviconBitmap = favicon == null ? null : favicon.copy(Bitmap.Config.ARGB_8888, false);
            if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
              child.stopLoading();
              child.destroy();
              runOnUiThread(() -> newTab(url, false));
            }
          }
        });
        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popup);
        resultMsg.sendToTarget();
        return true;
      }

      @Override
      public void onCloseWindow(WebView window) {
        try {
          window.stopLoading();
          window.destroy();
        } catch (Exception ignored) {}
      }

      @Override
      public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
        if (MainActivity.this.fileChooserCallback != null) {
          MainActivity.this.fileChooserCallback.onReceiveValue(null);
        }
        MainActivity.this.fileChooserCallback = filePathCallback;
        try {
          Intent intent = fileChooserParams.createIntent();
          startActivityForResult(intent, FILE_CHOOSER_REQUEST);
          return true;
        } catch (Exception e) {
          MainActivity.this.fileChooserCallback = null;
          filePathCallback.onReceiveValue(null);
          toast(getString(R.string.toast_file_chooser_unavailable));
          return false;
        }
      }

      @Override
      public void onProgressChanged(WebView view, int newProgress) {
        if (view == mWebView) {
            progressBar.setProgress(newProgress);
            if (newProgress == 100) progressBar.setVisibility(View.GONE);
        }
      }

      @Override
      public void onReceivedTitle(WebView view, String title) {
        super.onReceivedTitle(view, title);
        Tab tab = getTabForWebView(view);
        if (tab != null && title != null) {
            tab.title = title;
            renderTabs();
        }
      }

      @Override
      public void onReceivedIcon(WebView view, Bitmap icon) {
        super.onReceivedIcon(view, icon);
        Tab tab = getTabForWebView(view);
        if (icon != null && tab != null) {
            tab.favicon = faviconUrl(view.getUrl());
            if (view == mWebView) currentFaviconBitmap = icon.copy(Bitmap.Config.ARGB_8888, false);
        }
      }

      @Override
      public void onPermissionRequest(final PermissionRequest request) {
        request.deny();
        runOnUiThread(() -> toast(getString(R.string.toast_permission_denied)));
      }

      @Override
      public boolean onConsoleMessage(android.webkit.ConsoleMessage cm) {
        android.util.Log.d("WebView", cm.message() + " @" + cm.sourceId() + ":" + cm.lineNumber());
        return true;
      }

      @Override
      public void onExceededDatabaseQuota(String url, String dbName, long quota, long estimatedSize, long totalUsedQuota, WebStorage.QuotaUpdater updater) {
        updater.updateQuota(estimatedSize * 2);
      }
    });
  }

  public String getNoScrollCss() {
    return "(function(){" +
        "if(document.getElementById('_noscroll')) return;" +
        "var st=document.createElement('style');" +
        "st.id='_noscroll';" +
        "st.textContent='html,body{overflow-x:hidden!important}';" +
        "document.head.appendChild(st);" +
        "})();";
  }

  public String getDevToolsJs() {
    if (devtoolsJsCache != null) return devtoolsJsCache;
    try {
      String js = readRawText(this, R.raw.devtools_js);
      String css = readRawText(this, R.raw.devtools_css);
      String labels = "window.__devtools_labels=" + getLabelsJson() + ";\n";
      String cssInject =
        "(function(){" +
            "if(document.getElementById('dt-style')) return;" +
            "var s=document.createElement('style');" +
            "s.id='dt-style';" +
            "s.textContent=" + jsStr(css) + ";" +
            "(document.head||document.documentElement).appendChild(s);" +
            "})();\n";
      devtoolsJsCache = labels + cssInject + js;
      return devtoolsJsCache;
    } catch (Exception e) {
      devtoolsJsCache = "console.error('devtools not found: " + e.getMessage() + "');";
      return devtoolsJsCache;
    }
  }

  public static String jsStr(String s) {
    if (s == null) return "\"\"";
    StringBuilder sb = new StringBuilder("\"");
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      switch (c) {
        case '\\': sb.append("\\\\"); break;
        case '"': sb.append("\\\""); break;
        case '\n': sb.append("\\n"); break;
        case '\r': sb.append("\\r"); break;
        case '\t': sb.append("\\t"); break;
        case '\b': sb.append("\\b"); break;
        case '\f': sb.append("\\f"); break;
        case 0x2028: sb.append("\\u2028"); break;
        case 0x2029: sb.append("\\u2029"); break;
        default:
          if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
          else sb.append(c);
      }
    }
    sb.append("\"");
    return sb.toString();
  }

  public void toggleReaderMode() {
    if (mWebView != null) mWebView.evaluateJavascript(ReaderMode.toJavaScript(), null);
  }

  public void showPageTextStatistics() {
    if (mWebView == null) return;
    mWebView.evaluateJavascript(PageTextTools.wordCountScript(), value -> {
      try {
        JSONObject data = new JSONObject(value == null || "null".equals(value) ? "{}" : value);
        String message = getString(R.string.word_count, data.optInt("words")) + "\n"
            + getString(R.string.character_count, data.optInt("characters")) + "\n"
            + getString(R.string.paragraph_count, data.optInt("paragraphs"));
        new AlertDialog.Builder(this)
            .setTitle(R.string.menu_page_text_statistics)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok, null)
            .show();
      } catch (Exception e) {
        toast(getString(R.string.page_text_statistics_error));
      }
    });
  }

  public String getLabelsJson() {
    return "{"
      + "\"console\":" + jsStr(getString(R.string.dt_console)) + ","
      + "\"sources\":" + jsStr(getString(R.string.dt_sources)) + ","
      + "\"network\":" + jsStr(getString(R.string.dt_network)) + ","
      + "\"application\":" + jsStr(getString(R.string.dt_application)) + ","
      + "\"elements\":" + jsStr(getString(R.string.dt_elements)) + ","
      + "\"performance\":" + jsStr(getString(R.string.dt_performance)) + ","
      + "\"clear\":" + jsStr(getString(R.string.dt_clear)) + ","
      + "\"close\":" + jsStr(getString(R.string.dt_close)) + ","
      + "\"run\":" + jsStr(getString(R.string.dt_run)) + ","
      + "\"placeholder\":" + jsStr(getString(R.string.dt_placeholder)) + ","
      + "\"noLogs\":" + jsStr(getString(R.string.dt_no_logs)) + ","
      + "\"noNet\":" + jsStr(getString(R.string.dt_no_net)) + ","
      + "\"noSrc\":" + jsStr(getString(R.string.dt_no_src)) + ","
      + "\"empty\":" + jsStr(getString(R.string.dt_empty)) + ","
      + "\"headers\":" + jsStr(getString(R.string.dt_headers)) + ","
      + "\"preview\":" + jsStr(getString(R.string.dt_preview)) + ","
      + "\"response\":" + jsStr(getString(R.string.dt_response)) + ","
      + "\"timing\":" + jsStr(getString(R.string.dt_timing)) + ","
      + "\"general\":" + jsStr(getString(R.string.dt_general)) + ","
      + "\"reqHeaders\":" + jsStr(getString(R.string.dt_req_headers)) + ","
      + "\"resHeaders\":" + jsStr(getString(R.string.dt_res_headers)) + ","
      + "\"localStorage\":" + jsStr(getString(R.string.dt_local_storage)) + ","
      + "\"sessionStorage\":" + jsStr(getString(R.string.dt_session_storage)) + ","
      + "\"cookies\":" + jsStr(getString(R.string.dt_cookies)) + ","
      + "\"indexedDB\":" + jsStr(getString(R.string.dt_indexeddb)) + ","
      + "\"key\":" + jsStr(getString(R.string.dt_key)) + ","
      + "\"value\":" + jsStr(getString(R.string.dt_value)) + ","
      + "\"name\":" + jsStr(getString(R.string.dt_name)) + ","
      + "\"external\":" + jsStr("This resource is external or blocked by cross-origin restrictions")
      + "}";
  }
}